const $ = (id) => document.getElementById(id);
const state = { tabId: null, frameId: 0, detection: null, exporting: false, format: 'csv' };

function log(message) {
  const line = `[${new Date().toLocaleTimeString('zh-CN', { hour12: false })}] ${message}`;
  $('log').textContent = `${line}\n${$('log').textContent}`.slice(0, 8000);
}

function setStatus(kind, text, hint = '') {
  $('status-card').className = `status-card ${kind}`;
  $('status').textContent = text;
  $('status-icon').textContent = kind === 'ok' ? '✓' : (kind === 'error' ? '!' : '○');
  $('hint').textContent = hint;
}

function setFormat(format) {
  state.format = format === 'txt' ? 'txt' : 'csv';
  for (const card of document.querySelectorAll('.format-card')) {
    const selected = card.dataset.format === state.format;
    card.classList.toggle('selected', selected);
    card.setAttribute('aria-checked', String(selected));
  }
}

function setProgress({ completed = 0, total = 0, pagesVisited = 0, totalPages = 0, stage = 'exporting', phase = '', heartbeatAt = 0 } = {}) {
  $('progress-section').hidden = false;
  const knownTotal = Number(total) > 0;
  const percent = knownTotal ? Math.min(100, Math.round((Number(completed) / Number(total)) * 100)) : 0;
  $('progress-bar').style.width = `${percent}%`;
  $('progress-count').textContent = stage === 'complete'
    ? `已完成 ${completed} 个聊天`
    : (stage === 'ready'
      ? (knownTotal ? `待导出 ${total} 个聊天` : '等待开始导出')
      : (knownTotal ? `已导出 ${completed} / ${total} 个聊天` : `已导出 ${completed} 个聊天`));
  const pageText = totalPages ? `第 ${pagesVisited || 1} / ${totalPages} 页` : (pagesVisited ? `已处理 ${pagesVisited} 页` : '正在准备导出');
  const stalled = stage === 'exporting' && heartbeatAt && Date.now() - Number(heartbeatAt) > 30_000;
  const activity = stalled
    ? '目标页面暂未响应；请将生意参谋页面切回前台后继续。'
    : (phase || (stage === 'downloading' ? '聊天采集完成，正在下载文件' : '当前正在采集聊天明细。'));
  $('progress-detail').textContent = stage === 'complete'
    ? `已完成导出，共 ${completed} 个聊天。`
    : (stage === 'ready' ? `${pageText}；点击“开始本地导出”后将从第一页开始采集。` : `${pageText}；${activity}`);
}

async function send(tabId, frameId, message) {
  return chrome.tabs.sendMessage(tabId, message, { frameId });
}

async function findTarget() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.startsWith('http')) throw new Error('请先打开生意参谋的咨询明细页面。');
  state.tabId = tab.id;
  const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
  const candidates = [];
  for (const frame of frames) {
    try {
      const result = await send(tab.id, frame.frameId, { type: 'qianniuLocal.detect' });
      if (result?.supported && result.kind === 'chat-detail') candidates.push({ frameId: frame.frameId, result });
    } catch (_) { /* frame may not have the content script */ }
  }
  if (!candidates.length) throw new Error('未找到“咨询明细”中的“聊天明细”入口。请先进入生意参谋对应列表页并完成查询。');
  candidates.sort((a, b) => b.result.score - a.result.score);
  state.frameId = candidates[0].frameId;
  state.detection = candidates[0].result;
  return state.detection;
}

async function detect() {
  $('settings').hidden = true;
  setStatus('loading', '正在检测当前页面与分页…');
  try {
    const d = await findTarget();
    const total = Number(d.total || 0);
    const pages = Number(d.pages || 0);
    const current = Number(d.count || 0);
    const pageText = pages ? `共 ${pages} 页` : '页数暂未标示';
    const totalText = total ? `共 ${total} 个聊天` : '聊天总数暂未标示';
    setStatus('ok', `已识别聊天明细：${totalText}`, `${pageText}，当前页 ${current} 条。${d.description || ''}`);
    $('settings').hidden = false;
    setProgress({ completed: 0, total, pagesVisited: 0, totalPages: pages, stage: 'ready' });
    log(`检测完成：${totalText}，${pageText}，当前页 ${current} 条。`);
  } catch (error) {
    setStatus('error', '无法导出此页面', error.message);
    log(`检测失败：${error.message}`);
  }
}

function safeCell(value) {
  const text = String(value ?? '');
  return /^[=+\-@]/.test(text) ? `'${text}` : text;
}

function mask(value) {
  const text = String(value ?? '');
  if (text.length < 3) return '***';
  return `${text.slice(0, 1)}***${text.slice(-1)}`;
}

function sensitive(name) { return /旺旺|买家|用户|客户|姓名|手机号|电话|联系人|发送人|账号/i.test(name || ''); }
function csvCell(value) { return `"${String(safeCell(value)).replaceAll('"', '""')}"`; }

function makeChatCsv(data, redact) {
  const conversations = (data.conversations || []).map((conversation) => ({
    ...conversation,
    customer: redact ? mask(conversation.customer) : conversation.customer,
    rowData: Object.fromEntries(Object.entries(conversation.rowData || {}).map(([key, value]) => [key, redact && sensitive(key) ? mask(value) : value])),
    messages: (conversation.messages || []).map((message) => ({ ...message, sender: redact ? mask(message.sender) : message.sender }))
  }));
  const detailHeaders = [...new Set(conversations.flatMap((conversation) => Object.keys(conversation.rowData || {})))];
  const rows = conversations.flatMap((conversation) => {
    const messages = conversation.messages?.length ? conversation.messages : [{ time: '', role: '', sender: '', content: conversation.loadFailed ? `[聊天详情加载失败：${conversation.failureReason || '未知原因'}]` : '' }];
    return messages.map((message) => ({ ...conversation.rowData, 客户: conversation.customer, 时间: message.time, 角色: message.role, 发送人: message.sender, 内容: message.content }));
  });
  const headers = [...detailHeaders, '客户', '时间', '角色', '发送人', '内容'];
  const text = '\uFEFF' + [headers.map(csvCell).join(','), ...rows.map((row) => headers.map((header) => csvCell(row[header])).join(','))].join('\r\n');
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  return { text, filename: `taoxi-chat-insight-${stamp}.csv` };
}

async function exportData() {
  const button = $('export');
  button.disabled = true;
  try {
    if (!state.detection) await detect();
    if (!state.detection) throw new Error('页面检测未通过。');
    const result = await chrome.runtime.sendMessage({
      type: 'qianniuLocal.startExport', tabId: state.tabId, frameId: state.frameId,
      total: state.detection.total, totalPages: state.detection.pages, redact: $('redact').checked, format: state.format
    });
    if (!result?.ok) throw new Error(result?.error || '后台未能启动导出任务。');
    state.exporting = true;
    setProgress(result.task);
    log('后台导出已启动。现在可以关闭扩展窗口、切换标签页或继续其他工作。');
  } catch (error) {
    log(`导出失败：${error.message}`);
    setStatus('error', '导出失败', error.message);
    button.disabled = false;
  }
}

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== 'qianniuLocal.taskUpdate' || message.tabId !== state.tabId || message.frameId !== state.frameId) return;
  state.exporting = Boolean(message.active);
  setProgress(message);
  if (message.stage === 'complete') { $('export').disabled = false; log(`完成：已导出 ${message.completed} 个聊天。`); }
  if (message.stage === 'failed') { $('export').disabled = false; setStatus('error', '后台导出失败', message.error || '未知错误'); log(`导出失败：${message.error || '未知错误'}`); }
});

async function restoreBackgroundTask() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return false;
  const result = await chrome.runtime.sendMessage({ type: 'qianniuLocal.getExportStatus', tabId: tab.id });
  const task = result?.task;
  if (!task?.active) return false;
  state.tabId = task.tabId;
  state.frameId = task.frameId;
  state.exporting = true;
  $('settings').hidden = true;
  setStatus('loading', '后台正在导出聊天明细…', '可以关闭此窗口或继续浏览其他页面；重新打开扩展可查看最新进度。');
  setProgress(task);
  log(`已恢复后台任务：当前已导出 ${task.completed || 0}${task.total ? ` / ${task.total}` : ''} 个聊天。`);
  return true;
}

document.addEventListener('DOMContentLoaded', async () => {
  const saved = await chrome.storage.local.get({ redact: true, format: 'csv' });
  $('redact').checked = saved.redact;
  setFormat(saved.format);
  $('redact').addEventListener('change', () => chrome.storage.local.set({ redact: $('redact').checked }));
  for (const card of document.querySelectorAll('.format-card')) {
    card.addEventListener('click', () => {
      setFormat(card.dataset.format);
      chrome.storage.local.set({ format: state.format });
    });
  }
  $('redetect').addEventListener('click', detect);
  $('export').addEventListener('click', exportData);
  $('clear-log').addEventListener('click', () => { $('log').textContent = '日志已清空。'; });
  if (!(await restoreBackgroundTask())) await detect();
});
