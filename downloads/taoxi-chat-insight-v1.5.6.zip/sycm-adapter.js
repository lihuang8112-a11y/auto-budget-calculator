/**
 * 生意参谋通用内容脚本
 * 自动适配：接待明细、成交明细、流失明细、质量明细、商品明细、售后明细
 * 及其子分类页面
 */

(function() {
  'use strict';

  // ========== 日志收集器（自动收集 [千牛导出] 开头的日志）==========
  (function setupLogCollector() {
    if (window.__QIANNIU_LOG_BUFFER__) return;
    const MAX_LOGS = 2000;
    window.__QIANNIU_LOG_BUFFER__ = [];

    function addLog(level, args) {
      try {
        const text = args.map(a => {
          if (typeof a === 'string') return a;
          if (a instanceof Error) return a.stack || a.message;
          try { return JSON.stringify(a); } catch(e) { return String(a); }
        }).join(' ');
        const entry = `[${new Date().toISOString()}] [${level}] ${text}`;
        window.__QIANNIU_LOG_BUFFER__.push(entry);
        if (window.__QIANNIU_LOG_BUFFER__.length > MAX_LOGS) {
          window.__QIANNIU_LOG_BUFFER__.shift();
        }
      } catch(e) {}
    }

    const origLog = console.log;
    const origWarn = console.warn;
    const origError = console.error;

    console.log = function(...args) {
      const text = args.map(a => typeof a === 'string' ? a : '').join(' ');
      if (text.includes('[千牛导出]')) addLog('LOG', args);
      origLog.apply(console, args);
    };
    console.warn = function(...args) {
      const text = args.map(a => typeof a === 'string' ? a : '').join(' ');
      if (text.includes('[千牛导出]')) addLog('WARN', args);
      origWarn.apply(console, args);
    };
    console.error = function(...args) {
      const text = args.map(a => typeof a === 'string' ? a : '').join(' ');
      if (text.includes('[千牛导出]')) addLog('ERROR', args);
      origError.apply(console, args);
    };
  })();

  // 页面类型识别关键词（主板块，不含子分类关键词）
  const PAGE_TYPES = {
    '接待明细': ['接待明细', '接待概况'],
    '成交明细': ['成交明细', '成交记录'],
    '流失明细': ['流失明细', '流失记录'],
    '质量明细': ['质量明细', '质检明细'],
    '商品明细': ['商品明细'],
    '售后明细': ['售后明细', '退款明细', '退货明细']
  };

  const SUB_PAGE_TYPES = {
    '旺旺咨询明细': ['旺旺咨询明细'],
    '有效接待明细': ['有效接待明细'],
    '接待过滤明细': ['接待过滤明细'],
    '商品推荐明细': ['商品推荐明细'],
    '商品销售明细': ['商品销售明细'],
    '商品咨询明细': ['商品咨询明细'],
    '旺旺退款明细': ['旺旺退款明细'],
    '旺旺销售明细': ['旺旺销售明细'],
    '询单流失明细': ['询单流失明细'],
    '静默退款明细': ['静默退款明细'],
    '接待评价明细': ['接待评价明细'],
    '慢响应明细': ['慢响应明细'],
    '长接待明细': ['长接待明细'],
    '3分钟未响应明细': ['3分钟未响应明细', '3分钟未响应'],
    '全部退款明细': ['全部退款明细'],
    '咨询后退款明细': ['咨询后退款明细'],
    '退款挽留明细': ['退款挽留明细'],
    '投诉明细': ['投诉明细'],
    '售后解决明细': ['售后解决明细']
  };

  // 聊天明细按钮文字关键词
  const CHAT_BTN_KEYWORDS = ['聊天明细', '聊天记录', '查看聊天', '对话详情', '详情', '查看'];

  // 展开/折叠按钮文字
  const EXPAND_BTN_KEYWORDS = ['展开', '查看更多', '显示更多'];

  // 识别当前主板块
  function detectMainPageType() {
    const bodyText = document.body.innerText;
    const url = window.location.href;

    for (const [type, keywords] of Object.entries(PAGE_TYPES)) {
      for (const kw of keywords) {
        if (bodyText.includes(kw) || url.includes(encodeURIComponent(kw))) {
          return type;
        }
      }
    }

    // 兜底：根据 URL 路径猜
    if (url.includes('sycm.taobao.com')) {
      if (url.includes('service')) return '接待明细';
      if (url.includes('product')) return '商品明细';
      if (url.includes('trade')) return '成交明细';
      if (url.includes('lost')) return '流失明细';
      if (url.includes('quality')) return '质量明细';
      if (url.includes('aftersale')) return '售后明细';
    }

    return '未知板块';
  }

  // 识别当前子分类
  function detectSubPageType() {
    const bodyText = document.body.innerText;

    for (const [type, keywords] of Object.entries(SUB_PAGE_TYPES)) {
      for (const kw of keywords) {
        if (bodyText.includes(kw)) return type;
      }
    }

    return '';
  }

  // 判断元素是否可见/激活
  function isActiveElement(el) {
    if (!el) return false;
    const cls = (el.className || '').toString().toLowerCase();
    return cls.includes('active') ||
           cls.includes('selected') ||
           el.getAttribute('aria-selected') === 'true';
  }

  // 更精确的子分类识别：找激活的 tab
  function detectActiveSubTab() {
    const tabKeywords = Object.values(SUB_PAGE_TYPES).flat();
    const allEls = document.querySelectorAll('a, button, div, span, li');

    for (const el of allEls) {
      const text = el.textContent && el.textContent.trim();
      if (!text) continue;
      for (const kw of tabKeywords) {
        if (text === kw && isActiveElement(el)) {
          return kw;
        }
      }
    }

    // 兜底：找页面里第一个出现的子分类名
    const bodyText = document.body.innerText;
    for (const kw of tabKeywords) {
      if (bodyText.includes(kw)) return kw;
    }

    return detectSubPageType();
  }

  // 判断元素是否真实可见
  function isElementVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
  }

  // 找页面主表格
  function findMainTable() {
    // 优先找 ant-table 里可见且 tbody 行数最多的 table，排除嵌套表格
    const candidates = [];
    document.querySelectorAll('.ant-table, .ant-table-default, .ant-table-bordered').forEach(wrapper => {
      const tables = wrapper.querySelectorAll('table');
      tables.forEach(table => {
        // 跳过嵌套在另一个 table 里的 table
        if (table.closest('table') && table.closest('table') !== table) return;
        const tbody = table.querySelector('tbody');
        const rowCount = tbody ? tbody.querySelectorAll(':scope > tr').length : 0;
        if (rowCount > 0) {
          candidates.push({ table, rowCount, wrapper });
        }
      });
    });

    // 如果 ant-table 没找到，再全局搜索
    if (candidates.length === 0) {
      document.querySelectorAll('table').forEach(table => {
        if (table.closest('table') && table.closest('table') !== table) return;
        const tbody = table.querySelector('tbody');
        const rowCount = tbody ? tbody.querySelectorAll(':scope > tr').length : 0;
        if (rowCount > 0) candidates.push({ table, rowCount });
      });
    }

    // 过滤：排除疑似非数据表格（如日历、选择器等）
    // 特征：表头只有"一二三四五六日"等星期文字，没有实际业务列名
    const filteredCandidates = candidates.filter(c => {
      const headerCells = c.table.querySelectorAll('thead th, thead td, tr:first-child th, tr:first-child td');
      if (headerCells.length === 0) return true;
      const headerTexts = Array.from(headerCells).map(h => (h.textContent || '').trim());
      // 统计有效业务列（排除空列和纯星期列）
      const businessHeaders = headerTexts.filter(h =>
        h && h.length >= 1 && !/^[一二三四五六日]$/.test(h) && !/^\d+$/.test(h)
      );
      // 有效业务列不足3列视为异常表格
      if (businessHeaders.length < 3) {
        console.log(`[千牛导出] 跳过疑似非数据表格(${c.rowCount}行): 表头=${headerTexts.join('|')}`);
        return false;
      }
      return true;
    });

    // 按行数降序，优先选有 thead 的
    const targetCandidates = filteredCandidates.length > 0 ? filteredCandidates : candidates;
    targetCandidates.sort((a, b) => {
      if (b.rowCount !== a.rowCount) return b.rowCount - a.rowCount;
      const aHasHead = a.table.querySelector('thead') ? 1 : 0;
      const bHasHead = b.table.querySelector('thead') ? 1 : 0;
      return bHasHead - aHasHead;
    });

    return targetCandidates.length > 0 ? targetCandidates[0].table : null;
  }

  // 清理表头文字，作为字段名
  function cleanHeader(text) {
    if (!text) return '';
    return text
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u00A0\u2000-\u200D\uFEFF\u2060\u00AD\u2028\u2029\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, '')
      .replace(/\s+/g, ' ')
      .replace(/\n/g, ' ')
      .replace(/排序|升序|降序/g, '')
      .replace(/^["'“”‘’]+|["'“”‘’]+$/g, '')
      .trim();
  }

  // 从复杂单元格提取商品信息
  function extractProductCell(cell) {
    const result = { text: '', productName: '', productId: '', productUrl: '', productImg: '' };
    if (!cell) return result;

    const text = cell.textContent.trim();
    result.text = text;

    // 找商品名称链接（优先 title 属性，避免截断）
    const nameLink = cell.querySelector('a[title]') || cell.querySelector('.singleGoodsName a') || cell.querySelector('a');
    if (nameLink) {
      result.productName = nameLink.getAttribute('title') || nameLink.textContent.trim();
      result.productUrl = nameLink.getAttribute('href') || '';
    } else {
      // 兜底：找最长的文本作为商品名
      const texts = [];
      cell.querySelectorAll('*').forEach(el => {
        const t = el.childNodes.length > 0 && el.childNodes[0].nodeType === Node.TEXT_NODE
          ? el.childNodes[0].textContent.trim()
          : '';
        if (t.length > 5) texts.push(t);
      });
      if (texts.length > 0) {
        result.productName = texts.sort((a, b) => b.length - a.length)[0];
      }
    }

    // 找商品ID
    const idMatch = text.match(/商品ID[：:]\s*(\d+)/) || text.match(/ID[：:]\s*(\d+)/);
    if (idMatch) {
      result.productId = idMatch[1];
    }

    // 找商品图片
    const img = cell.querySelector('img.mediaObject') || cell.querySelector('img');
    if (img) {
      result.productImg = img.getAttribute('src') || '';
    }

    return result;
  }

  // 从旺旺单元格提取（适配 low-wangwang 结构）
  function extractWangwangCell(cell) {
    if (!cell) return { text: '', name: '', isMasked: false };

    // 优先找带样式的 span 中的真实文本
    const textSpan = cell.querySelector('.low-wangwang span') || cell.querySelector('span[style*="color"]') || cell;
    const text = textSpan.textContent.trim();

    // 尝试找 title 属性里的真实旺旺
    const title = cell.getAttribute('title') || textSpan.getAttribute('title') || '';

    const name = (title || text).replace(/旺旺/g, '').trim();
    return {
      text: text,
      name: name,
      isMasked: /\*+/.test(name)
    };
  }

  // 从时间单元格提取（适配 alife-dt-card-common-table-sortable-td 结构）
  function extractTimeCell(cell) {
    if (!cell) return { text: '', datetime: '' };
    const text = cell.textContent.trim();
    // 优先匹配 sortable-value 里的时间
    const valueEl = cell.querySelector('.alife-dt-card-common-table-sortable-value') || cell;
    const valueText = valueEl.textContent.trim();
    const match = valueText.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(?::\d{2})?/)
          || text.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(?::\d{2})?/);
    return {
      text: text,
      datetime: match ? match[0] : ''
    };
  }

  // 判断表头是否包含商品相关文字
  function isProductHeader(header) {
    return header && (header.includes('商品') || header.includes('宝贝') || header.includes('产品'));
  }

  // 判断表头是否包含买家旺旺相关文字（明确排除客服/接待客服，避免客服子账号污染买家旺旺列）
  function isWangwangHeader(header) {
    if (!header) return false;
    if (header.includes('客服') || header.includes('接待客服')) return false;
    return header.includes('旺旺') || header.includes('买家');
  }

  // 判断表头是否包含时间相关文字
  function isTimeHeader(header) {
    return header && (header.includes('时间') || header.includes('日期'));
  }

  // 判断表头是否是操作列
  function isOperationHeader(header) {
    return header && (header.includes('操作') || header.includes('详情'));
  }

  // 从单元格提取操作按钮
  function extractOperationButtons(cell) {
    const buttons = [];
    if (!cell) return buttons;

    // 1. 先找显式的可点击元素（a, button, role=button）
    const allClickable = cell.querySelectorAll('a, button, span[role="button"], div[role="button"]');
    allClickable.forEach(el => {
      const text = el.textContent.trim();
      if (!text) return;

      const isChat = CHAT_BTN_KEYWORDS.some(kw => text.includes(kw));
      const isExpand = EXPAND_BTN_KEYWORDS.some(kw => text.includes(kw));

      buttons.push({
        text: text,
        element: el,
        isChat: isChat,
        isExpand: isExpand,
        isPrimary: isChat
      });
    });

    // 2. 找 .operation-item 容器（生意参谋的"操作"列结构）- 优先返回外层容器
    if (!buttons.some(b => b.isChat)) {
      const operationItems = cell.querySelectorAll('.operation-item, [class*="operation-item"]');
      operationItems.forEach(item => {
        const text = (item.textContent || '').trim();
        if (!text) return;
        const isChat = CHAT_BTN_KEYWORDS.some(kw => text.includes(kw));
        const isExpand = EXPAND_BTN_KEYWORDS.some(kw => text.includes(kw));
        if (isChat || isExpand) {
          // 优先返回外层的 .operation-item 容器（事件通常绑定在外层）
          // 而不是最内层的 span
          buttons.push({
            text: text,
            element: item,
            isChat: isChat,
            isExpand: isExpand,
            isPrimary: isChat
          });
        }
      });
    }

    // 3. 找 .operation-list 容器（某些页面结构）
    if (!buttons.some(b => b.isChat)) {
      const operationLists = cell.querySelectorAll('.operation-list, [class*="operation-list"]');
      operationLists.forEach(list => {
        const text = (list.textContent || '').trim();
        if (!text) return;
        const isChat = CHAT_BTN_KEYWORDS.some(kw => text.includes(kw));
        const isExpand = EXPAND_BTN_KEYWORDS.some(kw => text.includes(kw));
        if (isChat || isExpand) {
          // 找里面的 operation-item
          const item = list.querySelector('.operation-item, [class*="operation-item"]');
          buttons.push({
            text: text,
            element: item || list,
            isChat: isChat,
            isExpand: isExpand,
            isPrimary: isChat
          });
        }
      });
    }

    // 4. 最终兜底：扫描 cell 内所有元素，找包含"聊天明细"文本的元素
    // 优先选择外层容器而不是最内层的 span
    if (!buttons.some(b => b.isChat)) {
      const allElements = cell.querySelectorAll('div, span, a, button');
      const candidates = [];
      allElements.forEach(el => {
        const text = (el.textContent || '').trim();
        if (text === '聊天明细' || (text.includes('聊天') && text.length <= 12)) {
          candidates.push({
            element: el,
            text: text,
            depth: getElementDepth(el)
          });
        }
      });
      
      // 优先选择层级较浅的元素（外层容器），因为事件绑定通常在外层
      candidates.sort((a, b) => a.depth - b.depth);
      if (candidates.length > 0) {
        const best = candidates[0];
        buttons.push({
          text: best.text,
          element: best.element,
          isChat: true,
          isExpand: false,
          isPrimary: true
        });
      }
    }

    return buttons;
  }

  // 获取元素在DOM中的深度（根节点深度为0）
  function getElementDepth(el) {
    let depth = 0;
    let current = el;
    while (current && current.parentElement && current.parentElement.tagName !== 'BODY') {
      depth++;
      current = current.parentElement;
    }
    return depth;
  }

  // 提取表头
  function extractHeaders(table) {
    const headers = [];
    const headerCells = table.querySelectorAll('thead th, thead td');
    headerCells.forEach((cell, i) => {
      const text = cleanHeader(cell.textContent);
      headers.push({
        index: i,
        text: text,
        isOperation: isOperationHeader(text),
        isProduct: isProductHeader(text),
        isWangwang: isWangwangHeader(text),
        isTime: isTimeHeader(text)
      });
    });

    // 如果没有 thead，用第一行作为表头
    if (headers.length === 0) {
      const firstRow = table.querySelector('tr');
      if (firstRow) {
        firstRow.querySelectorAll('th, td').forEach((cell, i) => {
          const text = cleanHeader(cell.textContent);
          headers.push({
            index: i,
            text: text,
            isOperation: isOperationHeader(text),
            isProduct: isProductHeader(text),
            isWangwang: isWangwangHeader(text),
            isTime: isTimeHeader(text)
          });
        });
      }
    }

    return headers;
  }

  // 提取表格数据（通用）
  function extractTableData() {
    const table = findMainTable();
    if (!table) {
      return { success: false, reason: '未找到表格' };
    }

    const headers = extractHeaders(table);
    if (headers.length === 0) {
      return { success: false, reason: '未找到表头' };
    }

    // 提取数据行：递归取所有 tr（包括嵌套的子行，如树形表格的展开行）
    const rows = [];
    const tbody = table.querySelector('tbody');

    // 递归收集所有行（包括嵌套子行）
    function collectRows(parent, depth = 0) {
      const directRows = parent.querySelectorAll(':scope > tr');
      directRows.forEach((row, rowIndex) => {
        // 跳过表头行
        if (row.querySelector('th')) return;

        const cells = row.querySelectorAll(':scope > td');
        if (cells.length === 0) return;

        recordRow(row, cells, depth, rowIndex);

        // 递归查找子行（树形表格的展开行）
        // 子行通常在 tr 内部或紧邻位置
        const childRows = row.querySelectorAll(':scope > td > tr, :scope tr.ant-table-row-level-1, :scope tr.ant-table-row-level-2');
        if (childRows.length > 0) {
          const childContainer = document.createElement('tbody');
          childRows.forEach(cr => childContainer.appendChild(cr));
          collectRows(childContainer, depth + 1);
        }
      });
    }

    function recordRow(row, cells, depth, rowIndex) {
      // 【关键修复】跳过所有单元格为空的占位行（AntD Table 可能出现的空行）
      const allEmpty = Array.from(cells).every(cell => !(cell.textContent || '').trim());
      if (allEmpty) {
        if (rowIndex < 3) {
          console.log(`[千牛导出] 行${rowIndex}(depth=${depth}): 所有单元格为空，跳过占位行`);
        }
        return;
      }

      const record = {
        _rowIndex: rowIndex,
        _rowDepth: depth,
        _rawCells: [],
        _operationButtons: [],
        _hasChatBtn: false,
        _chatBtn: null
      };

      cells.forEach((cell, i) => {
        const header = headers[i];
        const headerText = header ? header.text : `列${i}`;

        let value;
        if (header && header.isProduct) {
          value = extractProductCell(cell);
        } else if (header && header.isWangwang) {
          value = extractWangwangCell(cell);
        } else if (header && header.isTime) {
          value = extractTimeCell(cell);
        } else {
          value = { text: cell.textContent.trim() };
        }

        record[headerText] = value;
        record._rawCells.push({ header: headerText, value: value });

        // 操作列提取按钮
        if (header && header.isOperation) {
          record._operationButtons = extractOperationButtons(cell);
          const chatBtn = record._operationButtons.find(b => b.isChat);
          if (chatBtn) {
            record._hasChatBtn = true;
            record._chatBtn = chatBtn.element;
          }
        }
      });

      // 如果操作列没识别出来，扫描所有单元格找聊天按钮
      if (!record._hasChatBtn) {
        cells.forEach(cell => {
          const btns = extractOperationButtons(cell);
          const chatBtn = btns.find(b => b.isChat);
          if (chatBtn) {
            record._hasChatBtn = true;
            record._chatBtn = chatBtn.element;
            record._operationButtons = record._operationButtons.concat(btns);
          }
        });
      }

      // 调试日志：每行打印操作列识别情况
      if (rowIndex < 5) {
        console.log(`[千牛导出] 行${rowIndex}(depth=${depth}): hasChatBtn=${record._hasChatBtn}, 操作列=${headers.find(h => h.isOperation)?.text || '未识别'}, 操作按钮文本=${record._operationButtons.map(b => b.text).join(',')}`);
      }

      rows.push(record);
    }

    if (tbody) {
      collectRows(tbody, 0);
    } else {
      const allRows = table.querySelectorAll('tbody > tr, tr');
      allRows.forEach((row, idx) => {
        if (row.querySelector('th')) return;
        const cells = row.querySelectorAll(':scope > td');
        if (cells.length > 0) recordRow(row, cells, 0, idx);
      });
    }

    return {
      success: true,
      headers: headers.map(h => h.text),
      rows: rows,
      totalRows: rows.length
    };
  }

  // 等待元素出现
  function waitForElement(selector, timeout = 3000, parent = document) {
    return new Promise((resolve) => {
      const el = parent.querySelector(selector);
      if (el) {
        resolve(el);
        return;
      }

      const observer = new MutationObserver(() => {
        const el = parent.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });

      observer.observe(parent.body || parent, { childList: true, subtree: true });

      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeout);
    });
  }

  // 找页面中的弹窗/抽屉
  function findActiveModal() {
    // 严格模式：弹窗必须满足以下条件之一：
    // 1. 在 .ant-modal-wrap:not(.ant-modal-hidden) 或 .el-dialog__wrapper:not(.is-closing) 内部
    // 2. 是 fixed/absolute 定位，尺寸 >= 200x150，且有丰富内容
    function isRealModal(el) {
      if (!el) return false;
      // 必须可见
      if (!isElementVisible(el)) return false;
      // 尺寸检查
      const rect = el.getBoundingClientRect();
      if (rect.width < 150 || rect.height < 100) return false;
      // 内容检查
      const html = el.innerHTML || '';
      if (html.length < 200) return false;
      // 定位检查：要么在已知弹窗框架内，要么是 fixed/absolute 定位
      const isInKnownWrap = el.closest('.ant-modal-wrap, .el-dialog__wrapper, .ant-drawer') !== null;
      const style = window.getComputedStyle(el);
      const isFixedOrAbs = style.position === 'fixed' || style.position === 'absolute';
      if (!isInKnownWrap && !isFixedOrAbs) return false;
      return true;
    }

    // 策略1：找已打开状态的 Ant Design / Element UI 弹窗内容区
    const primarySelectors = [
      '.ant-modal-wrap:not(.ant-modal-hidden) .ant-modal-content',
      '.ant-modal-wrap:not(.ant-modal-hidden) .ant-modal',
      '.el-dialog__wrapper:not(.is-closing) .el-dialog',
      '.ant-drawer:not(.ant-drawer-close) .ant-drawer-content'
    ];
    for (const sel of primarySelectors) {
      const el = document.querySelector(sel);
      if (el && isRealModal(el)) return el;
    }

    // 策略2：找弹窗 body 区域
    const bodySelectors = [
      '.ant-modal-body',
      '.el-dialog__body',
      '.ant-drawer-body',
      '.oui-dialog-content',
      '.sycm-modal-content',
      '.sycm-dialog-content',
      '.qnc-dialog-content',
      '.chat-detail-modal',
      '.message-detail-modal'
    ];
    for (const sel of bodySelectors) {
      const el = document.querySelector(sel);
      if (el && isRealModal(el)) return el;
    }

    // 策略3：找遮罩层 + 相邻弹窗
    const masks = document.querySelectorAll('.ant-modal-mask, .ant-drawer-mask, [class*="modal-mask"]');
    for (const mask of masks) {
      if (!isElementVisible(mask)) continue;
      const mStyle = window.getComputedStyle(mask);
      const mRect = mask.getBoundingClientRect();
      if ((mStyle.position === 'fixed' || mStyle.position === 'absolute') &&
          mRect.width >= window.innerWidth * 0.5 && mRect.height >= window.innerHeight * 0.5) {
        // 找相邻的 modal-wrap
        const sibling = mask.nextElementSibling;
        if (sibling) {
          const content = sibling.querySelector('.ant-modal-content');
          if (content && isRealModal(content)) return content;
          if (isRealModal(sibling)) return sibling;
        }
        // 找父元素内的弹窗
        const parent = mask.parentElement;
        if (parent) {
          const content = parent.querySelector('.ant-modal-content, .ant-drawer-content, [class*="modal-content"]');
          if (content && isRealModal(content)) return content;
        }
      }
    }

    // 策略4：找 z-index 最高的弹窗相关容器
    const wraps = document.querySelectorAll('.ant-modal-wrap, .ant-drawer, [class*="dialog-wrap"], [class*="modal-wrap"]');
    let maxZ = 0, maxEl = null;
    for (const wrap of wraps) {
      const z = parseInt(window.getComputedStyle(wrap).zIndex, 10);
      if (!isNaN(z) && z > maxZ && isElementVisible(wrap)) {
        const content = wrap.querySelector('.ant-modal-content, .ant-drawer-content, [class*="dialog-content"]');
        if (content && isRealModal(content)) {
          maxZ = z; maxEl = content;
        } else if (isRealModal(wrap)) {
          maxZ = z; maxEl = wrap;
        }
      }
    }
    if (maxEl) return maxEl;

    // 策略5：找包含"聊天明细"/"聊天记录"文本的 fixed/absolute 大容器
    const chatContainers = document.querySelectorAll('div, section');
    for (const container of chatContainers) {
      if (!isElementVisible(container)) continue;
      const rect = container.getBoundingClientRect();
      const style = window.getComputedStyle(container);
      if ((style.position === 'fixed' || style.position === 'absolute') &&
          rect.width > 300 && rect.height > 200) {
        const text = container.textContent || '';
        if ((text.includes('聊天明细') || text.includes('聊天记录')) && text.length > 100) {
          return container;
        }
      }
    }

    // 没有真正弹窗时返回 null（不再兜底返回页面元素）
    return null;
  }

  // 关闭弹窗
  async function closeActiveModal() {
    // 策略：先尝试让框架自然关闭弹窗，再兜底隐藏
    const visibleWraps = Array.from(document.querySelectorAll('.ant-modal-wrap, .el-dialog__wrapper, [class*="modal-wrap"]'))
      .filter(wrap => isElementVisible(wrap));

    for (const wrap of visibleWraps) {
      // 方式1：找到关闭按钮，用原生 click() 触发（比 dispatchEvent 更能触发框架监听器）
      const closeBtn = wrap.querySelector('.ant-modal-close, .el-dialog__headerbtn, [aria-label="Close"], .ant-modal-close-x, [class*="close"]');
      if (closeBtn && isElementVisible(closeBtn)) {
        try {
          closeBtn.click();
        } catch (e) {}
      }
      // 也尝试点击弹窗遮罩层来关闭（某些框架支持点击遮罩关闭）
      const mask = wrap.querySelector('.ant-modal-mask, .el-dialog__mask, [class*="modal-mask"]');
      if (mask && isElementVisible(mask)) {
        try {
          // 在弹窗区域外点击遮罩
          mask.click();
        } catch (e) {}
      }
    }

    // 等待框架处理关闭
    await sleep(500);

    // 方式2：如果弹窗还在，尝试按 Escape 键
    const stillVisible = Array.from(document.querySelectorAll('.ant-modal-wrap, .el-dialog__wrapper, [class*="modal-wrap"]'))
      .filter(wrap => isElementVisible(wrap));
    if (stillVisible.length > 0) {
      try {
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      } catch (e) {}
      await sleep(300);
    }

    // 方式3：兜底 - 强制隐藏仍然可见的弹窗和遮罩
    document.querySelectorAll('.ant-modal-wrap, .el-dialog__wrapper, [class*="modal-wrap"]').forEach(wrap => {
      if (isElementVisible(wrap)) {
        wrap.style.display = 'none';
      }
    });
    document.querySelectorAll('.ant-modal-mask, .el-dialog__mask, [class*="modal-mask"]').forEach(mask => {
      if (isElementVisible(mask)) {
        mask.style.display = 'none';
      }
    });

    // 方式4：清理 body 上的 overflow hidden（弹窗打开时会锁定滚动）
    document.body.style.overflow = '';

    await sleep(200);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 模拟真实用户点击事件序列
  // 核心原则：只使用原生 click()，不手动派发 click 事件
  // 之前同时派发原生 click + MouseEvent('click') 导致重复触发
  function simulateClick(element) {
    if (!element) return;

    // 1. 确保元素在视口内且可见
    try {
      element.scrollIntoView({ behavior: 'instant', block: 'center' });
    } catch (e) {
      try { element.style.visibility = 'visible'; element.style.opacity = '1'; } catch (e2) {}
    }

    // 2. 只使用原生 click()，这是最可靠的方式
    //    Vue/React 的 onClick 都能正确捕获原生 click
    const innerClickable = findDeepestClickable(element);
    if (innerClickable && innerClickable !== element) {
      try { innerClickable.click(); } catch (e) {}
    }
    try { element.click(); } catch (e) {}
  }

  // 找到元素内最深层的可点击元素（SPAN/A/BUTTON 且有文本）
  function findDeepestClickable(element) {
    if (!element) return null;
    
    // 优先级：button > a > span[role=button] > span（带 cursor:pointer 或有文本）
    const candidates = [];
    
    // 1. 找 button / a
    element.querySelectorAll('button, a').forEach(el => {
      const text = (el.textContent || '').trim();
      if (text && text.length < 100) {
        candidates.push({ el, depth: getDepth(element, el), priority: 10 });
      }
    });
    
    // 2. 找 span[role="button"]
    element.querySelectorAll('[role="button"]').forEach(el => {
      const text = (el.textContent || '').trim();
      if (text && text.length < 100) {
        candidates.push({ el, depth: getDepth(element, el), priority: 8 });
      }
    });
    
    // 3. 找带 cursor: pointer 样式的元素
    element.querySelectorAll('*').forEach(el => {
      try {
        const style = window.getComputedStyle(el);
        if (style.cursor === 'pointer') {
          const text = (el.textContent || '').trim();
          if (text && text.length < 100) {
            candidates.push({ el, depth: getDepth(element, el), priority: 5 });
          }
        }
      } catch (e) {}
    });
    
    // 4. 找最内层的有文本的 span
    element.querySelectorAll('span').forEach(el => {
      // 只考虑叶子 span（没有子 span）
      if (el.querySelector('span')) return;
      const text = (el.textContent || '').trim();
      if (text && text.length > 1 && text.length < 50) {
        candidates.push({ el, depth: getDepth(element, el), priority: 1 });
      }
    });
    
    if (candidates.length === 0) return null;
    
    // 按 priority 降序、depth 降序（越深越好）排序
    candidates.sort((a, b) => {
      if (b.priority !== a.priority) return b.priority - a.priority;
      return b.depth - a.depth;
    });
    
    return candidates[0].el;
  }
  
  // 计算元素在父元素树中的深度
  function getDepth(root, el) {
    let depth = 0;
    let current = el;
    while (current && current !== root) {
      depth++;
      current = current.parentElement;
    }
    return depth;
  }

  function triggerMouseEvents(element) {
    if (!element) return;
    // 只使用原生 click()，不再手动派发事件
    try { element.click(); } catch (e) {}
  }

  // 从弹窗标题/头部提取旺旺
  function extractBuyerFromModalHeader(modal) {
    if (!modal) return '';

    // 1. 标题
    const titleEl = modal.querySelector('.ant-modal-title, .ant-drawer-title, [class*="modal-title"], [class*="dialog-title"]');
    if (titleEl) {
      const text = titleEl.textContent;
      const match = text.match(/与\s*([^\s]+)\s*的/) || text.match(/([^\s]{2,20})\s*的聊天/) || text.match(/旺旺[:：]\s*([^\s]+)/);
      if (match && isValidBuyerWangwang(match[1].trim())) return match[1].trim();
    }

    // 2. 头部信息区
    const headerEls = modal.querySelectorAll('.ant-modal-header, .ant-drawer-header, [class*="header"], [class*="info"]');
    for (const header of headerEls) {
      const text = header.textContent;
      const match = text.match(/买家旺旺[:：]\s*([^\s]+)/) ||
                    text.match(/买家[:：]\s*([^\s]+)/) ||
                    text.match(/旺旺[:：]\s*([^\s]+)/);
      if (match && isValidBuyerWangwang(match[1].trim())) return match[1].trim();
    }

    return '';
  }

  // 判断一个字符串是否是有效的买家旺旺（不是客服子账号、不是脱敏值）
  function isValidBuyerWangwang(s) {
    if (!s || typeof s !== 'string') return false;
    let v = s.trim();
    // 去除零宽字符和不可见控制字符，避免"驰腾\ufeff"绕过校验
    v = v.replace(/[\u200B-\u200F\uFEFF\u00A0\u00AD\u2028\u2029\u2060]/g, '');
    if (!v || v.includes('*')) return false;
    if (v.includes('旗舰店') || v.includes('专营店') || v.includes('专卖店')) return false;
    if (v.includes('客服') || v.includes('接待')) return false;
    if (v.includes('：') || v.includes(':')) return false;
    if (v.includes('聊天') || v.includes('对象') || v.includes('内容') || v.includes('时间')) return false;
    if (v === '买家' || v === '买家旺旺' || v === '客服旺旺' || v === '发送人') return false;
    if (v === '客户昵称' || v === '昵称' || v === '客户' || v === '消息') return false;
    // 过滤 1-4 个纯中文字符（店铺名简称，如"驰腾"）
    if (/^[\u4e00-\u9fa5]{1,4}$/.test(v)) return false;
    // 过滤系统短语
    const systemPhrases = ['将为您服务', '为您服务', '人工客服', '欢迎您光临本店', '欢迎光临', '稍等', '马上为您', '辛苦', '请稍候'];
    if (systemPhrases.some(p => v.includes(p))) return false;
    // 过滤URL域名
    const urlDomains = ['alicdn', 'taobao', 'cloud', 'video', 'imgextra', 'http', 'https', 'www', 'com', 'cn', 'mp4', 'jpg', 'png'];
    if (urlDomains.some(d => v.toLowerCase() === d || v.toLowerCase().includes(d + '.'))) return false;
    // 过滤包含空格的
    if (v.includes(' ') || v.includes('　')) return false;

    const wwRegexes = [
      /^tb[\w_]{3,15}$/i,
      /^[a-zA-Z_]{2,}\d{2,}$/,
      /^[\u4e00-\u9fa5]{5,10}$/,
      /^[\u4e00-\u9fa5]{1,5}[a-zA-Z0-9_]{1,15}$/,
      /^[a-zA-Z_]{2,}[\u4e00-\u9fa5]{1,5}$/,
      /^[a-zA-Z]_\d+_\d+$/,  // t_1501047164607_019 格式
    ];
    if (!wwRegexes.some(p => p.test(v))) return false;

    // 拒绝中文字符超过5个的混合字符串
    const chineseCount = (v.match(/[\u4e00-\u9fa5]/g) || []).length;
    const nonChineseCount = v.length - chineseCount;
    if (chineseCount > 5 && nonChineseCount > 0) return false;
    if (chineseCount > 10) return false;

    return v.length >= 2 && v.length <= 25;
  }

  // 判断是否是脱敏的旺旺名（包含 * 但格式合理，可以作为备选显示）
  function isMaskedBuyerWangwang(s) {
    if (!s || typeof s !== 'string') return false;
    let v = s.trim();
    v = v.replace(/[\u200B-\u200F\uFEFF\u00A0\u00AD\u2028\u2029\u2060]/g, '');
    if (!v || !v.includes('*')) return false;
    if (v.includes('旗舰店') || v.includes('专营店') || v.includes('专卖店')) return false;
    if (v.includes('客服') || v.includes('接待')) return false;
    if (v.includes('：') || v.includes(':')) return false;
    if (v.includes('聊天') || v.includes('对象') || v.includes('内容') || v.includes('时间')) return false;
    if (v === '买家' || v === '买家旺旺' || v === '客服旺旺' || v === '发送人') return false;
    if (v === '客户昵称' || v === '昵称' || v === '客户' || v === '消息') return false;
    // 脱敏旺旺名长度合理（2-25字符）
    return v.length >= 2 && v.length <= 25;
  }

  // 从弹窗内的详情表格提取买家旺旺和关键信息
  function extractDetailTableInfo(modal) {
    const info = { buyerWangwang: '', staffWangwang: '', startTime: '', endTime: '', date: '', status: '' };
    if (!modal) return info;

    // 1. 从表格提取
    const tables = modal.querySelectorAll('table');
    for (const table of tables) {
      const headerRow = table.querySelector('thead tr') || table.querySelector('tr');
      if (!headerRow) continue;

      const cells = headerRow.querySelectorAll('th, td');
      const headers = Array.from(cells).map(c => cleanHeader(c.textContent));

      // 严格列匹配：买家旺旺和客服旺旺必须明确区分
      let idxBuyer = -1;
      let idxStaff = -1;
      for (let i = 0; i < headers.length; i++) {
        if (headers[i] === '买家旺旺' || headers[i].includes('买家旺旺')) { idxBuyer = i; }
        if (headers[i].includes('客服旺旺') || headers[i].includes('接待客服')) { idxStaff = i; }
      }
      const idxStart = headers.findIndex(h => h.includes('开始时间'));
      const idxEnd = headers.findIndex(h => h.includes('结束时间'));
      const idxDate = headers.findIndex(h => h.includes('日期'));
      const idxStatus = headers.findIndex(h => h.includes('状态') || h.includes('订单状态'));

      // 表头识别到关键列才视为详情表
      if (idxBuyer >= 0 || idxStaff >= 0 || idxStart >= 0 || idxEnd >= 0 || idxDate >= 0 || idxStatus >= 0) {
        const dataRows = table.querySelectorAll('tbody tr');
        for (const row of dataRows) {
          const rowCells = row.querySelectorAll('td');
          if (rowCells.length < Math.max(idxBuyer, idxStaff, idxStart, idxEnd, idxDate, idxStatus, 0) + 1) continue;

          if (idxBuyer >= 0) {
            const v = rowCells[idxBuyer].textContent.trim();
            if (isValidBuyerWangwang(v)) {
              info.buyerWangwang = v;
            } else if (isMaskedBuyerWangwang(v)) {
              // 脱敏但有效的旺旺名，保留作为备选
              info.buyerWangwang = v;
            }
          }
          if (idxStaff >= 0 && !info.staffWangwang) {
            info.staffWangwang = rowCells[idxStaff].textContent.trim();
          }
          if (idxStart >= 0 && !info.startTime) {
            info.startTime = extractTimeCell(rowCells[idxStart]).datetime;
          }
          if (idxEnd >= 0 && !info.endTime) {
            info.endTime = extractTimeCell(rowCells[idxEnd]).datetime;
          }
          if (idxDate >= 0 && !info.date) {
            info.date = rowCells[idxDate].textContent.trim();
          }
          if (idxStatus >= 0 && !info.status) {
            info.status = rowCells[idxStatus].textContent.trim();
          }

          // 通用提取：遍历所有单元格，生成 key-value 对（但不再把客服旺旺当买家旺旺）
          for (let i = 0; i < headers.length && i < rowCells.length; i++) {
            const key = headers[i];
            const val = rowCells[i].textContent.trim();
            if (!key || !val) continue;
            if (key.includes('客服') || key.includes('买家旺旺')) continue; // 这两类单独处理
            if (!info[key]) {
              info[key] = val;
            }
          }
        }
      }
    }

    // 2. 处理 label-value 形式（非表格）：如"买家旺旺：t** 客服旺旺：驰小念"横排结构
    // 遍历弹窗所有叶子文本节点，寻找 "买家旺旺" 和 "客服旺旺" 标签后的值
    if (!info.buyerWangwang) {
      const labelValuePairs = extractLabelValuePairsFromModal(modal);
      if (labelValuePairs.buyerWangwang) info.buyerWangwang = labelValuePairs.buyerWangwang;
      if (labelValuePairs.staffWangwang && !info.staffWangwang) info.staffWangwang = labelValuePairs.staffWangwang;
      if (labelValuePairs.date && !info.date) info.date = labelValuePairs.date;
      if (labelValuePairs.startTime && !info.startTime) info.startTime = labelValuePairs.startTime;
      if (labelValuePairs.endTime && !info.endTime) info.endTime = labelValuePairs.endTime;
      if (labelValuePairs.status && !info.status) info.status = labelValuePairs.status;
    }

    // 3. 如果买家旺旺无效，尝试从其他来源获取；如果是脱敏的，保留作为备选
    if (!isValidBuyerWangwang(info.buyerWangwang)) {
      if (isMaskedBuyerWangwang(info.buyerWangwang)) {
        // 脱敏的旺旺名，保留作为备选
        console.log('[千牛导出] 保留脱敏买家旺旺:', info.buyerWangwang);
      } else {
        info.buyerWangwang = '';
      }
    }

    return info;
  }

  // 从弹窗中以 label-value 形式提取（横排的"买家旺旺：xxx"结构）
  function extractLabelValuePairsFromModal(modal) {
    const result = { buyerWangwang: '', staffWangwang: '', date: '', startTime: '', endTime: '', status: '' };
    if (!modal) return result;
    
    // 遍历所有可能的容器，查找包含"买家旺旺"标签的元素
    const allDescendants = modal.querySelectorAll('div, span, td, p, label');
    for (const el of allDescendants) {
      // 只看叶子元素或浅嵌套元素（避免抓到整行文本）
      const directText = Array.from(el.childNodes)
        .filter(n => n.nodeType === 3)
        .map(n => n.textContent)
        .join('')
        .trim();
      
      if (!directText) continue;
      
      // 匹配"买家旺旺：xxx"或"买家旺旺 xxx"
      const buyerMatch = directText.match(/买家旺旺[:：]\s*(\S+)/);
      if (buyerMatch && !result.buyerWangwang) {
        const v = buyerMatch[1].trim();
        if (v && (isValidBuyerWangwang(v) || isMaskedBuyerWangwang(v))) {
          result.buyerWangwang = v;
        }
      }
      
      const staffMatch = directText.match(/客服旺旺[:：]\s*(\S+)/);
      if (staffMatch && !result.staffWangwang) {
        result.staffWangwang = staffMatch[1].trim();
      }
      
      const dateMatch = directText.match(/日期[:：]\s*(\S+)/);
      if (dateMatch && !result.date) {
        result.date = dateMatch[1].trim();
      }
      
      const startMatch = directText.match(/开始时间[:：]\s*(\S+)/);
      if (startMatch && !result.startTime) {
        result.startTime = startMatch[1].trim();
      }
      
      const endMatch = directText.match(/结束时间[:：]\s*(\S+)/);
      if (endMatch && !result.endTime) {
        result.endTime = endMatch[1].trim();
      }
      
      const statusMatch = directText.match(/(?:订单)?状态[:：]\s*(\S+)/);
      if (statusMatch && !result.status) {
        result.status = statusMatch[1].trim();
      }
    }
    
    return result;
  }

  // 从文本中提取真实旺旺ID（不包含星号）
  function extractRealWangwangFromText(text) {
    if (!text) return '';

    // 旺旺ID格式校验：必须符合标准格式
    const isWangwang = (s) => {
      if (!s || s.length < 2 || s.length > 20) return false;
      if (s.includes('*')) return false;
      if (s.includes('聊天')) return false;
      if (s.includes('对象')) return false;
      if (s.includes('内容')) return false;
      if (s.includes('时间')) return false;
      if (s.includes('买家')) return false;
      if (s.includes('客服')) return false;
      if (s.includes('旗舰店')) return false;
      if (s.includes('专营店') || s.includes('专卖店')) return false;
      if (s.includes('：') || s.includes(':')) return false;
      // 排除"买家"、单字中文、店铺名简称（如"驰腾"）
      if (/^[\u4e00-\u9fa5]{1,4}$/.test(s)) return false;
      if (s === '买家' || s === '客户' || s === '客服' || s === '旺旺') return false;
      // 旺旺格式：纯英文数字下划线，或纯中文(>=5字)，或英文+中文组合
      return /^[a-zA-Z0-9_]{2,20}$/.test(s) || 
             /^[\u4e00-\u9fa5]{5,20}$/.test(s) ||
             /^[a-zA-Z0-9_]{2,12}[\u4e00-\u9fa5]{1,8}$/.test(s) ||
             /^[\u4e00-\u9fa5]{1,5}[a-zA-Z0-9_]{1,12}$/.test(s);
    };

    // 严格匹配：只提取明确标记为"买家旺旺：xxx"的（排除带星号的）
    const buyerWangwangMatch = text.match(/买家旺旺[：:]\s*([^\s。，,]{2,20})/);
    if (buyerWangwangMatch) {
      const v = buyerWangwangMatch[1].trim();
      if (v && !v.includes('*') && isWangwang(v)) {
        return v;
      }
    }

    // 排除"聊天对象"开头的误匹配（聊天对象是消息列不是买家旺旺来源）
    return '';
  }

  // 通用聊天记录提取（支持 iframe 和 shadow DOM）
  function extractChatMessages(modal) {
    const messages = [];
    const seen = new Set();
    let realBuyerWangwang = '';
    let realStaffWangwang = '';

    if (!modal) return { messages, realBuyerWangwang, realStaffWangwang };

    // 调试日志：输出弹窗DOM结构，帮助排查发送人提取问题
    try {
      const modalClass = modal.className || '';
      const modalHtml = modal.innerHTML || '';
      console.log('[千牛导出] extractChatMessages开始: modalClass=', modalClass.substring(0, 100));
      console.log('[千牛导出] modal HTML长度=', modalHtml.length);
      // 输出前2000字符的HTML结构，帮助识别DOM结构
      if (modalHtml.length > 0) {
        console.log('[千牛导出] modal结构预览:', modalHtml.substring(0, 2000));
      }
      // 检查iframe
      const iframes = modal.querySelectorAll('iframe');
      console.log('[千牛导出] modal内iframe数量=', iframes.length);
      iframes.forEach((iframe, i) => {
        try {
          if (iframe.contentDocument) {
            const iframeBody = iframe.contentDocument.body;
            const iframeHtml = iframeBody ? iframeBody.innerHTML : '';
            console.log(`[千牛导出] iframe[${i}] HTML长度=`, iframeHtml.length, '预览:', iframeHtml.substring(0, 1500));
          }
        } catch(e) {
          console.log(`[千牛导出] iframe[${i}] 跨域无法访问`);
        }
      });
    } catch(e) {}

    // 从弹窗顶部提取客服旺旺（"客服旺旺：驰小卷"）
    function extractStaffWangwangFromHeader(modal) {
      const allText = modal.textContent || '';
      // 方式1：匹配 "客服旺旺：xxx"
      const match1 = allText.match(/客服旺旺[：:]\s*([^\s]+)/);
      if (match1 && !match1[1].includes('*') && match1[1].length > 1 && match1[1].length <= 25) {
        return match1[1].trim();
      }
      // 方式2：匹配 "接待：xxx" 或 "接待客服：xxx"
      const match2 = allText.match(/(?:接待客服|接待)[：:]\s*([^\s]+)/);
      if (match2 && !match2[1].includes('*') && match2[1].length > 1 && match2[1].length <= 25) {
        return match2[1].trim();
      }
      // 方式3：从 low-chat-bar-meta 中提取
      const barMetas = modal.querySelectorAll('.low-chat-bar-meta');
      for (const meta of barMetas) {
        const text = meta.textContent.trim();
        const m = text.match(/(?:客服旺旺|接待客服|接待)[：:]\s*([^\s]+)/);
        if (m && !m[1].includes('*') && m[1].length > 1 && m[1].length <= 25) {
          return m[1].trim();
        }
      }
      // 方式4：从 ChatLog_bar（CSS Modules）中提取
      const chatLogMetas = modal.querySelectorAll('[class*="ChatLog_meta"]');
      for (const meta of chatLogMetas) {
        const text = meta.textContent.trim();
        const m = text.match(/(?:客服旺旺|接待客服|接待)[：:]\s*([^\s]+)/);
        if (m && !m[1].includes('*') && m[1].length > 1 && m[1].length <= 25) {
          return m[1].trim();
        }
      }
      return '';
    }

    // 从弹窗顶部提取买家旺旺（"买家旺旺：xxx"）
    function extractBuyerWangwangFromHeader(modal) {
      const allText = modal.textContent || '';
      const match = allText.match(/买家旺旺[：:]\s*([^\s]+)/);
      if (match && !match[1].includes('*') && match[1].length > 1 && isValidBuyerWangwang(match[1].trim())) {
        return match[1].trim();
      }
      return '';
    }

    // 从弹窗头部提取的旺旺（在提取聊天记录前调用）
    realStaffWangwang = extractStaffWangwangFromHeader(modal);
    const headerBuyerWw = extractBuyerWangwangFromHeader(modal);

    // 判断角色：基于客服旺旺匹配
    function getRoleFromSender(sender) {
      if (!sender) return lastRole || 'buyer';
      const senderClean = sender.trim();

      // 排除通用标签词（不是真实旺旺）
      const nonWwLabels = ['买家', '客服', '买家旺旺', '客服旺旺', '发送人', '客户昵称', '昵称', '客户'];
      if (nonWwLabels.includes(senderClean)) return lastRole || 'buyer';

      // 包含店铺名关键词的一定是 staff
      if (senderClean.includes('旗舰店') || senderClean.includes('专营店') || senderClean.includes('专卖店')) {
        return 'staff';
      }

      if (realStaffWangwang) {
        const staffClean = realStaffWangwang.trim();
        if (senderClean === staffClean) return 'staff';
        if (senderClean.includes(staffClean) && senderClean.length <= staffClean.length + 10) return 'staff';
        if (staffClean.includes(senderClean) && senderClean.length > 1) return 'staff';

        // 格式："店铺名:客服名" → 提取冒号后匹配
        const colonMatch = senderClean.match(/[:：]\s*(.+)$/);
        if (colonMatch) {
          const name = colonMatch[1].trim();
          if (name === staffClean || name.includes(staffClean)) return 'staff';
        }
        return 'buyer';
      }

      if (senderClean.includes('旗舰店') || senderClean.includes('专营店') || senderClean.includes('专卖店')) {
        return 'staff';
      }

      // 长度合理且不包含通用标签 → 更可能是买家
      if (senderClean.length >= 2 && senderClean.length <= 20) {
        return 'buyer';
      }

      return lastRole || 'buyer';
    }

    // 从聊天对象中提取真实旺旺
    function extractWangwangFromSender(sender) {
      if (!sender) return '';
      const s = sender.trim();
      // 排除店铺名称和标签
      if (s.includes('旗舰店') || s.includes('专营店') || s.includes('专卖店')) {
        return '';
      }
      if (['买家', '客服', '发送人', '客户昵称', '昵称', '客户', '消息'].includes(s)) {
        return '';
      }
      // 过滤 1-4 个纯中文字符（店铺名简称，如"驰腾"）
      if (/^[\u4e00-\u9fa5]{1,4}$/.test(s)) return '';
      // 常见格式："店铺名:旺旺名" 或 "旺旺名"
      const colonMatch = s.match(/[:：]\s*([a-zA-Z0-9_\u4e00-\u9fa5]{2,20})/);
      if (colonMatch && !colonMatch[1].includes('*')) {
        const name = colonMatch[1].trim();
        if (isValidBuyerWangwang(name)) return name;
      }
      // 直接是旺旺名
      if (isValidBuyerWangwang(s)) return s;
      return '';
    }

    let lastRole = 'buyer'; // 用于推断发送人为空的消息角色

    function addMessage(sender, content, time) {
      if (!content || content.length < 1) return;

      const invalidTexts = ['聊天明细', '聊天对象', '聊天内容', '聊天时间', '买家旺旺', '客服旺旺', '咨询发起类型', '日期', '开始时间', '结束时间', '消息列表', '加载更多', '查看更多'];
      if (invalidTexts.includes(content)) return;
      if (/^https?:\/\/[^\s]+$/.test(content) && content.length < 30) return;

      const invalidLabels = ['买家', '客服', '买家旺旺', '客服旺旺', '发送人', '客户昵称', '昵称', '客户', '消息', '查看更多', '加载更多'];
      
      function extractValidWw(text) {
        if (!text) return '';
        const t = text.trim();
        if (!t) return '';
        
        const colonMatch = t.match(/[:：]\s*([a-zA-Z0-9_\u4e00-\u9fa5]{2,20})$/);
        if (colonMatch) {
          const name = colonMatch[1].trim();
          if (!invalidLabels.includes(name) && !name.includes('*')) return name;
        }
        
        const wwRegexes = [
          /^tb[\w_]{3,15}$/i,
          /^[a-zA-Z_]{2,}\d*$/,
          /^[\u4e00-\u9fa5]{2,10}$/,
          /^[\u4e00-\u9fa5]{1,5}[a-zA-Z0-9_]{1,15}$/,
          /^[a-zA-Z_]{2,}[\u4e00-\u9fa5]{1,5}$/,
          /^[\u4e00-\u9fa5a-zA-Z0-9_]{2,25}$/,
        ];
        
        if (!invalidLabels.includes(t) && !t.includes('*') && wwRegexes.some(p => p.test(t))) {
          return t;
        }
        
        const parts = t.split(/[\s,，、;；]+/);
        for (const part of parts) {
          const p = part.trim();
          if (!p || invalidLabels.includes(p) || p.includes('*')) continue;
          // 过滤 1-4 个纯中文字符（店铺名简称，如"驰腾"）
          if (/^[\u4e00-\u9fa5]{1,4}$/.test(p)) continue;
          if (wwRegexes.some(re => re.test(p))) return p;
        }
        
        return '';
      }

      const rawSender = (sender || '').trim();
      
      // 防污染：如果 rawSender 包含表头关键词或过长，说明DOM提取错误，清空
      if (rawSender.includes('聊天对象') || rawSender.includes('聊天内容') || rawSender.includes('聊天时间') || rawSender.length > 30) {
        sender = '';
      }
      const cleanRawSender = (sender || '').trim();
      
      // 判断是否是"店铺名:客服名"格式（如"驰腾旗舰店:驰小美"）
      const shopColonMatch = cleanRawSender.match(/^(.+?(?:旗舰店|专营店|专卖店|官方店))[:：](.+)$/);
      const isShopColonFormat = !!shopColonMatch;
      
      // 关键修复：如果 cleanRawSender 中包含店铺名/客服关键词，整条消息应识别为 staff
      const hasShopKeyword = /旗舰店|专营店|专卖店|客服|接待/.test(cleanRawSender);
      
      let cleanedSender = '';
      if (isShopColonFormat) {
        // 保留"店铺名:客服名"完整格式
        cleanedSender = cleanRawSender;
      } else if (!hasShopKeyword) {
        cleanedSender = cleanRawSender
          .replace(/聊天明细|聊天对象|聊天内容|聊天时间|买家旺旺|客服旺旺|咨询发起类型|日期|开始时间|结束时间|买家|客服|发送人|客户昵称|昵称|客户|消息/g, ' ')
          .replace(/[:：]/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();
      }
      
      const validWw = extractValidWw(cleanedSender) || extractValidWw(cleanRawSender);
      if (validWw && !hasShopKeyword && !isShopColonFormat) {
        cleanedSender = validWw;
      } else if (!cleanedSender || invalidLabels.includes(cleanedSender)) {
        cleanedSender = '';
      }

      const key = `${cleanedSender}|${content}|${time}`;
      if (seen.has(key)) return;

      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.content === content) {
        return;
      }

      seen.add(key);

      let role;
      if (hasShopKeyword) {
        role = 'staff';
      } else {
        role = getRoleFromSender(cleanedSender);
        if (!cleanedSender && role === 'buyer' && realStaffWangwang && lastRole === 'staff') {
          role = 'staff';
        } else if (!cleanedSender) {
          role = lastRole || 'buyer';
        }
      }
      lastRole = role;
      
      if (role === 'buyer' && !realBuyerWangwang && cleanedSender) {
        const ww = extractWangwangFromSender(cleanedSender) || validWw;
        if (ww && isValidBuyerWangwang(ww)) realBuyerWangwang = ww;
      }

      let displaySender = cleanedSender;
      if (!displaySender || displaySender.length > 30) {
        if (realStaffWangwang && role === 'staff') {
          displaySender = realStaffWangwang;
        } else if (realBuyerWangwang && role === 'buyer') {
          displaySender = realBuyerWangwang;
        } else if (validWw) {
          displaySender = validWw;
        } else {
          displaySender = '';
        }
      }

      messages.push({
        date: time ? time.split(/\s+/)[0] : '',
        time: time || '',
        sender: displaySender || '',
        role: role,
        content: content
      });
    }

    // 方式0：生意参谋 low-chat 自定义组件结构（最常见）
    // 结构：.low-chat-container > .low-chat-bar(含客服旺旺) > .low-chat-table > .low-chat-scroll > .low-chat-tbody > .low-chat-row
    try {
      let lowChatContainers = getAllElementsIncludingIframes(modal, '.low-chat-container');
      // 去重：同一个容器可能在 iframe 和主文档中各有一份（内容相同但 DOM 对象不同）
      const uniqueContainers = [];
      const seenHtml = new Set();
      for (const container of lowChatContainers) {
        try {
          // 用文本内容去重更稳定，避免 outerHTML 因属性顺序略有差异
          const text = container.textContent.substring(0, 300);
          if (!seenHtml.has(text)) {
            seenHtml.add(text);
            uniqueContainers.push(container);
          }
        } catch (e) {
          uniqueContainers.push(container);
        }
      }
      lowChatContainers = uniqueContainers;

      for (const container of lowChatContainers) {
        // 从 low-chat-bar 提取客服旺旺
        const barMetaEls = container.querySelectorAll('.low-chat-bar-meta');
        barMetaEls.forEach(meta => {
          const text = meta.textContent.trim();
          if (text.includes('客服旺旺') && !realStaffWangwang) {
            const m = text.match(/客服旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*')) realStaffWangwang = m[1].trim();
          }
          if (text.includes('买家旺旺') && !realBuyerWangwang) {
            const m = text.match(/买家旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*') && isValidBuyerWangwang(m[1].trim())) {
              realBuyerWangwang = m[1].trim();
            }
          }
        });

        const tbody = container.querySelector('.low-chat-tbody');
        if (tbody) {
          let rows = tbody.querySelectorAll(':scope > .low-chat-row');
          if (rows.length === 0) {
            rows = tbody.querySelectorAll('.low-chat-row');
            console.log('[千牛导出] low-chat: :scope选择0行，回退到全选', rows.length, '行');
          }
          console.log('[千牛导出] low-chat: 外层行数=', rows.length, '客服旺旺=', realStaffWangwang);
          let extractCount = 0;
          rows.forEach((row, idx) => {
            const nameEl = row.querySelector(':scope > .low-chat-name');
            const composeCell = row.querySelector(':scope > .low-chat-composeCell');

            let sender = '';
            if (nameEl) {
              // 优先取直接文本节点，避免innerText获取嵌套元素文本
              const directText = Array.from(nameEl.childNodes)
                .filter(n => n.nodeType === 3)
                .map(n => n.textContent)
                .join('')
                .trim();
              if (directText) {
                sender = directText;
              } else {
                // 兜底用 textContent（不是 innerText，避免获取隐藏元素文本）
                sender = (nameEl.textContent || '').trim();
              }
              // 防污染：如果sender包含表头关键词或过长，说明提取错误
              if (sender.includes('聊天对象') || sender.includes('聊天内容') || sender.includes('聊天时间') || sender.length > 30) {
                console.log(`[千牛导出] 行${idx}: 发送人被防污染清除 "${sender.substring(0, 50)}"`);
                sender = '';
              }
            }

            // 从composeCell中提取所有内层行的消息
            if (composeCell) {
              const innerRows = composeCell.querySelectorAll('.low-chat-row');
              innerRows.forEach(innerRow => {
                const chatEl = innerRow.querySelector('.low-chat-chat');
                const timeEl = innerRow.querySelector('.low-chat-time');
                const content = chatEl ? (chatEl.textContent || '').trim() : '';
                const time = timeEl ? (timeEl.textContent || '').trim() : '';

                if (!content || content === '聊天内容' || content === '消息' ||
                    sender === '发送人' || sender === '聊天对象' || sender === '聊天内容') return;

                if (content) {
                  extractCount++;
                  if (extractCount <= 3) {
                    console.log(`[千牛导出] 行${idx}: sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
                  }
                  addMessage(sender, content, time);
                }
              });
            } else {
              // 没有composeCell，尝试直接从行中提取
              const chatEl = row.querySelector(':scope > .low-chat-chat');
              const timeEl = row.querySelector(':scope > .low-chat-time');
              const content = chatEl ? (chatEl.textContent || '').trim() : '';
              const time = timeEl ? (timeEl.textContent || '').trim() : '';

              if (!content || content === '聊天内容' || content === '消息' ||
                  sender === '发送人' || sender === '聊天对象' || sender === '聊天内容') return;

              if (content) {
                extractCount++;
                if (extractCount <= 3) {
                  console.log(`[千牛导出] 行${idx}: sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
                }
                addMessage(sender, content, time);
              }
            }
          });
          console.log('[千牛导出] low-chat: 提取消息数=', extractCount);
        }
      }
      if (messages.length > 0) return { messages, realBuyerWangwang, realStaffWangwang };
    } catch (e) {}

    // 方式0.5：生意参谋 ChatLog_* CSS Modules 结构（接待/成交/流失/质量/售后明细）
    // 结构：[class*="ChatLog_container"] > [class*="ChatLog_bar"] > [class*="ChatLog_meta"]
    //       [class*="ChatLog_table"] > [class*="ChatLog_scroll"] > [class*="ChatLog_tbody"] > [class*="ChatLog_row"]
    try {
      let chatLogContainers = getAllElementsIncludingIframes(modal, '[class*="ChatLog_container"]');
      const uniqueChatLogContainers = [];
      const seenChatLogHtml = new Set();
      for (const container of chatLogContainers) {
        try {
          const text = container.textContent.substring(0, 300);
          if (!seenChatLogHtml.has(text)) {
            seenChatLogHtml.add(text);
            uniqueChatLogContainers.push(container);
          }
        } catch (e) {
          uniqueChatLogContainers.push(container);
        }
      }
      chatLogContainers = uniqueChatLogContainers;

      for (const container of chatLogContainers) {
        // 从 ChatLog_bar 提取客服旺旺和买家旺旺
        const barMetaEls = container.querySelectorAll('[class*="ChatLog_meta"]');
        barMetaEls.forEach(meta => {
          const text = meta.textContent.trim();
          if (text.includes('客服旺旺') && !realStaffWangwang) {
            const m = text.match(/客服旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*')) realStaffWangwang = m[1].trim();
          }
          if (text.includes('买家旺旺') && !realBuyerWangwang) {
            const m = text.match(/买家旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*') && isValidBuyerWangwang(m[1].trim())) {
              realBuyerWangwang = m[1].trim();
            }
          }
        });

        const tbody = container.querySelector('[class*="ChatLog_tbody"]');
        if (tbody) {
          let rows = tbody.querySelectorAll(':scope > [class*="ChatLog_row"]');
          if (rows.length === 0) {
            rows = tbody.querySelectorAll('[class*="ChatLog_row"]');
            console.log('[千牛导出] ChatLog: :scope选择0行，回退到全选', rows.length, '行');
          }
          console.log('[千牛导出] ChatLog: 外层行数=', rows.length, '客服旺旺=', realStaffWangwang);
          let extractCount = 0;
          rows.forEach((row, idx) => {
            const nameEl = row.querySelector(':scope > [class*="ChatLog_name"]');
            const composeCell = row.querySelector(':scope > [class*="ChatLog_composeCell"]');

            let sender = '';
            if (nameEl) {
              const directText = Array.from(nameEl.childNodes)
                .filter(n => n.nodeType === 3)
                .map(n => n.textContent)
                .join('')
                .trim();
              if (directText) {
                sender = directText;
              } else {
                sender = (nameEl.textContent || '').trim();
              }
              if (sender.includes('聊天对象') || sender.includes('聊天内容') || sender.includes('聊天时间') || sender.length > 30) {
                console.log(`[千牛导出] ChatLog 行${idx}: 发送人被防污染清除 "${sender.substring(0, 50)}"`);
                sender = '';
              }
            }

            // 从composeCell中提取所有内层行的消息
            if (composeCell) {
              const innerRows = composeCell.querySelectorAll('[class*="ChatLog_row"]');
              innerRows.forEach(innerRow => {
                const chatEl = innerRow.querySelector('[class*="ChatLog_chat"]');
                const timeEl = innerRow.querySelector('[class*="ChatLog_time"]');
                const content = chatEl ? (chatEl.textContent || '').trim() : '';
                const time = timeEl ? (timeEl.textContent || '').trim() : '';

                if (!content || content === '聊天内容' || content === '消息' ||
                    sender === '发送人' || sender === '聊天对象' || sender === '聊天内容') return;

                if (content) {
                  extractCount++;
                  if (extractCount <= 3) {
                    console.log(`[千牛导出] ChatLog 行${idx}: sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
                  }
                  addMessage(sender, content, time);
                }
              });
            } else {
              // 没有composeCell，尝试直接从行中提取
              const chatEl = row.querySelector(':scope > [class*="ChatLog_chat"]');
              const timeEl = row.querySelector(':scope > [class*="ChatLog_time"]');
              const content = chatEl ? (chatEl.textContent || '').trim() : '';
              const time = timeEl ? (timeEl.textContent || '').trim() : '';

              if (!content || content === '聊天内容' || content === '消息' ||
                  sender === '发送人' || sender === '聊天对象') return;

              if (content) {
                extractCount++;
                if (extractCount <= 3) {
                  console.log(`[千牛导出] ChatLog 行${idx}(直接): sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
                }
                addMessage(sender, content, time);
              }
            }
          });
          console.log('[千牛导出] ChatLog: 提取消息数=', extractCount);
        }
      }
      if (messages.length > 0) return { messages, realBuyerWangwang, realStaffWangwang };
    } catch (e) {
      console.warn('[千牛导出] ChatLog提取异常:', e);
    }

    // 方式0.6：生意参谋 ChatlogNew_* CSS Modules 结构（3分钟未响应明细）
    // 实际DOM结构（经HTML精确验证）：
    //   ChatlogNew_fixed 仅包含1行表头：[聊天对象|聊天内容|聊天时间]
    //   ChatlogNew_scroll
    //     └── ChatlogNew_tbody
    //          ├── ChatlogNew_row（顶层：每发送人一组）
    //          │    ├── ChatlogNew_name（发送人，如"驰腾旗舰店:驰小静"或买家旺旺）
    //          │    └── ChatlogNew_composeCell
    //          │         ├── ChatlogNew_row（子行1：ChatlogNew_chat + ChatlogNew_time）
    //          │         └── ChatlogNew_row（子行2）
    //          └── ChatlogNew_row（下一个发送人）
    // 本质上与 ChatLog_ 结构一致，只是前缀从 ChatLog_ 改为 ChatlogNew_
    try {
      let chatLogNewContainers = getAllElementsIncludingIframes(modal, '[class*="ChatlogNew_container"]');
      const uniqueNewContainers = [];
      const seenNewHtml = new Set();
      for (const container of chatLogNewContainers) {
        try {
          const text = container.textContent.substring(0, 300);
          if (!seenNewHtml.has(text)) {
            seenNewHtml.add(text);
            uniqueNewContainers.push(container);
          }
        } catch (e) {
          uniqueNewContainers.push(container);
        }
      }
      chatLogNewContainers = uniqueNewContainers;

      for (const container of chatLogNewContainers) {
        // 从 ChatlogNew_bar 提取客服旺旺和买家旺旺
        const barMetaEls = container.querySelectorAll('[class*="ChatlogNew_meta"]');
        barMetaEls.forEach(meta => {
          const text = meta.textContent.trim();
          if (text.includes('客服旺旺') && !realStaffWangwang) {
            const m = text.match(/客服旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*')) realStaffWangwang = m[1].trim();
          }
          if (text.includes('买家旺旺') && !realBuyerWangwang) {
            const m = text.match(/买家旺旺[：:]\s*([^\s]+)/);
            if (m && !m[1].includes('*') && isValidBuyerWangwang(m[1].trim())) {
              realBuyerWangwang = m[1].trim();
            }
          }
        });

        // 找 scroll + tbody 内部（所有顶层row）
        const tbody = container.querySelector('[class*="ChatlogNew_tbody"]') ||
                      container.querySelector('[class*="ChatlogNew_scroll"]');
        if (!tbody) continue;

        // 找所有顶级 ChatlogNew_row（直接包含 ChatlogNew_name 或 ChatlogNew_chat+ChatlogNew_time 的row）
        // 优先找 tbody 直接子 row
        let topRows = Array.from(tbody.querySelectorAll(':scope > [class*="ChatlogNew_row"]'));
        if (topRows.length < 2) {
          // 若层级不对，找所有 ChatlogNew_row（后续再用 name/composeCell 区分）
          topRows = Array.from(tbody.querySelectorAll('[class*="ChatlogNew_row"]'));
        }

        // 只保留"顶层row"：即含有 ChatlogNew_name 的row
        const senderRows = topRows.filter(r => r.querySelector(':scope > [class*="ChatlogNew_name"]'));

        console.log('[千牛导出] ChatlogNew: 顶层发送人行数=', senderRows.length, 'tbody总子row数=', topRows.length, '客服旺旺=', realStaffWangwang);

        let newExtractCount = 0;
        senderRows.forEach((row, idx) => {
          // 顶层row直接取 name 作为sender
          const nameEl = row.querySelector(':scope > [class*="ChatlogNew_name"]');
          let sender = '';
          if (nameEl) {
            // 取直接文本节点（避免内嵌子元素文本污染）
            const directText = Array.from(nameEl.childNodes)
              .filter(n => n.nodeType === 3)
              .map(n => n.textContent)
              .join('')
              .trim();
            sender = directText || (nameEl.textContent || '').trim();
          }
          // 清理污染
          if (sender.includes('聊天对象') || sender.includes('聊天内容') || sender.includes('聊天时间')) sender = '';

          // 有composeCell → 内部是多条子row（每条chat+time）
          const composeCell = row.querySelector(':scope > [class*="ChatlogNew_composeCell"]');
          if (composeCell) {
            const subRows = composeCell.querySelectorAll(':scope > [class*="ChatlogNew_row"]');
            subRows.forEach(subRow => {
              const chatEl = subRow.querySelector(':scope > [class*="ChatlogNew_chat"]');
              const timeEl = subRow.querySelector(':scope > [class*="ChatlogNew_time"]');
              const content = chatEl ? (chatEl.textContent || '').trim() : '';
              const time = timeEl ? (timeEl.textContent || '').trim() : '';

              if (!content || content === '聊天内容' || content === '消息' ||
                  sender === '发送人' || sender === '聊天对象') return;

              if (content) {
                newExtractCount++;
                if (newExtractCount <= 5) {
                  console.log(`[千牛导出] ChatlogNew 组${idx}-子: sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
                }
                addMessage(sender, content, time);
              }
            });
          } else {
            // 没有composeCell，直接取chat+time（单行消息）
            const chatEl = row.querySelector(':scope > [class*="ChatlogNew_chat"]');
            const timeEl = row.querySelector(':scope > [class*="ChatlogNew_time"]');
            const content = chatEl ? (chatEl.textContent || '').trim() : '';
            const time = timeEl ? (timeEl.textContent || '').trim() : '';

            if (!content || content === '聊天内容' || content === '消息' ||
                sender === '发送人' || sender === '聊天对象') return;

            if (content) {
              newExtractCount++;
              if (newExtractCount <= 5) {
                console.log(`[千牛导出] ChatlogNew 组${idx}(直接): sender="${sender}" content="${content.substring(0, 40)}" time="${time}"`);
              }
              addMessage(sender, content, time);
            }
          }
        });
        console.log('[千牛导出] ChatlogNew: 提取消息数=', newExtractCount);
      }
      if (messages.length > 0) return { messages, realBuyerWangwang, realStaffWangwang };
    } catch (e) {
      console.warn('[千牛导出] ChatlogNew提取异常:', e);
    }

    // 方式1：标准三列表格（聊天对象/聊天内容/聊天时间）- 包括 iframe
    let tables = getAllElementsIncludingIframes(modal, 'table');
    // 去重：同一个 table 可能在 iframe 和主文档中各有一份（内容相同但 DOM 对象不同）
    const uniqueTables = [];
    const seenTableHtml = new Set();
    for (const table of tables) {
      try {
        const html = table.outerHTML.substring(0, 300);
        if (!seenTableHtml.has(html)) {
          seenTableHtml.add(html);
          uniqueTables.push(table);
        }
      } catch (e) {
        uniqueTables.push(table);
      }
    }
    tables = uniqueTables;
    for (const table of tables) {
      try {
        let headerRow = table.querySelector('thead tr');
        if (!headerRow) {
          const allRows = table.querySelectorAll('tr');
          for (const r of allRows) {
            if (r.querySelector('th')) { headerRow = r; break; }
          }
          if (!headerRow && allRows.length > 0) headerRow = allRows[0];
        }

        if (headerRow) {
          const cells = headerRow.querySelectorAll('th, td');
          const headers = Array.from(cells).map(c => c.textContent.trim());

          const idxSender = headers.findIndex(h => h.includes('聊天对象') || h.includes('发送人'));
          const idxContent = headers.findIndex(h => h.includes('聊天内容') || h.includes('内容') || h.includes('消息'));
          const idxTime = headers.findIndex(h => h.includes('聊天时间') || h.includes('时间'));

          const isDetailTable = headers.some(h => h.includes('日期') || h.includes('开始时间') || h.includes('结束时间')) &&
                                !headers.some(h => h.includes('聊天内容') || h.includes('聊天对象'));

          if (idxContent >= 0 && !isDetailTable) {
            const dataRows = table.querySelectorAll('tbody tr');
            const rowsToUse = dataRows.length > 0 ? dataRows : table.querySelectorAll('tr');

            rowsToUse.forEach(row => {
              if (row.querySelector('th')) return;
              const cells = row.querySelectorAll(':scope > td');
              if (cells.length < 2) return;
              const sender = idxSender >= 0 ? cells[idxSender].textContent.trim() : '';
              const content = idxContent >= 0 ? cells[idxContent].textContent.trim() : '';
              const time = idxTime >= 0 ? cells[idxTime].textContent.trim() : '';
              // 跳过表头行
              if (content === '聊天内容' || content === '消息' || 
                  sender === '发送人' || sender === '聊天对象') return;
              addMessage(sender, content, time);
            });
            if (messages.length > 0) return { messages, realBuyerWangwang };
          }
        }
      } catch (e) {}
    }

    // 方式2：消息列表结构（气泡/卡片）- 包括 iframe
    const msgSelectors = [
      '[class*="message-item"]',
      '[class*="msg-item"]',
      '[class*="chat-item"]',
      '[class*="bubble"]',
      '[class*="conversation-item"]',
      '[class*="dialog-item"]',
      '[class*="chat-message"]',
      '[class*="im-message"]',
      '[class*="MessageItem"]',
      '[class*="ChatMessage"]',
      '[class*="record-item"]',
      '[class*="recordItem"]',
      '[class*="consult-record"]',
      '[class*="consultRecord"]'
    ];

    let msgEls = [];
    for (const sel of msgSelectors) {
      msgEls = msgEls.concat(getAllElementsIncludingIframes(modal, sel));
    }
    // 去重：同一个消息元素可能在 iframe 和主文档中各有一份（内容相同但 DOM 对象不同）
    const uniqueMsgEls = [];
    const seenMsgHtml = new Set();
    for (const el of msgEls) {
      try {
        const html = el.outerHTML.substring(0, 300);
        if (!seenMsgHtml.has(html)) {
          seenMsgHtml.add(html);
          uniqueMsgEls.push(el);
        }
      } catch (e) {
        uniqueMsgEls.push(el);
      }
    }
    msgEls = uniqueMsgEls;

    if (msgEls.length > 0) {
      msgEls.forEach(el => {
        try {
          const contentEl = el.querySelector('[class*="content"], [class*="text"], [class*="body"], [class*="desc"], p') || el;
          const content = contentEl.textContent.trim();
          if (!content) return;

          const senderEl = el.querySelector('[class*="sender"], [class*="name"], [class*="user"], [class*="from"], [class*="author"]');
          const timeEl = el.querySelector('[class*="time"], [class*="date"], [class*="timestamp"]');

          addMessage(
            senderEl ? senderEl.textContent.trim() : '',
            content,
            timeEl ? timeEl.textContent.trim() : ''
          );
        } catch (e) {}
      });
      if (messages.length > 0) return { messages, realBuyerWangwang };
    }

    // 方式3：兜底，扫描弹窗内所有含时间的 div（包括 iframe）
    const allDivs = getAllElementsIncludingIframes(modal, 'div');
    const candidateDivs = [];
    for (const div of allDivs) {
      try {
        const text = (div.textContent || '').trim();
        if (!/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(:\d{2})?/.test(text)) continue;
        if (/^(日期|开始时间|结束时间|买家旺旺|客服旺旺)/.test(text)) continue;
        if (text.length < 5 || text.length > 1000) continue;

        const childDivsWithText = div.querySelectorAll('div');
        let isLeaf = true;
        for (const cd of childDivsWithText) {
          const ct = (cd.textContent || '').trim();
          if (ct.length > text.length * 0.7 && /\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}/.test(ct)) {
            isLeaf = false;
            break;
          }
        }
        if (isLeaf) candidateDivs.push({ el: div, text });
      } catch (e) {}
    }

    if (candidateDivs.length > 0) {
      for (const { text } of candidateDivs) {
        const timeMatch = text.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(:\d{2})?/);
        const time = timeMatch ? timeMatch[0] : '';

        let sender = '';
        const senderMatch = text.match(/(买家|客服|小二|客服旺旺|发送人)[：:]\s*([^\s]+)/);
        if (senderMatch) sender = senderMatch[2].trim();

        let content = text
          .replace(/(买家|客服|小二|客服旺旺|发送人)[：:][^\s]+\s*/g, '')
          .replace(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(:\d{2})?/g, '')
          .replace(/^\s+|\s+$/g, '');

        if (content.length < 2) continue;

        addMessage(sender, content, time);
      }
      if (messages.length > 0) return { messages, realBuyerWangwang };
    }

    // 方式4：最后兜底，直接从弹窗的所有文本中提取（包括 iframe）
    const totalText = getTextContentIncludingIframes(modal);
    if (totalText.length > 50) {
      // 按时间戳分割文本
      const timePattern = /(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}(:\d{2})?)/g;
      let lastIndex = 0;
      let match;
      while ((match = timePattern.exec(totalText)) !== null) {
        const time = match[0];
        const prevText = totalText.substring(lastIndex, match.index).trim();
        const nextText = totalText.substring(match.index + time.length).trim();

        if (prevText.length > 0 && nextText.length > 0) {
          // 从前文提取发送人
          let sender = '';
          const senderMatch = prevText.match(/(买家|客服|小二|客服旺旺|发送人)[：:]\s*([^\s]+)$/);
          if (senderMatch) {
            sender = senderMatch[2].trim();
          } else {
            // 简单模式：直接取时间前的文本作为发送人
            const parts = prevText.split(/[:：]/);
            if (parts.length > 1) {
              sender = parts[parts.length - 1].trim();
            }
          }

          // 取时间后的文本作为内容，直到下一个时间戳
          let content = nextText;
          const nextTimeMatch = content.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}/);
          if (nextTimeMatch) {
            content = content.substring(0, nextTimeMatch.index).trim();
          }

          if (content.length >= 2) {
            addMessage(sender, content, time);
          }
        }
        lastIndex = match.index + time.length;
      }
    }

    // ========== 角色二次修正 ==========
    // 如果提取到了客服旺旺但所有消息都是 buyer，说明匹配逻辑有问题，强制修正
    if (realStaffWangwang && messages.length > 0) {
      const staffCount = messages.filter(m => m.role === 'staff').length;
      if (staffCount === 0) {
        console.log(`[千牛导出] 角色修正触发: realStaffWangwang=${realStaffWangwang}，但无staff消息，强制重新匹配`);
        for (const msg of messages) {
          const sender = msg.sender || '';
          const colonMatch = sender.match(/[:：]\s*(.+)$/);
          const name = colonMatch ? colonMatch[1].trim() : sender.trim();
          if (sender.includes(realStaffWangwang) || realStaffWangwang.includes(name) || name === realStaffWangwang) {
            msg.role = 'staff';
          }
        }
      }
    }
    // 如果仍然全是 buyer，使用频率推断：出现次数最多的 sender 视为客服
    if (messages.length > 0 && messages.every(m => m.role === 'buyer')) {
      const senderCounts = {};
      for (const msg of messages) {
        if (!msg.sender) continue;
        senderCounts[msg.sender] = (senderCounts[msg.sender] || 0) + 1;
      }
      const entries = Object.entries(senderCounts).filter(([s]) => s.length > 0);
      if (entries.length >= 2) {
        entries.sort((a, b) => b[1] - a[1]);
        const mostFrequent = entries[0][0];
        for (const msg of messages) {
          if (msg.sender === mostFrequent) msg.role = 'staff';
        }
        const colonMatch = mostFrequent.match(/[:：]\s*(.+)$/);
        realStaffWangwang = colonMatch ? colonMatch[1].trim() : mostFrequent;
        console.log(`[千牛导出] 角色推断: 将 ${mostFrequent} 设为staff`);
      }
    }
    // ========== 修正结束 ==========

    return { messages, realBuyerWangwang, realStaffWangwang };
  }

  // 等待弹窗内的聊天记录加载完成
  async function waitForChatContent(modal, timeout = 20000) {
    const start = Date.now();
    
    // 找到弹窗主体区域（Element UI 的 el-dialog__body）
    const bodyEl = modal.querySelector('.el-dialog__body') || 
                   modal.querySelector('.ant-modal-body') || 
                   modal.querySelector('[class*="dialog-body"]') ||
                   modal.querySelector('[class*="modal-body"]') ||
                   modal;

    console.log(`[千牛导出] 等待内容加载: bodyEl=${bodyEl?.className || 'modal'}, timeout=${timeout}`);

    // 使用 MutationObserver 监听内容变化
    return new Promise((resolve) => {
      let observer = null;
      let checkInterval = null;

      function checkAndResolve() {
        const content = bodyEl.textContent || '';
        const innerHTML = bodyEl.innerHTML || '';
        const hasLowChat = bodyEl.querySelector('.low-chat-container') !== null;
        const hasChatLog = bodyEl.querySelector('[class*="ChatLog_container"]') !== null;
        const hasTable = bodyEl.querySelector('table') !== null;

        // 优先检查 low-chat 结构：必须 tbody 里有实际聊天数据行
        if (hasLowChat) {
          const lowChatTbody = bodyEl.querySelector('.low-chat-tbody');
          if (lowChatTbody) {
            const rows = lowChatTbody.querySelectorAll('.low-chat-row');
            let validRows = 0;
            for (const row of rows) {
              const chatEl = row.querySelector('.low-chat-chat');
              const chatText = chatEl ? chatEl.textContent.trim() : row.textContent.trim();
              // 排除表头行和空行
              if (chatText && chatText !== '聊天内容' && chatText !== '暂无数据' && chatText.length > 0) {
                validRows++;
              }
            }
            if (validRows > 0) {
              console.log(`[千牛导出] 内容加载完成（low-chat有 ${validRows} 条有效记录）`);
              cleanup();
              resolve(true);
              return;
            }
            // 兜底：tbody.innerHTML 已经很大，说明数据已渲染但可能结构不同
            if (lowChatTbody.innerHTML.length > 300) {
              console.log(`[千牛导出] 内容加载完成（low-chat-tbody HTML长度 ${lowChatTbody.innerHTML.length}）`);
              cleanup();
              resolve(true);
              return;
            }
          }
          // low-chat 存在但 tbody 为空，如果已等待足够时间且有日期/时间信息，也接受
          const elapsed = Date.now() - start;
          if (elapsed > 1500 && /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(content) && /\d{2}:\d{2}/.test(content)) {
            console.log(`[千牛导出] 内容加载完成（low-chat已等待 ${elapsed}ms 且检测到时间信息）`);
            cleanup();
            resolve(true);
            return;
          }
        }

        // 检查 ChatLog_* 结构（CSS Modules）
        if (hasChatLog) {
          const chatLogTbody = bodyEl.querySelector('[class*="ChatLog_tbody"]');
          if (chatLogTbody) {
            const rows = chatLogTbody.querySelectorAll('[class*="ChatLog_row"]');
            let validRows = 0;
            for (const row of rows) {
              const chatEl = row.querySelector('[class*="ChatLog_chat"]');
              const chatText = chatEl ? chatEl.textContent.trim() : row.textContent.trim();
              // 排除表头行和空行
              if (chatText && chatText !== '聊天内容' && chatText !== '暂无数据' && chatText.length > 0) {
                validRows++;
              }
            }
            if (validRows > 0) {
              console.log(`[千牛导出] 内容加载完成（ChatLog有 ${validRows} 条有效记录）`);
              cleanup();
              resolve(true);
              return;
            }
            // 兜底：tbody.innerHTML 已经很大，说明数据已渲染
            if (chatLogTbody.innerHTML.length > 300) {
              console.log(`[千牛导出] 内容加载完成（ChatLog_tbody HTML长度 ${chatLogTbody.innerHTML.length}）`);
              cleanup();
              resolve(true);
              return;
            }
          }
          // ChatLog 存在但 tbody 为空，如果已等待足够时间且有日期/时间信息，也接受
          const elapsed = Date.now() - start;
          if (elapsed > 1500 && /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(content) && /\d{2}:\d{2}/.test(content)) {
            console.log(`[千牛导出] 内容加载完成（ChatLog已等待 ${elapsed}ms 且检测到时间信息）`);
            cleanup();
            resolve(true);
            return;
          }
        }

        // 检查表格结构：必须有实际数据行
        if (hasTable) {
          const tables = bodyEl.querySelectorAll('table');
          for (const table of tables) {
            const rows = table.querySelectorAll('tbody tr');
            let dataRows = 0;
            for (const r of rows) {
              if (r.querySelector('th')) continue;
              const cells = r.querySelectorAll('td');
              if (cells.length > 0) {
                const text = r.textContent.trim();
                if (text.length > 2 && text !== '暂无数据') dataRows++;
              }
            }
            if (dataRows > 0) {
              console.log(`[千牛导出] 内容加载完成（表格有 ${dataRows} 行数据）`);
              cleanup();
              resolve(true);
              return;
            }
          }
        }

        // 兜底：非 low-chat / 非 table 结构，才用通用条件
        if (!hasLowChat && !hasTable) {
          if (content.length > 50 && /\d{2}:\d{2}/.test(content)) {
            console.log(`[千牛导出] 内容加载完成（文本长度: ${content.length}）`);
            cleanup();
            resolve(true);
            return;
          }
          if (/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}/.test(content)) {
            console.log(`[千牛导出] 内容加载完成（检测到时间戳）`);
            cleanup();
            resolve(true);
            return;
          }
          if (innerHTML.length > 1000) {
            console.log(`[千牛导出] 内容加载完成（innerHTML长度: ${innerHTML.length}）`);
            cleanup();
            resolve(true);
            return;
          }
        }

        // 超时检查
        if (Date.now() - start >= timeout) {
          console.log(`[千牛导出] 内容加载超时（已等待 ${timeout}ms）`);
          cleanup();
          resolve(false);
          return;
        }
      }

      function cleanup() {
        if (observer) {
          observer.disconnect();
          observer = null;
        }
        if (checkInterval) {
          clearInterval(checkInterval);
          checkInterval = null;
        }
      }

      // 设置 MutationObserver 监听 DOM 变化
      observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === 'childList' || mutation.type === 'subtree') {
            checkAndResolve();
            break;
          }
        }
      });

      observer.observe(bodyEl, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true
      });

      // 同时设置定期检查（双重保障）
      checkInterval = setInterval(checkAndResolve, 300);

      // 立即检查一次
      checkAndResolve();
    });
  }

  // 支持中断的 waitForChatContent 变体
  async function waitForChatContentWithAbort(modal, timeout, shouldAbort) {
    const start = Date.now();
    const bodyEl = modal.querySelector('.el-dialog__body') || 
                   modal.querySelector('.ant-modal-body') || 
                   modal.querySelector('[class*="dialog-body"]') ||
                   modal.querySelector('[class*="modal-body"]') ||
                   modal;

    // 每300ms轮询一次，期间检查 shouldAbort
    while (Date.now() - start < timeout) {
      if (shouldAbort && shouldAbort()) {
        console.log('[千牛导出] 等待聊天内容时被中断');
        return false;
      }

      const content = bodyEl.textContent || '';
      const innerHTML = bodyEl.innerHTML || '';
      const hasLowChat = bodyEl.querySelector('.low-chat-container') !== null;
      const hasTable = bodyEl.querySelector('table') !== null;

      if (hasLowChat) {
        const lowChatTbody = bodyEl.querySelector('.low-chat-tbody');
        if (lowChatTbody) {
          const rows = lowChatTbody.querySelectorAll('.low-chat-row');
          let validRows = 0;
          for (const row of rows) {
            const chatEl = row.querySelector('.low-chat-chat');
            const chatText = chatEl ? chatEl.textContent.trim() : row.textContent.trim();
            if (chatText && chatText !== '聊天内容' && chatText !== '暂无数据' && chatText.length > 0) {
              validRows++;
            }
          }
          if (validRows > 0) return true;
          if (lowChatTbody.innerHTML.length > 300) return true;
        }
        const elapsed = Date.now() - start;
        if (elapsed > 1500 && /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(content) && /\d{2}:\d{2}/.test(content)) {
          return true;
        }
      }

      if (hasTable) {
        const tables = bodyEl.querySelectorAll('table');
        for (const table of tables) {
          const rows = table.querySelectorAll('tbody tr');
          let dataRows = 0;
          for (const r of rows) {
            if (r.querySelector('th')) continue;
            const cells = r.querySelectorAll('td');
            if (cells.length > 0) {
              const text = r.textContent.trim();
              if (text.length > 2 && text !== '暂无数据') dataRows++;
            }
          }
          if (dataRows > 0) return true;
        }
      }

      if (!hasLowChat && !hasTable) {
        if (content.length > 50 && /\d{2}:\d{2}/.test(content)) return true;
        if (/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{2}:\d{2}/.test(content)) return true;
        if (innerHTML.length > 1000) return true;
      }

      await sleep(300);
    }

    console.log(`[千牛导出] 内容加载超时（已等待 ${timeout}ms）`);
    return false;
  }

  // 获取元素内所有匹配选择器的元素（包括 iframe 和 shadow DOM）
  function getAllElementsIncludingIframes(root, selector) {
    const results = [];

    function collect(el) {
      try {
        // 直接查询
        el.querySelectorAll(selector).forEach(e => results.push(e));

        // 查询 iframe
        el.querySelectorAll('iframe').forEach(iframe => {
          try {
            if (iframe.contentDocument) {
              collect(iframe.contentDocument.body || iframe.contentDocument);
            }
          } catch (e) {}
        });

        // 查询 shadow DOM
        el.querySelectorAll('*').forEach(child => {
          try {
            if (child.shadowRoot) {
              collect(child.shadowRoot);
            }
          } catch (e) {}
        });
      } catch (e) {}
    }

    collect(root);
    return results;
  }

  // 获取元素内所有文本内容（包括 iframe 和 shadow DOM）
  function getTextContentIncludingIframes(root) {
    let text = '';

    function collect(el) {
      try {
        text += (el.textContent || '') + ' ';

        el.querySelectorAll('iframe').forEach(iframe => {
          try {
            if (iframe.contentDocument) {
              collect(iframe.contentDocument.body || iframe.contentDocument);
            }
          } catch (e) {}
        });

        el.querySelectorAll('*').forEach(child => {
          try {
            if (child.shadowRoot) {
              collect(child.shadowRoot);
            }
          } catch (e) {}
        });
      } catch (e) {}
    }

    collect(root);
    return text.trim();
  }

  // 生成聊天记录指纹（用于检测重复）
  function getMessagesFingerprint(messages) {
    if (!messages || messages.length === 0) return '';
    return messages.map(m => `${m.sender}:${m.content}`.substring(0, 50)).join('|');
  }

  // 后处理：当发送人全部为空时，从消息内容中提取发送人和角色
  // 仅在所有sender都为空时启用，不影响已有正确提取的页面
  function postProcessMessages(messages, staffWw, buyerWw) {
    if (!messages || messages.length === 0) return messages;

    // 检查是否所有sender都为空
    const hasAnySender = messages.some(m => m.sender && m.sender.trim());
    if (hasAnySender) return messages; // 已有sender提取，不需要后处理

    console.log('[千牛导出] 后处理：所有sender为空，从内容中提取发送人, staffWw=', staffWw, 'buyerWw=', buyerWw);

    // 构建客服旺旺的多种匹配格式
    const staffPatterns = [];
    if (staffWw) {
      // 完整格式 "驰腾旗舰店:驰小静"
      staffPatterns.push(staffWw);
      // 短格式 "驰小静"（去掉店铺名前缀）
      const colonIdx = staffWw.indexOf(':');
      const colonIdx2 = staffWw.indexOf('：');
      const colonPos = colonIdx >= 0 ? colonIdx : colonIdx2;
      if (colonPos >= 0) {
        const shortName = staffWw.substring(colonPos + 1).trim();
        if (shortName) staffPatterns.push(shortName);
        // 店铺名前缀 "驰腾旗舰店"
        const shopName = staffWw.substring(0, colonPos);
        if (shopName.includes('旗舰店') || shopName.includes('专营店') || shopName.includes('专卖店')) {
          staffPatterns.push(shopName + ':');
          staffPatterns.push(shopName + '：');
        }
      } else {
        // staffWw 没有冒号，是短格式（如"驰小静"）
        // 需要匹配内容中 "XXX旗舰店:驰小静" 或 "XXX专营店:驰小静" 的格式
        staffPatterns.push(staffWw); // 短名称本身
      }
    }

    // 提取客服短名称（用于正则匹配 "XXX旗舰店:短名称" 格式）
    let staffShortName = '';
    if (staffWw) {
      const cIdx = staffWw.indexOf(':');
      const cIdx2 = staffWw.indexOf('：');
      const cPos = cIdx >= 0 ? cIdx : cIdx2;
      staffShortName = cPos >= 0 ? staffWw.substring(cPos + 1).trim() : staffWw;
    }
    // 正则：匹配内容开头的 "店铺名:客服短名称" 格式
    // 关键修复：用[\u4e00-\u9fa5]{2,10}限制店铺名只匹配中文字符，避免.+?把买家消息内容也匹配进去
    const staffShopPrefixRegex = staffShortName
      ? new RegExp('([\u4e00-\u9fa5]{2,10}(?:旗舰店|专营店|专卖店)[:：]' + staffShortName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')')
      : null;

    // 买家旺旺的匹配格式
    const buyerPatterns = [];
    if (buyerWw && !buyerWw.includes('*')) {
      buyerPatterns.push(buyerWw);
    }

    const newMessages = [];
    let lastRole = 'buyer';

    for (const msg of messages) {
      let content = msg.content || '';
      let time = msg.time || '';
      let date = msg.date || '';

      // 尝试用客服旺旺分割内容（处理多条消息被拼接在一起的情况）
      // 例如："驰腾旗舰店:驰小静欢迎您光临本店tb7842602995还有一个问题...驰腾旗舰店:驰小静您好..."
      const splitParts = [];
      if (staffPatterns.length > 0 || staffShopPrefixRegex) {
        // 找到所有客服旺旺在内容中的位置
        const positions = [];
        // 用字符串匹配找已知模式
        for (const pattern of staffPatterns) {
          if (pattern.length < 2) continue; // 跳过过短的模式
          let startIdx = 0;
          while (true) {
            const idx = content.indexOf(pattern, startIdx);
            if (idx < 0) break;
            positions.push({ start: idx, end: idx + pattern.length, pattern, matchText: pattern });
            startIdx = idx + pattern.length;
          }
        }
        // 用正则找 "XXX旗舰店:短名称" 格式
        if (staffShopPrefixRegex) {
          let regexStr = staffShopPrefixRegex.source;
          // 去掉 ^ 限制，搜索全文
          regexStr = regexStr.replace(/^\^/, '');
          const globalRegex = new RegExp(regexStr, 'g');
          let m;
          while ((m = globalRegex.exec(content)) !== null) {
            // 避免重复添加（如果已经被字符串匹配找到）
            const exists = positions.some(p => p.start === m.index);
            if (!exists) {
              positions.push({ start: m.index, end: m.index + m[1].length, pattern: m[1], matchText: m[1] });
            }
            globalRegex.lastIndex = m.index + m[1].length;
          }
        }
        positions.sort((a, b) => a.start - b.start);

        // 去重：移除被更长模式包含的短模式（如"驰小静"被"驰腾旗舰店:驰小静"包含）
        const filteredPositions = [];
        for (const pos of positions) {
          const isContained = filteredPositions.some(fp =>
            pos.start >= fp.start && pos.end <= fp.end
          );
          if (!isContained) {
            // 移除已有的被包含的短模式
            for (let i = filteredPositions.length - 1; i >= 0; i--) {
              if (filteredPositions[i].start >= pos.start && filteredPositions[i].end <= pos.end) {
                filteredPositions.splice(i, 1);
              }
            }
            filteredPositions.push(pos);
          }
        }

        if (filteredPositions.length > 0) {
          // 按客服旺旺位置分割内容
          // 第一部分（在第一个客服旺旺之前）可能是买家消息
          if (filteredPositions[0].start > 0) {
            const beforeStaff = content.substring(0, filteredPositions[0].start).trim();
            if (beforeStaff) {
              splitParts.push({ sender: '', role: 'buyer', content: beforeStaff });
            }
          }
          // 每个客服旺旺开始的部分
          for (let i = 0; i < filteredPositions.length; i++) {
            const start = filteredPositions[i].start;
            const end = i < filteredPositions.length - 1 ? filteredPositions[i + 1].start : content.length;
            let part = content.substring(start, end).trim();
            // 去掉开头的客服旺旺
            const usedPattern = filteredPositions[i].matchText;
            if (part.startsWith(usedPattern)) {
              part = part.substring(usedPattern.length).trim();
            }
            if (part) {
              // 如果匹配到的是 "XXX旗舰店:短名称" 格式，使用完整匹配文本作为sender
              const senderForPart = usedPattern.includes('旗舰店') || usedPattern.includes('专营店') || usedPattern.includes('专卖店')
                ? usedPattern : staffWw;
              splitParts.push({ sender: senderForPart, role: 'staff', content: part });
            }
          }
        }
      }

      if (splitParts.length > 0) {
        // 内容被成功分割为多条消息
        for (const part of splitParts) {
          // 尝试从内容中提取买家旺旺（如"欢迎您光临本店tb7842602995"）
          if (part.role === 'staff' && part.content.includes('欢迎您光临本店')) {
            const welcomeMatch = part.content.match(/欢迎您光临本店([a-zA-Z0-9_]{3,25})/);
            if (welcomeMatch && !buyerWw) {
              buyerWw = welcomeMatch[1];
            }
          }
          // 从内容开头提取买家旺旺
          if (part.role === 'buyer' && !part.sender) {
            const tbMatch = part.content.match(/^tb(\d{8,12})(?![\d])/i);
            if (tbMatch) {
              part.sender = tbMatch[0];
            } else {
              const alnumMatch = part.content.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
              if (alnumMatch) part.sender = alnumMatch[1];
            }
          }
          lastRole = part.role;
          newMessages.push({
            date: date,
            time: time,
            sender: part.sender,
            role: part.role,
            content: part.content
          });
        }
      } else {
        // 内容没有被分割，检查客服旺旺前缀可能出现在内容任何位置（开头、中间、末尾）
        // 先搜索全文中的客服旺旺位置（包括 "XXX旗舰店:短名称" 格式）
        let staffPos = -1;
        let staffLen = 0;
        let staffMatchText = '';
        // 先用字符串模式搜索
        for (const pattern of staffPatterns) {
          if (pattern.length < 2) continue;
          const idx = content.indexOf(pattern);
          if (idx >= 0) {
            // 优先取更靠左、更长的匹配
            if (staffPos < 0 || idx < staffPos || (idx === staffPos && pattern.length > staffLen)) {
              staffPos = idx;
              staffLen = pattern.length;
              staffMatchText = pattern;
            }
          }
        }
        // 再用正则搜索 "XXX旗舰店:短名称" 格式
        if (staffShopPrefixRegex) {
          let regexStr = staffShopPrefixRegex.source.replace(/^\^/, '');
          const globalRegex = new RegExp(regexStr, 'g');
          const m = globalRegex.exec(content);
          if (m) {
            const idx = m.index;
            const len = m[1].length;
            if (staffPos < 0 || idx < staffPos || (idx === staffPos && len > staffLen)) {
              staffPos = idx;
              staffLen = len;
              staffMatchText = m[1];
            }
          }
        }

        let sender = '';
        let role = lastRole;
        // 最终输出的消息（可能拆分为0、1、2条）
        const outputMsgs = [];

        if (staffPos >= 0) {
          // 找到了客服旺旺位置
          const staffSenderForDisplay = (staffMatchText.includes('旗舰店') || staffMatchText.includes('专营店') || staffMatchText.includes('专卖店'))
            ? staffMatchText : staffWw;

          if (staffPos === 0) {
            // 情况A：客服旺旺在开头
            sender = staffSenderForDisplay;
            role = 'staff';
            const restContent = content.substring(staffPos + staffLen).trim();
            if (restContent) {
              content = restContent;
            }
            outputMsgs.push({ sender, role, content });
          } else if (staffPos + staffLen >= content.length - 2) {
            // 情况B：客服旺旺在末尾（或几乎末尾，后面只剩<=2字符）
            // 这是一条买家消息，客服旺旺是下一条的前缀被误拼进来了
            // 取客服旺旺之前的内容
            const beforeContent = content.substring(0, staffPos).trim();
            if (beforeContent) {
              // 尝试从开头提取买家旺旺
              let buyerSender = '';
              const tbMatch = beforeContent.match(/^tb(\d{8,12})(?![\d])/i);
              if (tbMatch) {
                buyerSender = tbMatch[0];
              } else {
                const alnumMatch = beforeContent.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
                if (alnumMatch && isValidBuyerWangwang(alnumMatch[1])) {
                  buyerSender = alnumMatch[1];
                } else {
                  const underscoreMatch = beforeContent.match(/^([a-zA-Z]_\d+_\d+)/);
                  if (underscoreMatch) buyerSender = underscoreMatch[1];
                }
              }
              if (buyerSender) {
                const rest = beforeContent.substring(buyerSender.length).trim();
                outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
              } else {
                // 检查开头是否匹配买家旺旺模式
                for (const pattern of buyerPatterns) {
                  if (beforeContent.startsWith(pattern)) {
                    buyerSender = pattern;
                    const rest = beforeContent.substring(pattern.length).trim();
                    outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
                    break;
                  }
                }
                if (!buyerSender) {
                  outputMsgs.push({ sender: '', role: 'buyer', content: beforeContent });
                }
              }
            }
          } else {
            // 情况C：客服旺旺在中间 → 拆分为两条：前段买家、后段客服
            const beforeContent = content.substring(0, staffPos).trim();
            const afterContent = content.substring(staffPos + staffLen).trim();
            // 前段：买家消息
            if (beforeContent) {
              let buyerSender = '';
              const tbMatch = beforeContent.match(/^tb(\d{8,12})(?![\d])/i);
              if (tbMatch) {
                buyerSender = tbMatch[0];
                const rest = beforeContent.substring(tbMatch[0].length).trim();
                outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
              } else {
                const underscoreMatch = beforeContent.match(/^([a-zA-Z]_\d+_\d+)/);
                if (underscoreMatch) {
                  buyerSender = underscoreMatch[1];
                  const rest = beforeContent.substring(underscoreMatch[1].length).trim();
                  outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
                } else {
                  const alnumMatch = beforeContent.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
                  if (alnumMatch && isValidBuyerWangwang(alnumMatch[1])) {
                    buyerSender = alnumMatch[1];
                    const rest = beforeContent.substring(alnumMatch[1].length).trim();
                    outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
                  } else {
                    for (const pattern of buyerPatterns) {
                      if (beforeContent.startsWith(pattern)) {
                        buyerSender = pattern;
                        const rest = beforeContent.substring(pattern.length).trim();
                        outputMsgs.push({ sender: buyerSender, role: 'buyer', content: rest || beforeContent });
                        break;
                      }
                    }
                    if (!buyerSender) {
                      outputMsgs.push({ sender: '', role: 'buyer', content: beforeContent });
                    }
                  }
                }
              }
            }
            // 后段：客服消息
            if (afterContent) {
              outputMsgs.push({ sender: staffSenderForDisplay, role: 'staff', content: afterContent });
            } else if (!beforeContent) {
              // 前后都空但找到了位置，保留原始
              outputMsgs.push({ sender: staffSenderForDisplay, role: 'staff', content: content });
            }
          }
        } else {
          // 没找到客服旺旺，检查是否以买家旺旺开头
          let handled = false;
          for (const pattern of buyerPatterns) {
            if (content.startsWith(pattern)) {
              sender = pattern;
              role = 'buyer';
              const restContent = content.substring(pattern.length).trim();
              outputMsgs.push({ sender, role, content: restContent || content });
              handled = true;
              break;
            }
          }
          if (!handled) {
            const tbMatch = content.match(/^tb(\d{8,12})(?![\d])/i);
            if (tbMatch) {
              sender = tbMatch[0];
              role = 'buyer';
              const rest = content.substring(tbMatch[0].length).trim();
              outputMsgs.push({ sender, role, content: rest || content });
              handled = true;
            }
          }
          if (!handled) {
            const underscoreMatch = content.match(/^([a-zA-Z]_\d+_\d+)/);
            if (underscoreMatch) {
              sender = underscoreMatch[1];
              role = 'buyer';
              const rest = content.substring(underscoreMatch[1].length).trim();
              outputMsgs.push({ sender, role, content: rest || content });
              handled = true;
            }
          }
          if (!handled) {
            const alnumMatch = content.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
            if (alnumMatch && isValidBuyerWangwang(alnumMatch[1])) {
              sender = alnumMatch[1];
              role = 'buyer';
              const rest = content.substring(alnumMatch[1].length).trim();
              outputMsgs.push({ sender, role, content: rest || content });
              handled = true;
            }
          }
          if (!handled) {
            // 纯内容，无发送人标记
            outputMsgs.push({ sender: '', role: lastRole, content: content });
          }
        }

        // 将 outputMsgs 写入 newMessages
        for (const om of outputMsgs) {
          lastRole = om.role;
          newMessages.push({
            date: date,
            time: time,
            sender: om.sender,
            role: om.role,
            content: om.content
          });
        }
      }
    }

    // 去重：处理DOM中父元素拼接子元素内容、以及前缀提取后内容相同的情况
    if (newMessages.length > 1) {
      // 第一步：对于长消息包含短消息内容的情况，把长消息的sender/role传递给短消息，然后移除长消息
      for (let i = 0; i < newMessages.length; i++) {
        const msg = newMessages[i];
        if (!msg.content || msg.content.length <= 20) continue;
        for (let j = 0; j < newMessages.length; j++) {
          if (i === j) continue;
          const otherMsg = newMessages[j];
          if (!otherMsg.content || otherMsg.content.length < 5) continue;
          // 如果长消息包含了短消息的完整内容
          if (msg.content.includes(otherMsg.content) && msg.content.length > otherMsg.content.length + 10) {
            // 把长消息的sender/role传递给短消息（如果短消息没有sender）
            if (msg.sender && !otherMsg.sender) {
              otherMsg.sender = msg.sender;
              otherMsg.role = msg.role;
            }
            // 标记长消息为待移除
            msg._remove = true;
            break;
          }
        }
      }

      // 第二步：对于内容完全相同的消息，保留有sender的，移除没有sender的
      for (let i = 0; i < newMessages.length; i++) {
        if (newMessages[i]._remove) continue;
        for (let j = i + 1; j < newMessages.length; j++) {
          if (newMessages[j]._remove) continue;
          if (newMessages[i].content === newMessages[j].content) {
            // 保留有sender的，移除没有sender的
            if (newMessages[i].sender && !newMessages[j].sender) {
              newMessages[j]._remove = true;
            } else if (!newMessages[i].sender && newMessages[j].sender) {
              newMessages[i]._remove = true;
            } else if (newMessages[i].sender && newMessages[j].sender) {
              // 都有sender，保留第一条
              newMessages[j]._remove = true;
            } else {
              // 都没有sender，保留第一条
              newMessages[j]._remove = true;
            }
          }
        }
      }

      const dedupedMessages = newMessages.filter(m => !m._remove);
      // 清理临时标记
      dedupedMessages.forEach(m => delete m._remove);

      if (dedupedMessages.length < newMessages.length) {
        console.log('[千牛导出] 去重：移除', newMessages.length - dedupedMessages.length, '条重复消息');
      }
      console.log('[千牛导出] 后处理完成: 原消息数=', messages.length, '处理后消息数=', dedupedMessages.length);
      return dedupedMessages;
    }

    console.log('[千牛导出] 后处理完成: 原消息数=', messages.length, '处理后消息数=', newMessages.length);
    return newMessages;
  }

  // 点击行内的聊天明细按钮，抓取聊天记录
  async function extractChatForRow(row) {
    if (!row._hasChatBtn || !row._chatBtn) {
      return { messages: [], detail: {} };
    }

    // 检查暂停
    if (window.__QIANNIU_PAUSE_REQUEST__) {
      console.log('[千牛导出] 检测到暂停请求，跳过当前行');
      return { messages: [], detail: {}, paused: true };
    }

    // 单条记录超时保护：最多25秒
    const recordStartTime = Date.now();
    const RECORD_TIMEOUT = 25000;
    function isRecordTimeout() {
      return Date.now() - recordStartTime > RECORD_TIMEOUT;
    }

    try {
      const btn = row._chatBtn;
      const btnText = btn.textContent.trim().substring(0, 50);
      const rowBuyerHint = (row['买家旺旺']?.text || row['买家']?.text || row['旺旺']?.text || '').substring(0, 30);
      const rowStaffHint = (row['客服旺旺']?.text || row['客服']?.text || '').substring(0, 30);
      console.log(`[千牛导出] 准备处理: buyer="${rowBuyerHint}", staff="${rowStaffHint}", btn="${btnText}"`);

      // 点击按钮前确保元素在视口内
      row._chatBtn.scrollIntoView({ behavior: 'instant', block: 'center' });
      await sleep(300);

      // 先确保没有已打开的弹窗（避免框架状态混乱）
      const existingModal = findActiveModal();
      if (existingModal) {
        console.log('[千牛导出] 发现已有弹窗未关闭，先关闭');
        await closeActiveModal();
        await sleep(800);
      }

      // 多次尝试点击
      let modal = null;
      const clickAttempts = [
        { delay: 1200, desc: '首次点击' },
        { delay: 1500, desc: '第二次点击' },
        { delay: 2000, desc: '第三次点击' }
      ];

      for (const attempt of clickAttempts) {
        if (window.__QIANNIU_PAUSE_REQUEST__) {
          return { messages: [], detail: {}, paused: true };
        }
        if (isRecordTimeout()) {
          console.log('[千牛导出] 单条记录处理超时，跳过');
          return { messages: [], detail: {} };
        }

        console.log(`[千牛导出] ${attempt.desc}`);
        simulateClick(row._chatBtn);
        
        const operationItem = btn.closest('.operation-item, [class*="operation-item"]');
        if (operationItem && operationItem !== btn) {
          simulateClick(operationItem);
        }
        triggerMouseEvents(row._chatBtn);

        // 分步等待弹窗出现，每200ms检查一次，期间可响应暂停
        for (let waited = 0; waited < attempt.delay; waited += 200) {
          if (window.__QIANNIU_PAUSE_REQUEST__) {
            return { messages: [], detail: {}, paused: true };
          }
          await sleep(200);
          modal = findActiveModal();
          if (modal) break;
        }
        
        if (modal) {
          console.log('[千牛导出] 弹窗已出现');
          break;
        }
      }

      if (!modal) {
        console.log(`[千牛导出] 未找到弹窗，跳过 buyer="${rowBuyerHint}"`);
        return { messages: [], detail: {} };
      }

      // 等待聊天记录加载（支持暂停中断）
      const chatLoaded = await waitForChatContentWithAbort(modal, 10000, 
        () => window.__QIANNIU_PAUSE_REQUEST__ || isRecordTimeout()
      );
      if (!chatLoaded) {
        console.log('[千牛导出] 弹窗内聊天记录未加载完成或已暂停/超时');
      }

      // 滚动加载所有聊天记录（处理懒加载）
      if (!window.__QIANNIU_PAUSE_REQUEST__ && !isRecordTimeout()) {
        await scrollChatToLoadAll(modal);
      }

      // 提取详情和聊天记录
      const detail = extractDetailTableInfo(modal);
      const headerBuyer = extractBuyerFromModalHeader(modal);
      if (headerBuyer && !detail.buyerWangwang) {
        detail.buyerWangwang = headerBuyer;
      }

      let chatResult = extractChatMessages(modal);
      let messages = chatResult.messages || [];

      // 如果首次提取为0条，重试一次
      if (messages.length === 0 && !window.__QIANNIU_PAUSE_REQUEST__ && !isRecordTimeout()) {
        await sleep(800);
        chatResult = extractChatMessages(modal);
        messages = chatResult.messages || [];
      }
      
      if (chatResult.realBuyerWangwang && !chatResult.realBuyerWangwang.includes('*') && isValidBuyerWangwang(chatResult.realBuyerWangwang)) {
        detail.buyerWangwang = chatResult.realBuyerWangwang;
        detail.realBuyerWangwang = chatResult.realBuyerWangwang;
      }
      if (chatResult.realStaffWangwang) {
        detail.staffWangwang = chatResult.realStaffWangwang;
      }

      // 后处理：当所有sender为空时，从消息内容中提取发送人和角色
      // 使用客服旺旺（优先用detail中的完整格式，备选行数据中的短格式）
      const staffWwForPost = detail.staffWangwang || rowStaffHint || '';
      const buyerWwForPost = (detail.buyerWangwang && !detail.buyerWangwang.includes('*')) ? detail.buyerWangwang : '';
      if (messages.length > 0 && staffWwForPost) {
        const originalCount = messages.length;
        messages = postProcessMessages(messages, staffWwForPost, buyerWwForPost);
        // 如果后处理发现了真实买家旺旺，更新detail
        const buyerMsg = messages.find(m => m.role === 'buyer' && m.sender && !m.sender.includes('*'));
        if (buyerMsg && buyerMsg.sender && isValidBuyerWangwang(buyerMsg.sender)) {
          if (!detail.buyerWangwang || detail.buyerWangwang.includes('*')) {
            detail.buyerWangwang = buyerMsg.sender;
            detail.realBuyerWangwang = buyerMsg.sender;
            console.log('[千牛导出] 后处理提取到买家旺旺:', buyerMsg.sender);
          }
        }
      }

      // 重复检测：如果提取到的聊天记录和上一次完全一样，说明弹窗内容未更新
      const fingerprint = getMessagesFingerprint(messages);
      if (fingerprint && window.__QIANNIU_LAST_CHAT_FINGERPRINT__ === fingerprint && messages.length > 0) {
        console.warn(`[千牛导出] 警告：聊天记录和上次完全相同，可能是弹窗未更新（buyer="${rowBuyerHint}"）`);
        // 清空消息，避免重复数据
        messages = [];
      }
      if (fingerprint) {
        window.__QIANNIU_LAST_CHAT_FINGERPRINT__ = fingerprint;
      }

      // 校验：弹窗中的买家旺旺应该和表格行的买家匹配（如果都能提取到）
      const modalBuyer = detail.buyerWangwang || detail.realBuyerWangwang || '';
      if (modalBuyer && rowBuyerHint && !modalBuyer.includes('*') && !rowBuyerHint.includes('*')) {
        // 如果两者完全不同且都不为空，可能是弹窗内容未更新
        const isMatch = modalBuyer === rowBuyerHint || 
                        modalBuyer.includes(rowBuyerHint) || 
                        rowBuyerHint.includes(modalBuyer);
        if (!isMatch && messages.length > 0) {
          console.warn(`[千牛导出] 警告：弹窗买家(${modalBuyer})和表格买家(${rowBuyerHint})不匹配，聊天记录可能不正确`);
        }
      }

      console.log(`[千牛导出] buyer="${rowBuyerHint}" 提取到 ${messages.length} 条聊天记录`);

      // 关闭弹窗
      await closeActiveModal();
      // 确认弹窗已关闭（最多等1秒）
      for (let i = 0; i < 5; i++) {
        await sleep(200);
        if (!findActiveModal()) break;
        if (i === 4) {
          console.warn('[千牛导出] 弹窗关闭后仍存在，强制隐藏');
          await closeActiveModal();
        }
      }

      return { messages, detail };
    } catch (e) {
      console.error('[千牛导出] 提取聊天记录失败:', e);
      return { messages: [], detail: {} };
    }
  }

  // 获取买家真实旺旺（多来源）- 注意：只返回真实旺旺名，脱敏值的使用由 popup.js 根据 mask 标志决定
  function getRealBuyerWangwang(messages, detail, currentMasked) {
    const invalidLabels = ['买家', '买家旺旺', '客服旺旺', '发送人', '客户昵称', '昵称', '客户', '消息'];
    
    // 1. 优先使用详情中的有效旺旺名（非脱敏）
    if (detail && detail.buyerWangwang && isValidBuyerWangwang(detail.buyerWangwang)) {
      return detail.buyerWangwang;
    }

    // 2. 从聊天记录中查找有效旺旺名
    if (messages && messages.length > 0) {
      for (const msg of messages) {
        if (msg.sender && msg.role === 'buyer') {
          if (isValidBuyerWangwang(msg.sender) && !invalidLabels.includes(msg.sender.trim())) {
            return msg.sender;
          }
        }
      }
      for (const msg of messages) {
        if (msg.sender && msg.role === 'buyer') {
          const colonMatch = msg.sender.match(/[:：]\s*([a-zA-Z0-9_\u4e00-\u9fa5]{2,20})/);
          if (colonMatch && isValidBuyerWangwang(colonMatch[1]) && !invalidLabels.includes(colonMatch[1].trim())) {
            return colonMatch[1];
          }
        }
      }
      for (const msg of messages) {
        if (msg.sender && !msg.sender.includes('*') && msg.role !== 'staff') {
          const sender = msg.sender.trim();
          if (!sender || invalidLabels.includes(sender)) continue;
          if (sender.includes('旗舰店') || sender.includes('专营店') || sender.includes('专卖店') ||
              sender.includes('客服') || sender.includes('接待')) continue;
          if (sender.length >= 2 && sender.length <= 25) {
            return sender;
          }
        }
      }

      // 3. 从聊天内容中提取真实旺旺名（3分钟未响应明细等页面发送人为空的情况）

      function removeUrls(text) {
        return text.replace(/https?:\/\/[^\s，。！？、：；]+/g, ' ');
      }

      // 3.1 搜索所有消息中的 tb+数字 格式，取后跟非数字的最短匹配
      {
        const allTbMatches = [];
        for (const msg of messages) {
          if (!msg.content) continue;
          const cleanContent = removeUrls(msg.content);
          const regex = /tb(\d{8,12})/gi;
          let m;
          while ((m = regex.exec(cleanContent)) !== null) {
            const fullMatch = m[0];
            const endPos = m.index + fullMatch.length;
            const nextChar = cleanContent[endPos] || '';
            if (!/\d/.test(nextChar)) {
              allTbMatches.push(fullMatch);
            }
          }
        }
        if (allTbMatches.length > 0) {
          allTbMatches.sort((a, b) => a.length - b.length);
          const candidate = allTbMatches[0];
          if (isValidBuyerWangwang(candidate)) {
            console.log('[千牛导出] 从消息中提取到tb格式旺旺(最短匹配):', candidate);
            return candidate;
          }
        }
      }

      // 3.2 匹配"欢迎您光临本店XXX"格式（偏移量=7）
      for (const msg of messages) {
        if (!msg.content) continue;
        const cleanContent = removeUrls(msg.content);
        const welcomeStr = '欢迎您光临本店';
        const welcomeIdx = cleanContent.indexOf(welcomeStr);
        if (welcomeIdx >= 0) {
          const afterWelcome = cleanContent.substring(welcomeIdx + welcomeStr.length);
          const alnumMatch = afterWelcome.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
          if (alnumMatch && isValidBuyerWangwang(alnumMatch[1])) {
            console.log('[千牛导出] 从"欢迎您光临本店"提取到买家旺旺(alnum):', alnumMatch[1]);
            return alnumMatch[1];
          }
          const cnNumMatch = afterWelcome.match(/^([\u4e00-\u9fa5]{1,4}\d{1,4})(?=[\u4e00-\u9fa5，。！？、：；,.!?;:\s])/);
          if (cnNumMatch && isValidBuyerWangwang(cnNumMatch[1])) {
            console.log('[千牛导出] 从"欢迎您光临本店"提取到买家旺旺(cn+num):', cnNumMatch[1]);
            return cnNumMatch[1];
          }
        }
      }

      // 3.3 从消息开头提取独立的旺旺名
      for (const msg of messages) {
        if (!msg.content) continue;
        const cleanContent = removeUrls(msg.content.trim());
        if (!cleanContent) continue;

        const alnumMatch = cleanContent.match(/^([a-zA-Z][a-zA-Z0-9_]{3,25})(?=[\u4e00-\u9fa5])/);
        if (alnumMatch && isValidBuyerWangwang(alnumMatch[1])) {
          console.log('[千牛导出] 从消息开头提取到买家旺旺(alnum):', alnumMatch[1]);
          return alnumMatch[1];
        }
        const cnNumMatch = cleanContent.match(/^([\u4e00-\u9fa5]{1,4}\d{1,4})(?=[\u4e00-\u9fa5，。！？、：；,.!?;:\s])/);
        if (cnNumMatch && isValidBuyerWangwang(cnNumMatch[1])) {
          console.log('[千牛导出] 从消息开头提取到买家旺旺(cn+num):', cnNumMatch[1]);
          return cnNumMatch[1];
        }
      }

      // 3.4 匹配 t_XXXXXX 格式和手机号
      for (const msg of messages) {
        if (!msg.content) continue;
        const underscoreMatch = msg.content.match(/[a-zA-Z]_\d+_\d+/);
        if (underscoreMatch) {
          const candidate = underscoreMatch[0].trim();
          if (candidate.length >= 2 && candidate.length <= 30) {
            console.log('[千牛导出] 从消息中提取下划线格式ID:', candidate);
            return candidate;
          }
        }
        const phoneMatch = msg.content.match(/(?<![0-9])1[3-9]\d{9}(?![0-9])/);
        if (phoneMatch) {
          console.log('[千牛导出] 从消息中提取手机号格式ID:', phoneMatch[0]);
          return phoneMatch[0];
        }
      }
    }

    // 4. 检查当前脱敏值中是否有真实旺旺的标注
    if (currentMasked && typeof currentMasked === 'string') {
      const match = currentMasked.match(/真实[:：]\s*([^\s]+)/);
      if (match && isValidBuyerWangwang(match[1])) return match[1];
    }

    // 注意：不再在这里返回脱敏值，由 popup.js 根据 mask 标志统一处理是否使用脱敏值作为备选
    return '';
  }

  // 获取分页总数（严格按用户实际显示的口径，不做估算）
  function getTotalCount() {
    const paginationEl = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (paginationEl) {
      const text = paginationEl.textContent || paginationEl.innerText;

      // 方式1：优先匹配分页器完整文本中的"共X条"（最可靠）
      const match = text.match(/共\s*(\d+)\s*条/);
      if (match) return parseInt(match[1], 10);

      // 方式2：精确匹配分页器中的"总条数"元素
      const totalTextEl = paginationEl.querySelector('.next-pagination-total, .ant-pagination-total-text, [class*="total-text"]');
      if (totalTextEl) {
        const t = totalTextEl.textContent || totalTextEl.innerText;
        // 优先匹配 "共XX条"
        const m1 = t.match(/共\s*(\d+)\s*条/);
        if (m1) return parseInt(m1[1], 10);
        // 匹配单独的数字
        const m2 = t.match(/(\d+)/);
        if (m2) return parseInt(m2[1], 10);
      }

      // 方式3：匹配 "共 XX 条记录" 或 "XX 条记录"
      const match2 = text.match(/(\d+)\s*条\s*(?:记录|数据|商品)/);
      if (match2) return parseInt(match2[1], 10);
    }

    // 方式4：从页面正文提取
    const bodyText = document.body.innerText;
    const bodyMatch = bodyText.match(/共\s*(\d+)\s*条/);
    if (bodyMatch) return parseInt(bodyMatch[1], 10);
    const bodyMatch2 = bodyText.match(/(\d+)\s*条\s*(?:记录|数据|商品)/);
    if (bodyMatch2) return parseInt(bodyMatch2[1], 10);

    // 方式5：从 URL 参数提取
    const url = window.location.href;
    const totalMatch = url.match(/total=(\d+)/) || url.match(/count=(\d+)/) || url.match(/totalCount=(\d+)/);
    if (totalMatch) return parseInt(totalMatch[1], 10);

    return 0;
  }

  function getCurrentPageRows() {
    const table = findMainTable();
    if (!table) return 0;
    const rows = table.querySelectorAll('tbody tr');
    let validCount = 0;
    rows.forEach((row, rowIndex) => {
      // 跳过层级子行（expanded-row / row-level-1 / row-level-2）
      const className = row.className || '';
      if (/expanded-row|row-level-[1-9]/.test(className)) return;
      // 跳过所有单元格为空的占位行
      const cells = row.querySelectorAll('td, th');
      const allEmpty = Array.from(cells).every(cell => !(cell.textContent || '').trim());
      if (!allEmpty) validCount++;
    });
    return validCount;
  }

  // 主入口：提取整个页面数据
  async function extractFullPageData() {
    const pageType = detectMainPageType();
    const subPageType = detectActiveSubTab();
    const tableData = extractTableData();

    if (!tableData.success) {
      return {
        success: false,
        pageType,
        subPageType,
        reason: tableData.reason
      };
    }

    // totalCount 必须来自分页器的真实总条数；如果取不到，返回 null 而不是当前页行数
    // 当前页行数 tableData.totalRows 不能代表总记录数
    const totalCount = getTotalCount();
    const hasNextPage = checkHasNextPage();

    return {
      success: true,
      pageType,
      subPageType,
      totalCount,
      hasNextPage,
      currentPageRows: tableData.rows.length,
      headers: tableData.headers,
      rows: tableData.rows
    };
  }

  // 预扫描：获取真实总条数和总页数
  async function preScanAndGetTotal() {
    const paginationEl = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (!paginationEl) return { total: 0, pages: 0, perPage: 0 };

    const perPage = getCurrentPageRows();
    
    // 优先尝试从分页器获取真实总条数
    const directTotal = getTotalCount();
    
    // 获取总页数（可能不准确，仅作为参考）
    const maxPageFromUI = getMaxPageNumber(paginationEl);
    
    // 检查是否为滑动窗口分页器（有省略号）
    const paginationText = paginationEl.textContent || '';
    const hasEllipsis = /\.\.\./.test(paginationText) || paginationText.includes('…');
    
    if (directTotal > 0) {
      console.log(`[千牛导出] 预扫描：直接获取到总条数 ${directTotal}`);
      
      if (perPage > 0) {
        const calculatedPages = Math.ceil(directTotal / perPage);
        console.log(`[千牛导出] 预扫描：每页${perPage}条，由总条数${directTotal}计算出${calculatedPages}页`);

        // 【关键修复】交叉验证：如果UI显示的最大页码比计算出的多，保留directTotal为总条数，只更新pages为UI值
        // 不再用 pages * perPage 覆盖 directTotal，避免误差累积
        if (maxPageFromUI > calculatedPages) {
          console.log(`[千牛导出] 预扫描：计算出${calculatedPages}页，但UI显示最大${maxPageFromUI}页，使用UI页数，总条数保留${directTotal}`);
          return { total: directTotal, pages: maxPageFromUI, perPage };
        }
        return { total: directTotal, pages: calculatedPages, perPage };
      }
      return { total: directTotal, pages: 0, perPage: 0 };
    }

    if (perPage === 0) return { total: 0, pages: 0, perPage: 0 };

    // 【关键修复】滑动窗口分页器：直接信任 getMaxPageNumber 的结果
    // 因为跳页验证不可靠（可能跳错页）
    if (hasEllipsis && maxPageFromUI > 1) {
      console.log(`[千牛导出] 预扫描：滑动窗口分页器，UI显示最大页码${maxPageFromUI}，直接信任`);
      console.log(`[千牛导出] 预扫描：每页${perPage}条 × ${maxPageFromUI}页 = ${maxPageFromUI * perPage}条`);
      return { total: maxPageFromUI * perPage, pages: maxPageFromUI, perPage };
    }

    console.log(`[千牛导出] 预扫描：每页${perPage}条，UI显示最大页码${maxPageFromUI}，使用跳页扫描`);

    // 只有一页，直接返回
    if (maxPageFromUI <= 1) {
      const total = getCurrentPageRows();
      console.log(`[千牛导出] 预扫描：只有1页，共${total}条`);
      return { total, pages: 1, perPage };
    }

    // 记录当前第一行内容，用于检测跳转是否成功
    const firstRowBefore = getFirstRowText();
    const currentPageBefore = getCurrentPageNumber();

    // 策略：尝试点击最大页码（比"最后一页"按钮更可靠）
    let clicked = false;
    if (maxPageFromUI > 0) {
      const pageBtn = findPageButtonByNumber(maxPageFromUI);
      if (pageBtn) {
        console.log(`[千牛导出] 预扫描：点击第${maxPageFromUI}页`);
        clickPageButton(pageBtn);
        clicked = true;
      }
    }
    
    if (!clicked) {
      // 尝试找"尾页"/"最后一页"按钮作为备选
      const lastPageBtn = findLastPageButton(paginationEl);
      if (lastPageBtn) {
        console.log('[千牛导出] 预扫描：点击最后一页按钮...');
        clickPageButton(lastPageBtn);
        clicked = true;
      }
    }

    if (!clicked) {
      console.log('[千牛导出] 预扫描：无法跳页，将通过翻页验证确定真实总页数');
      return { total: 0, pages: 0, perPage };
    }

    // 等待页面变化
    let changed = false;
    for (let i = 0; i < 60; i++) {
      await sleep(200);
      if (getFirstRowText() !== firstRowBefore) {
        changed = true;
        break;
      }
    }

    if (!changed) {
      console.log('[千牛导出] 预扫描：跳转后内容未变化');
      const currentPageAfter = getCurrentPageNumber();
      if (currentPageAfter !== currentPageBefore) {
        changed = true;
      }
    }

    await sleep(500);

    // 读取当前页的行数和页码
    const currentPageRows = getCurrentPageRows();
    const currentPageNum = getCurrentPageNumber();
    console.log(`[千牛导出] 预扫描：当前页=${currentPageNum}，行数=${currentPageRows}`);

    // 尝试再次获取真实总条数
    const finalTotal = getTotalCount();
    if (finalTotal > 0) {
      console.log(`[千牛导出] 预扫描：获取到真实总条数 ${finalTotal}`);
      const finalPages = Math.ceil(finalTotal / perPage);
      return { total: finalTotal, pages: finalPages, perPage };
    }

    // 如果能从分页器文本获取 "共X页"
    const paginationEl2 = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (paginationEl2) {
      const text = paginationEl2.textContent || '';
      const totalPagesMatch = text.match(/共\s*(\d+)\s*页/);
      if (totalPagesMatch) {
        const totalPages = parseInt(totalPagesMatch[1], 10);
        if (!isNaN(totalPages) && totalPages > 0) {
          console.log(`[千牛导出] 预扫描：从分页器获取总页数 ${totalPages}`);
          const lastPageRows = currentPageRows;
          const total = (totalPages - 1) * perPage + lastPageRows;
          return { total, pages: totalPages, perPage };
        }
      }
    }

    // 计算真实总条数
    const lastPageRows = currentPageRows;
    const total = (currentPageNum - 1) * perPage + lastPageRows;
    console.log(`[千牛导出] 预扫描完成：${perPage}×${currentPageNum - 1}+${lastPageRows}=${total}条，共${currentPageNum}页`);

    return { total, pages: currentPageNum, perPage };
  }

  // 可靠的页码点击：兼容 React/AntD
  // 【关键修复】AntD 的 onClick 绑定在 <li> 上，不是内部的 <a>
  function clickPageButton(el) {
    if (!el) return;
    // AntD Pagination: 事件绑定在 <li> 上，直接点击 <li>
    if (el.tagName === 'LI' && (el.className || '').toString().includes('ant-pagination')) {
      el.click();
      return;
    }
    // 其他情况：找到真正可点击的元素
    const clickable = el.tagName === 'A' || el.tagName === 'BUTTON' ? el : (el.querySelector('a, button') || el);
    clickable.click();
  }

  // 通过数字找页码按钮
  function findPageButtonByNumber(num) {
    const paginationEl = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (!paginationEl) return null;
    // Next UI: .next-pagination-item-N
    const nextUiItem = paginationEl.querySelector(`.next-pagination-item-${num}`);
    if (nextUiItem) return nextUiItem.querySelector('a, button') || nextUiItem;
    // AntD: li.ant-pagination-item-N —— 【关键】返回 <li> 本身，onClick 绑定在 <li> 上
    const antItem = paginationEl.querySelector(`.ant-pagination-item-${num}`);
    if (antItem && antItem.offsetHeight > 0) {
      return antItem;
    }
    // 通用：遍历找文本匹配的（AntD 优先返回 <li>）
    const items = paginationEl.querySelectorAll('li, a, button, span, div, [role="button"]');
    for (const item of items) {
      if (item.textContent.trim() === String(num) && item.offsetHeight > 0) {
        // AntD: 如果是 <li>，直接返回（onClick 在 <li> 上）
        if (item.tagName === 'LI' && (item.className || '').toString().includes('ant-pagination')) {
          return item;
        }
        // 其他情况：如果是容器元素，尝试找内部可点击元素
        if (item.tagName !== 'A' && item.tagName !== 'BUTTON') {
          const inner = item.querySelector('a, button');
          if (inner) return inner;
        }
        return item;
      }
    }
    return null;
  }

  // 等待表格内容稳定渲染（翻页后DOM可能异步更新，需要确保tbody行已就绪）
  async function waitForTableStable(expectedMinRows = 1, maxWaitMs = 8000) {
    const startTime = Date.now();
    let lastRowCount = -1;
    let stableCount = 0;
    const targetStable = 3; // 连续3次行数一致则认为稳定

    while (Date.now() - startTime < maxWaitMs) {
      const table = findMainTable();
      if (table) {
        const tbody = table.querySelector('tbody');
        const rows = tbody ? tbody.querySelectorAll(':scope > tr') : [];
        const rowCount = rows.length;
        // 检查是否存在"操作"列（有效数据的标志）
        const hasOperationCol = table.textContent && /操作/.test(table.textContent.substring(0, 500));
        const hasValidRows = rowCount >= expectedMinRows && hasOperationCol;

        if (rowCount === lastRowCount && hasValidRows) {
          stableCount++;
          if (stableCount >= targetStable) {
            console.log(`[千牛导出] 表格稳定: ${rowCount}行，操作列存在`);
            return true;
          }
        } else {
          stableCount = 0;
        }
        lastRowCount = rowCount;
      }
      await sleep(200);
    }
    console.warn('[千牛导出] 表格等待超时，尝试继续...');
    return false;
  }

  // 回到第一页
  async function jumpToFirstPage() {
    const paginationEl = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (!paginationEl) return;

    // 直接点击"1"页码按钮（最可靠的方式）
    const page1Btn = findPageButtonByNumber(1);
    if (page1Btn) {
      console.log('[千牛导出] 回第一页：点击页码1');
      clickPageButton(page1Btn);
      for (let i = 0; i < 60; i++) {
        await sleep(200);
        if (getCurrentPageNumber() === 1) {
          // 关键修复：页码变了不代表数据加载完，等待表格内容稳定
          await waitForTableStable(1);
          console.log('[千牛导出] 回第一页成功（页码检测+表格稳定）');
          return;
        }
      }
    }

    // 如果页码1按钮不存在或点击失败，尝试连续点击"上一页"
    console.log('[千牛导出] 回第一页：连续点击上一页');
    for (let attempt = 0; attempt < 30; attempt++) {
      if (getCurrentPageNumber() === 1) break;
      const prevBtn = paginationEl.querySelector('.ant-pagination-prev, .ivu-page-prev, [class*="prev"]');
      if (!prevBtn) break;
      const cls = (prevBtn.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || prevBtn.disabled || prevBtn.getAttribute('aria-disabled') === 'true') break;
      clickPageButton(prevBtn);
      for (let i = 0; i < 20; i++) {
        await sleep(100);
        if (getCurrentPageNumber() === 1) break;
      }
    }
    // 关键修复：回到第一页后等待表格数据完全加载
    await waitForTableStable(1);
    console.log('[千牛导出] 回第一页完成，当前页码:', getCurrentPageNumber());
  }

  function getCurrentPageNumber() {
    const paginationEl = document.querySelector('.next-pagination, .ant-pagination, .ivu-page, [class*="pagination"]');
    if (!paginationEl) return 1;

    // Next UI simple 分页器: .next-pagination-display 显示 "1/203"
    const displayEl = paginationEl.querySelector('.next-pagination-display');
    if (displayEl) {
      const text = (displayEl.textContent || '').trim();
      const m = text.match(/(\d+)\s*\/\s*\d+/);
      if (m) {
        const num = parseInt(m[1], 10);
        if (!isNaN(num) && num > 0) return num;
      }
      const emEl = displayEl.querySelector('em');
      if (emEl) {
        const num = parseInt((emEl.textContent || '').trim(), 10);
        if (!isNaN(num) && num > 0) return num;
      }
    }

    const activeItem = paginationEl.querySelector('.next-current, .ant-pagination-item-active, .ivu-page-item-active, [class*="active"]');
    if (activeItem) {
      const num = parseInt((activeItem.textContent || '').trim(), 10);
      if (!isNaN(num)) return num;
    }
    return 1;
  }

  function getMaxPageNumber(paginationEl) {
    if (!paginationEl) return 1;

    // 1. Next UI simple 分页器: .next-pagination-display 显示 "1/203"
    const displayEl = paginationEl.querySelector('.next-pagination-display');
    if (displayEl) {
      const text = (displayEl.textContent || '').trim();
      const m = text.match(/(\d+)\s*\/\s*(\d+)/);
      if (m) {
        const maxPage = parseInt(m[2], 10);
        if (!isNaN(maxPage) && maxPage > 0) return maxPage;
      }
    }

    // 2. 查找 "共X页" 文本
    const paginationText = paginationEl.textContent || '';
    const totalPagesMatch = paginationText.match(/共\s*(\d+)\s*页/);
    if (totalPagesMatch) {
      const maxPage = parseInt(totalPagesMatch[1], 10);
      if (!isNaN(maxPage) && maxPage > 0) return maxPage;
    }

    // 3. 查找 "共X条" 结合每页条数推算（暂存，不直接返回）
    const totalMatch = paginationText.match(/共\s*(\d+)\s*条/);
    let estimatedPagesFromTotal = 0;
    if (totalMatch) {
      const totalCount = parseInt(totalMatch[1], 10);
      const pageSizeMatch = paginationText.match(/(\d+)\s*条\s*\/\s*页|每页\s*(\d+)\s*条/);
      const pageSize = pageSizeMatch ? parseInt(pageSizeMatch[1] || pageSizeMatch[2], 10) : 10;
      if (!isNaN(totalCount) && !isNaN(pageSize) && pageSize > 0) {
        estimatedPagesFromTotal = Math.ceil(totalCount / pageSize);
        console.log(`[千牛导出] getMaxPageNumber: 从"共${totalCount}条"推算出${estimatedPagesFromTotal}页`);
      }
    }

    // 4. 查找结构化页码项（Next UI / AntD）
    const pageItemSelectors = [
      '.next-pagination-item',
      '.ant-pagination-item',
      '.ivu-page-item',
      '[class*="pagination-item"]',
      '[class*="page-item"]'
    ];
    let maxPage = 0;
    for (const itemSel of pageItemSelectors) {
      const items = paginationEl.querySelectorAll(itemSel);
      for (const item of items) {
        const text = (item.textContent || '').trim();
        if (/^\d+$/.test(text)) {
          const num = parseInt(text, 10);
          if (!isNaN(num) && num > maxPage && num < 100000) {
            maxPage = num;
          }
        }
      }
      if (maxPage > 0) break;
    }
    if (maxPage > 0) return maxPage;

    // 5. 查找 "尾页"/"最后一页" 按钮（如果有，说明至少有那么多页）
    const lastPageSelectors = [
      '.ant-pagination-jump-next',
      '.next-pagination-jump-next',
      '[class*="jump-next"]',
      '[class*="last-page"]',
      '[class*="pagination-last"]',
      'a[title="最后一页"]',
      'button[title="最后一页"]'
    ];
    for (const sel of lastPageSelectors) {
      const el = paginationEl.querySelector(sel);
      if (el && el.offsetHeight > 0) {
        // 尾页按钮存在，说明总页数 > 当前可见最大页码
        // 继续用数字扫描方式
        break;
      }
    }

    // 6. 兜底：扫描所有数字元素
    // 【关键】滑动窗口分页器只显示部分页码，最大可见数字可能不是总页数
    // 因此如果找到 "..." 省略号，说明后面还有更多页
    const hasEllipsis = /\.\.\./.test(paginationText) || paginationText.includes('…');
    
    let visibleMaxPage = 0;
    paginationEl.querySelectorAll('li, a, span, div, button').forEach(el => {
      const text = (el.textContent || '').trim();
      if (/^\d+$/.test(text)) {
        const num = parseInt(text, 10);
        if (!isNaN(num) && num > visibleMaxPage && num < 100000) {
          visibleMaxPage = num;
        }
      }
    });

    // 如果有省略号，说明后面还有页，不能信任当前可见的最大页码
    if (hasEllipsis && visibleMaxPage > 0) {
      // 尝试从 "X-Y/共Z" 格式获取总页数
      const rangeMatch = paginationText.match(/(\d+)\s*-\s*(\d+)\s*\/\s*共\s*(\d+)/);
      if (rangeMatch) {
        const totalPages = parseInt(rangeMatch[3], 10);
        if (!isNaN(totalPages) && totalPages > 0) return totalPages;
      }
      
      // 从 "共X条" 和 "每页Y条" 推算
      if (totalMatch) {
        const totalCount = parseInt(totalMatch[1], 10);
        const perPage = getCurrentPageRows() || 10;
        if (totalCount > 0 && perPage > 0) {
          return Math.ceil(totalCount / perPage);
        }
      }
      
      // 如果有省略号但找不到总页数，返回一个较大的估算值
      // 后续导出循环会通过检查"下一页"按钮状态来确定真实终点
      if (visibleMaxPage > 0) {
        console.log(`[千牛导出] 分页器有省略号，可见最大页=${visibleMaxPage}，将通过翻页验证确定真实总页数`);
        return visibleMaxPage;
      }
    }

    return visibleMaxPage || 1;
  }

  function findLastPageButton(paginationEl) {
    // 1. 优先找"尾页"/"最后一页"/">>" 专用按钮
    const lastBtnSelectors = [
      '.ant-pagination-jump-next',
      '.ant-pagination .ant-pagination-jump-next',
      '.next-pagination-jump-next',
      '[class*="pagination-jump-next"]',
      '[class*="last-page"]',
      '[class*="pagination-last"]',
      'a[title="最后一页"]',
      'button[title="最后一页"]',
      'a[title="尾页"]',
      'button[title="尾页"]'
    ];
    for (const sel of lastBtnSelectors) {
      const el = paginationEl.querySelector(sel);
      if (el && el.offsetHeight > 0) return el;
    }

    // 2. 检查是否有省略号（滑动窗口分页器）
    const paginationText = paginationEl.textContent || '';
    const hasEllipsis = /\.\.\./.test(paginationText) || paginationText.includes('…');
    
    if (hasEllipsis) {
      // 滑动窗口分页器：省略号后面的数字可能是最后一页
      // 查找 "..." 后面的数字元素
      const allElements = paginationEl.querySelectorAll('li, a, span, div, button');
      let foundEllipsis = false;
      let lastPageAfterEllipsis = null;
      for (const el of allElements) {
        const text = (el.textContent || '').trim();
        if (foundEllipsis && /^\d+$/.test(text)) {
          const num = parseInt(text, 10);
          if (!isNaN(num) && num > 1) {
            // 找到省略号后的第一个数字，可能是最后一页或接近最后一页
            lastPageAfterEllipsis = el;
          }
        }
        if (text === '...' || text === '…' || /^\.\.\.$/.test(text)) {
          foundEllipsis = true;
        }
      }
      if (lastPageAfterEllipsis) {
        console.log('[千牛导出] 滑动窗口分页器：找到省略号后的页码');
        return lastPageAfterEllipsis;
      }
      
      // 找不到省略号后的页码，返回null让调用方处理
      // 调用方应该改为：逐页翻到最后
      console.log('[千牛导出] 滑动窗口分页器：无法直接定位最后一页');
      return null;
    }

    // 3. 非滑动窗口：找数字最大的页码按钮
    const pageItems = paginationEl.querySelectorAll('li, a, span, div, button');
    let maxItem = null;
    let maxPage = 0;
    pageItems.forEach(el => {
      const text = (el.textContent || '').trim();
      if (/^\d+$/.test(text)) {
        const num = parseInt(text, 10);
        if (!isNaN(num) && num > maxPage && num < 100000) {
          maxPage = num;
          maxItem = el;
        }
      }
    });
    return maxItem;
  }

  // 旧 jumpToFirstPage 已删除，使用上方新版本

  function getFirstRowText() {
    const selectors = ['.ant-table tbody tr', '.ivu-table tbody tr', 'table tbody tr', '[class*="table"] tbody tr'];
    for (const sel of selectors) {
      const firstRow = document.querySelector(sel);
      if (firstRow) return firstRow.textContent.trim().substring(0, 120);
    }
    return '';
  }

  // 检查分页器是否有下一页
  function checkHasNextPage() {
    const paginationSelectors = [
      '.next-pagination',
      '.ant-pagination',
      '.ivu-page',
      '.el-pagination',
      '[class*="pagination"]',
      '[class*="Pagination"]'
    ];
    
    let paginationEl = null;
    for (const sel of paginationSelectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetHeight > 0) {
        paginationEl = el;
        break;
      }
    }
    
    if (!paginationEl) return false;

    // 策略0: Next UI (Fusion Design) 的 .next-next（本身就是 <button>）
    const nextUiNext = paginationEl.querySelector('.next-next');
    if (nextUiNext) {
      const cls = (nextUiNext.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || nextUiNext.getAttribute('aria-disabled') === 'true' || nextUiNext.disabled) {
        return false;
      }
      return true;
    }

    // 策略1: 查找 AntD 的 li.ant-pagination-next
    const antNextLi = paginationEl.querySelector('.ant-pagination-next');
    if (antNextLi) {
      const cls = (antNextLi.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || antNextLi.getAttribute('aria-disabled') === 'true') {
        return false;
      }
      return true;
    }

    // 策略2: 查找 iView 的 .ivu-page-next
    const ivuNext = paginationEl.querySelector('.ivu-page-next');
    if (ivuNext) {
      const cls = (ivuNext.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || ivuNext.getAttribute('aria-disabled') === 'true') {
        return false;
      }
      return true;
    }

    // 策略3: 查找 Element UI 的 .btn-next
    const elNext = paginationEl.querySelector('.btn-next');
    if (elNext) {
      const cls = (elNext.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || elNext.getAttribute('aria-disabled') === 'true') {
        return false;
      }
      return true;
    }

    // 策略4: 通用查找
    const genericNext = paginationEl.querySelector('[class*="next"], [class*="Next"]');
    if (genericNext) {
      const cls = (genericNext.className || '').toString().toLowerCase();
      if (cls.includes('disabled') || genericNext.getAttribute('aria-disabled') === 'true' || genericNext.disabled) {
        return false;
      }
      // 检查父元素
      let parent = genericNext.parentElement;
      for (let i = 0; i < 3 && parent; i++) {
        const parentCls = (parent.className || '').toString().toLowerCase();
        if (parentCls.includes('disabled') || parent.getAttribute('aria-disabled') === 'true') {
          return false;
        }
        parent = parent.parentElement;
      }
      return true;
    }

    // 策略5: 通过文字找 "下一页" 或 ">"
    const items = paginationEl.querySelectorAll('a, button, span, li, div');
    for (const item of items) {
      const text = (item.textContent || '').trim();
      const title = (item.getAttribute('title') || '').trim();
      if (text === '>' || text === '下一页' || text === 'Next' || 
          title.includes('下一页') || title.toLowerCase() === 'next') {
        const cls = (item.className || '').toString().toLowerCase();
        const parent = item.parentElement;
        const parentCls = parent ? (parent.className || '').toString().toLowerCase() : '';
        if (cls.includes('disabled') || parentCls.includes('disabled') || 
            item.disabled || item.getAttribute('aria-disabled') === 'true') {
          return false;
        }
        return true;
      }
    }

    // 策略6: 检查是否有当前激活页后面的页码
    const activeItem = paginationEl.querySelector('.ant-pagination-item-active, .ivu-page-item-active, [class*="active"]');
    if (activeItem) {
      const nextSibling = activeItem.nextElementSibling;
      if (nextSibling && nextSibling.offsetHeight > 0) {
        const sibText = (nextSibling.textContent || '').trim();
        if (sibText && (/\d/.test(sibText) || sibText === '...')) {
          return true;
        }
      }
    }

    // 策略7: 查找所有页码项，看是否有大于当前页的
    const currentPage = getCurrentPageNumber();
    const pageItems = paginationEl.querySelectorAll('.ant-pagination-item, .ivu-page-item, [class*="page-item"]');
    for (const item of pageItems) {
      const text = (item.textContent || '').trim();
      if (/^\d+$/.test(text)) {
        const num = parseInt(text, 10);
        if (num > currentPage) return true;
      }
    }

    return false;
  }

  // 滚动加载聊天记录，直到没有更多消息
  async function scrollChatToLoadAll(modal, maxAttempts = 10) {
    const scrollContainer = modal.querySelector('.low-chat-scroll') ||
                            modal.querySelector('[class*="ChatLog_scroll"]') ||
                            modal.querySelector('.el-dialog__body') ||
                            modal.querySelector('.ant-modal-body') ||
                            modal.querySelector('[class*="dialog-body"]') ||
                            modal.querySelector('[class*="modal-body"]');
    if (!scrollContainer) return;

    let lastHeight = scrollContainer.scrollHeight;
    let unchangedCount = 0;

    for (let i = 0; i < maxAttempts; i++) {
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
      await sleep(400);

      const currentHeight = scrollContainer.scrollHeight;
      if (currentHeight === lastHeight) {
        unchangedCount++;
        if (unchangedCount >= 2) break;
      } else {
        unchangedCount = 0;
        lastHeight = currentHeight;
      }
    }
  }

  // 处理单条记录：提取表格数据 + 聊天记录
  async function processRecord(record) {
    const chatResult = await extractChatForRow(record);
    const messages = chatResult.messages || [];
    const detail = chatResult.detail || {};

    // 如果买家旺旺是脱敏的，尝试从弹窗/聊天记录替换
    let realBuyerWangwang = '';
    for (const key of Object.keys(record)) {
      if (key.startsWith('_')) continue;
      const val = record[key];
      if (val && typeof val === 'object' && val.isMasked) {
        realBuyerWangwang = getRealBuyerWangwang(messages, detail, val.name);
        if (realBuyerWangwang) {
          record[key + '_真实旺旺'] = realBuyerWangwang;
        }
      }
    }

    // 如果没有脱敏列，也尝试提取真实旺旺
    if (!realBuyerWangwang) {
      realBuyerWangwang = getRealBuyerWangwang(messages, detail, '');
    }

    return {
      ...record,
      _chatMessages: messages,
      _chatDetail: detail,
      _realBuyerWangwang: realBuyerWangwang
    };
  }

  // 暴露到全局
  console.log('[千牛导出] sycm-content.js 版本验证 2026-08-02-v21');
  console.warn('[千牛导出] ===== 新代码已加载 v1.4.60 (2026-08-02-v21) =====');
  console.warn('[千牛导出] 修复内容: 1.翻页后等待表格DOM稳定渲染 2.过滤非数据表格(日历/选择器) 3.数据质量检测与异常重试');

  window.__QIANNIU_SYCM_EXTRACTOR__ = {
    detectMainPageType,
    detectActiveSubTab,
    extractTableData,
    extractChatMessages,
    extractChatForRow,
    extractFullPageData,
    processRecord,
    findActiveModal,
    closeActiveModal,
    findMainTable,
    extractDetailTableInfo,
    extractBuyerFromModalHeader,
    preScanAndGetTotal,
    jumpToFirstPage,
    getCurrentPageRows,
    getCurrentPageNumber,
    getMaxPageNumber,
    getTotalCount,
    checkHasNextPage,
    getLogs: () => (window.__QIANNIU_LOG_BUFFER__ || []).slice(),
    clearLogs: () => { window.__QIANNIU_LOG_BUFFER__ = []; }
  };

  // 监听 SPA 路由变化，路由切换后通知 popup 重新检测
  let lastUrl = location.href;
  function checkUrlChange() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      try {
        chrome.runtime.sendMessage({ action: 'sycmUrlChanged', url: lastUrl });
      } catch (e) {}
    }
  }
  // 拦截 pushState/replaceState
  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function(...args) {
    origPush.apply(this, args);
    setTimeout(checkUrlChange, 50);
  };
  history.replaceState = function(...args) {
    origReplace.apply(this, args);
    setTimeout(checkUrlChange, 50);
  };
  window.addEventListener('popstate', checkUrlChange);
  // 兜底：定时器检测（有些SPA不触发popstate）
  setInterval(checkUrlChange, 2000);

  // ========== 后台任务支持 ==========
  const TASK_STATUS_KEY = '__QIANNIU_EXPORT_TASK__';

  // 保存导出状态到 storage
  function saveTaskState(state) {
    try {
      const taskData = {
        ...state,
        tabId: window.__QIANNIU_TAB_ID__,
        url: location.href,
        savedAt: Date.now()
      };
      chrome.runtime.sendMessage({
        action: 'saveExportTask',
        task: taskData
      });
    } catch (e) {
      console.warn('[千牛导出] 保存任务状态失败:', e.message);
    }
  }

  // 从 storage 读取任务状态
  async function loadTaskState() {
    return new Promise((resolve) => {
      chrome.storage.local.get(TASK_STATUS_KEY, (result) => {
        resolve(result[TASK_STATUS_KEY] || null);
      });
    });
  }

  // 更新任务进度（用于后台监控）
  function updateTaskProgress(progress) {
    const state = window.__QIANNIU_EXPORT_STATE__ || {};
    saveTaskState({
      ...state,
      ...progress,
      status: 'exporting'
    });
  }

  // 监听来自 background 的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request || !request.action) return;

    switch (request.action) {
      case 'RESUME_EXPORT':
        // 收到恢复导出指令
        console.log('[千牛导出] 收到后台恢复导出指令');
        handleResumeExport(request.task).then(result => {
          sendResponse({ success: true, ...result });
        }).catch(err => {
          sendResponse({ success: false, error: err.message });
        });
        return true;

      case 'GET_EXPORT_STATUS':
        // 查询导出状态
        loadTaskState().then(task => {
          sendResponse({ success: true, task, currentState: window.__QIANNIU_EXPORT_STATE__ });
        });
        return true;

      case 'STOP_EXPORT':
        // 停止导出
        console.log('[千牛导出] 收到后台停止导出指令');
        window.__QIANNIU_PAUSE_REQUEST__ = true;
        window.__QIANNIU_EXPORT_STATE__ = { status: 'paused', stoppedAt: Date.now() };
        saveTaskState(window.__QIANNIU_EXPORT_STATE__);
        sendResponse({ success: true });
        return true;

      case 'PING':
        // 心跳检测
        sendResponse({ success: true, url: location.href, exporting: !!window.__QIANNIU_EXPORTING__ });
        return true;
    }
  });

  // 处理恢复导出请求
  async function handleResumeExport(task) {
    // 如果当前没有正在导出，通知 popup 可以恢复
    if (!window.__QIANNIU_EXPORTING__) {
      console.log('[千牛导出] 当前无导出任务，通知 popup 可以恢复');
      chrome.runtime.sendMessage({
        action: 'notifyExportReady',
        payload: {
          canResume: true,
          task: task,
          url: location.href
        }
      });
    }
    return { canResume: !window.__QIANNIU_EXPORTING__ };
  }

  // 主动心跳：每30秒检查一次任务状态
  setInterval(async () => {
    if (window.__QIANNIU_EXPORTING__) {
      updateTaskProgress({
        status: 'exporting',
        currentPage: window.__QIANNIU_CURRENT_PAGE__ || 0,
        totalPages: window.__QIANNIU_TOTAL_PAGES__ || 0,
        exportedCount: window.__QIANNIU_EXPORTED_COUNT__ || 0
      });
    }
  }, 30000);

  // 页面加载完成后，检查是否有未完成的任务
  async function checkPendingTask() {
    try {
      const task = await loadTaskState();
      if (task && task.status === 'exporting') {
        console.log('[千牛导出] 检测到未完成的导出任务，等待 popup 接管');
        chrome.runtime.sendMessage({
          action: 'notifyPendingTask',
          payload: {
            hasPendingTask: true,
            task: task
          }
        });
      }
    } catch (e) {}
  }
  setTimeout(checkPendingTask, 3000);

  // 暴露后台任务API
  window.__QIANNIU_TASK_MANAGER__ = {
    saveState: saveTaskState,
    loadState: loadTaskState,
    updateProgress: updateTaskProgress,
    pause: () => {
      window.__QIANNIU_PAUSE_REQUEST__ = true;
      saveTaskState({ status: 'paused', pausedAt: Date.now() });
    },
    resume: () => {
      window.__QIANNIU_PAUSE_REQUEST__ = false;
      saveTaskState({ status: 'exporting', resumedAt: Date.now() });
    }
  };

  console.log('[千牛导出] 后台任务管理器已就绪 v1.4.44');

  // ========== 后台导出循环（支持popup关闭后继续） ==========
  
  // 后台导出状态
  window.__QIANNIU_BG_EXPORT_STATE__ = {
    running: false,
    pauseRequested: false,
    taskId: null,
    startTime: null
  };

  // 启动后台导出
  async function startBackgroundExport(params) {
    const {
      format = 'excel',
      mask = false,
      encrypt = false,
      password = '',
      maxPages = 999,
      total = 0,
      unknownTotal = true
    } = params;

    if (window.__QIANNIU_BG_EXPORT_STATE__.running) {
      return { success: false, error: '已有导出任务在运行' };
    }

    window.__QIANNIU_BG_EXPORT_STATE__ = {
      running: true,
      pauseRequested: false,
      taskId: Date.now(),
      startTime: Date.now()
    };

    // 记录当前页面类型，用于文件名生成
    const mainPageType = detectMainPageType();
    const subPageType = detectActiveSubTab();

    const conversations = [];
    let completed = 0;
    let currentPage = 1;
    let consecutiveEmptyPages = 0;
    let pageSize = 10;

    window.__QIANNIU_EXPORTING__ = true;

    // 保存初始任务状态
    saveTaskState({
      status: 'exporting',
      startedAt: Date.now(),
      format,
      mask,
      encrypt,
      total,
      completed: 0,
      currentPage: 1
    });

    console.log(`[千牛导出] 后台导出启动: format=${format}, mask=${mask}, totalPages=${maxPages}`);

    // 通知 popup 导出已启动
    chrome.runtime.sendMessage({
      action: 'exportStarted',
      payload: { format, mask, total }
    });

    try {
      while (currentPage <= maxPages) {
        // 检查暂停请求
        if (window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested) {
          console.log('[千牛导出] 后台导出已暂停');
          window.__QIANNIU_BG_EXPORT_STATE__.running = false;
          window.__QIANNIU_EXPORTING__ = false;
          saveTaskState({
            status: 'paused',
            pausedAt: Date.now(),
            completed,
            currentPage,
            conversationsCount: conversations.length
          });
          chrome.runtime.sendMessage({
            action: 'exportPaused',
            payload: { completed, currentPage }
          });
          return { success: true, paused: true, completed, currentPage };
        }

        // 检查页面是否还有效
        if (document.body.innerText.length < 100) {
          console.warn('[千牛导出] 页面可能已失效，等待恢复...');
          await sleep(2000);
          continue;
        }

        // 提取当前页数据
        const pageData = await extractFullPageData();
        if (!pageData || !pageData.rows || pageData.rows.length === 0) {
          consecutiveEmptyPages++;
          console.warn(`[千牛导出] 第${currentPage}页为空，连续空页: ${consecutiveEmptyPages}/2`);
          if (consecutiveEmptyPages >= 2) break;
          continue;
        }
        consecutiveEmptyPages = 0;

        const rows = pageData.rows.slice();
        
        // 更新进度
        saveTaskState({
          status: 'exporting',
          completed,
          currentPage,
          totalPages: maxPages,
          currentPageRows: rows.length,
          lastUpdate: Date.now()
        });

        // 处理每一行
        for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
          if (window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested) break;

          try {
            const processed = await processRecord(rows[rowIdx]);
            if (processed) {
              // 转换为 conversation 格式
              const conversation = convertRecordToConversationSimple(processed, pageData);
              if (conversation) {
                conversations.push(conversation);
                completed++;
              }
            }
          } catch (e) {
            console.warn(`[千牛导出] 处理行${rowIdx}失败:`, e.message);
          }

          // 每处理5行保存一次进度
          if (completed % 5 === 0) {
            saveTaskState({
              status: 'exporting',
              completed,
              currentPage,
              conversationsCount: conversations.length
            });
          }
        }

        // 翻页
        if (pageData.hasNextPage && currentPage < maxPages) {
          const jumped = jumpToPage(currentPage + 1);
          if (!jumped) {
            console.warn('[千牛导出] 翻页失败，尝试继续...');
          }
          await sleep(1500); // 等待页面加载
        } else {
          break;
        }
        
        currentPage++;
      }

      // 导出完成
      window.__QIANNIU_BG_EXPORT_STATE__.running = false;
      window.__QIANNIU_EXPORTING__ = false;

      const exportResult = {
        conversations,
        format,
        mask,
        encrypt,
        password,
        completed,
        total: total || completed,
        pageType: `sycm_${mainPageType || 'data'}`,
        subPageType: subPageType || '',
        exportInfo: {
          totalRecords: conversations.length,
          source: 'sycm-bg',
          lastPage: currentPage,
          duration: Date.now() - (window.__QIANNIU_BG_EXPORT_STATE__.startTime || Date.now())
        }
      };

      // 保存结果
      window.__QIANNIU_EXPORTED_DATA__ = exportResult;

      saveTaskState({
        status: 'completed',
        completed,
        total: conversations.length,
        finishedAt: Date.now(),
        exportInfo: exportResult.exportInfo
      });

      console.log(`[千牛导出] 后台导出完成: ${conversations.length}条记录`);

      // 通知 popup 导出完成
      chrome.runtime.sendMessage({
        action: 'exportCompleted',
        payload: {
          total: conversations.length,
          completed,
          exportInfo: exportResult.exportInfo
        }
      });

      return { success: true, conversationsCount: conversations.length };

    } catch (e) {
      console.error('[千牛导出] 后台导出异常:', e);
      window.__QIANNIU_BG_EXPORT_STATE__.running = false;
      window.__QIANNIU_EXPORTING__ = false;
      saveTaskState({
        status: 'error',
        error: e.message,
        failedAt: Date.now()
      });
      chrome.runtime.sendMessage({
        action: 'exportError',
        payload: { error: e.message }
      });
      return { success: false, error: e.message };
    }
  }

  // 简化版的记录转换（在content script中直接构建）
  function convertRecordToConversationSimple(processed, pageData) {
    try {
      const rowData = {};
      
      // 从 processed 中提取基础字段
      if (processed.rowData) {
        Object.assign(rowData, processed.rowData);
      }
      
      // 添加消息数据
      const messages = processed.messages || [];
      const buyerWangwang = processed.buyerWangwangReal || '';
      
      // 过滤空买家记录（客服内部聊天等无效记录）
      if (!buyerWangwang || buyerWangwang.trim() === '') {
        console.log('[千牛导出] 跳过空买家记录:', rowData);
        return null;
      }
      
      return {
        rowData,
        buyerWangwangReal: buyerWangwang,
        messages,
        pageType: pageData.pageType || 'unknown',
        subPageType: pageData.subPageType || 'unknown'
      };
    } catch (e) {
      console.warn('[千牛导出] 转换记录失败:', e.message);
      return null;
    }
  }

  // 翻页函数
  async function jumpToPage(pageNum) {
    try {
      // 查找分页器中的页码按钮
      const pagination = document.querySelector('.next-pagination') ||
                         document.querySelector('.ant-pagination') || 
                         document.querySelector('[class*="pagination"]');
      if (!pagination) return false;

      const pageButtons = pagination.querySelectorAll('.next-pagination-item, .ant-pagination-item, [class*="pagination-item"]');
      for (const btn of pageButtons) {
        const text = btn.textContent.trim();
        if (text === String(pageNum)) {
          btn.click();
          return true;
        }
      }

      // 如果找不到指定页码，点击下一页
      const nextBtn = pagination.querySelector('.next-next, .ant-pagination-next, [class*="next"]');
      if (nextBtn && !nextBtn.classList.contains('ant-pagination-disabled') && !nextBtn.classList.contains('next-disabled') && !nextBtn.disabled) {
        nextBtn.click();
        return true;
      }

      return false;
    } catch (e) {
      return false;
    }
  }

  // 简单的 sleep 函数
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 暴露后台导出API给 popup 调用
  window.__QIANNIU_TASK_MANAGER__.startExport = startBackgroundExport;
  window.__QIANNIU_TASK_MANAGER__.pauseExport = () => {
    window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested = true;
  };
  window.__QIANNIU_TASK_MANAGER__.resumeExport = () => {
    window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested = false;
  };

  // 监听启动导出的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'START_BG_EXPORT') {
      startBackgroundExport(request.params).then(result => {
        sendResponse(result);
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
    
    if (request.action === 'PAUSE_BG_EXPORT') {
      window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested = true;
      saveTaskState({ status: 'paused', pausedAt: Date.now() });
      sendResponse({ success: true });
      return true;
    }

    if (request.action === 'RESUME_BG_EXPORT') {
      window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested = false;
      saveTaskState({ status: 'exporting', resumedAt: Date.now() });
      sendResponse({ success: true });
      return true;
    }

    if (request.action === 'GET_BG_EXPORT_STATUS') {
      sendResponse({
        success: true,
        running: window.__QIANNIU_BG_EXPORT_STATE__.running,
        pauseRequested: window.__QIANNIU_BG_EXPORT_STATE__.pauseRequested,
        state: window.__QIANNIU_EXPORT_STATE__
      });
      return true;
    }
  });

  console.log('[千牛导出] 后台导出循环已就绪 v1.4.44');
})();
