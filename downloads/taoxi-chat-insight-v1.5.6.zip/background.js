const TASK_KEY = 'taoxiChatInsightTask';

async function saveTask(task) {
  await chrome.storage.local.set({ [TASK_KEY]: task });
}

async function getTask() {
  const result = await chrome.storage.local.get(TASK_KEY);
  return result[TASK_KEY] || null;
}

function notify(task) {
  chrome.runtime.sendMessage({ type: 'qianniuLocal.taskUpdate', ...task }).catch(() => {});
}

async function updateTask(patch) {
  const current = await getTask();
  if (!current || (patch.taskId && patch.taskId !== current.taskId)) return null;
  const next = { ...current, ...patch, updatedAt: Date.now() };
  await saveTask(next);
  notify(next);
  return next;
}

async function startExport(message) {
  const task = {
    taskId: `taoxi-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    tabId: message.tabId,
    frameId: message.frameId,
    total: Number(message.total) || 0,
    totalPages: Number(message.totalPages) || 0,
    format: message.format === 'txt' ? 'txt' : 'csv',
    completed: 0,
    pagesVisited: 0,
    stage: 'exporting',
    phase: '后台任务已启动，等待页面开始采集',
    active: true,
    startedAt: Date.now(),
    updatedAt: Date.now()
  };
  await saveTask(task);
  try {
    const accepted = await chrome.tabs.sendMessage(task.tabId, {
      type: 'qianniuLocal.startDetachedExport',
      taskId: task.taskId,
      redact: Boolean(message.redact),
      format: task.format
    }, { frameId: task.frameId });
    if (!accepted?.ok) throw new Error(accepted?.error || '目标页面未接受导出任务。');
    notify(task);
    return task;
  } catch (error) {
    const failed = await updateTask({ taskId: task.taskId, active: false, stage: 'failed', error: error.message || '无法启动导出任务。' });
    throw new Error(failed?.error || error.message);
  }
}

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message?.type === 'qianniuLocal.startExport') {
    startExport(message).then((task) => respond({ ok: true, task })).catch((error) => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === 'qianniuLocal.getExportStatus') {
    getTask().then((task) => respond({ ok: true, task: task?.tabId === message.tabId ? task : null }));
    return true;
  }
  if (message?.type === 'qianniuLocal.progress') {
    updateTask(message);
    return;
  }
  if (message?.type === 'qianniuLocal.exportFile') {
    (async () => {
      const task = await updateTask({ taskId: message.taskId, stage: 'downloading', active: true });
      if (!task) return;
      try {
        // downloads API 可由后台长期负责；内容脚本只传递本地生成的 CSV 文本。
        const mime = message.mime === 'text/plain' ? 'text/plain' : 'text/csv';
        const url = `data:${mime};charset=utf-8,${encodeURIComponent(message.text)}`;
        await chrome.downloads.download({ url, filename: message.filename, saveAs: true });
        await updateTask({ taskId: message.taskId, stage: 'complete', active: false, completed: message.completed, total: message.total || task.total });
      } catch (error) {
        await updateTask({ taskId: message.taskId, stage: 'failed', active: false, error: error.message || '文件下载失败。' });
      }
    })();
    respond({ ok: true });
    return;
  }
  if (message?.type === 'qianniuLocal.exportFailed') {
    updateTask({ taskId: message.taskId, stage: 'failed', active: false, error: message.error || '导出失败。' });
  }
});
