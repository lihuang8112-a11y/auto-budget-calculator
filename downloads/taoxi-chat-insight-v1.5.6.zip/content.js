(() => {
  if (window.__QIANNIU_LOCAL_EXPORTER__) return;
  window.__QIANNIU_LOCAL_EXPORTER__ = true;

  let detachedExportTask = null;
  let detachedHeartbeatTimer = null;

  const text = (node) => (node?.innerText || node?.textContent || '').replace(/[\u200b\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  const visible = (node) => !!node && node.getClientRects().length > 0 && getComputedStyle(node).visibility !== 'hidden';
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function isChatPage() {
    return Boolean(document.querySelector('.message-list-right, [class*="message-list-right"], .results-list'));
  }

  function tableCandidates() {
    return [...document.querySelectorAll('table, [role="table"]')].filter(visible).map((node) => {
      const rows = node.querySelectorAll('tr, [role="row"]').length;
      const cells = node.querySelectorAll('td, th, [role="cell"], [role="columnheader"]').length;
      return { node, score: rows * 10 + cells };
    }).filter((x) => x.score > 5).sort((a, b) => b.score - a.score);
  }

  function detect() {
    const chat = isChatPage();
    const best = tableCandidates()[0];
    const chatCount = customerItems().length;
    const chatTotal = estimatedChatTotal();
    if (chat && (!best || chatCount > 0)) return { supported: true, kind: 'chat', score: 100 + chatCount, count: chatCount, total: chatTotal || chatCount, description: chatTotal ? `共识别到 ${chatTotal} 个聊天客户，当前页显示 ${chatCount} 个；导出会自动翻页并逐个打开。` : (chatCount ? `当前页显示 ${chatCount} 个聊天客户；未在页面文字中找到总数，将自动翻到没有下一页为止。` : '发现当前聊天窗口；将导出已加载的消息。') };
    const detailCount = best ? chatDetailButtons(best.node).length : 0;
    if (best && detailCount) return { supported: true, kind: 'chat-detail', score: 10000 + detailCount, count: detailCount, total: tableTotalCount() || 0, description: `发现 ${detailCount} 条带“聊天明细”的咨询记录；将逐行打开详情、从顶部滚动到末尾并采集完整聊天。` };
    if (best) return { supported: true, kind: 'table', score: best.score, count: best.node.querySelectorAll('tbody tr, [role="row"]').length, description: '将导出主数据表的可见列。多页模式会点击“下一页”直到结束。' };
    return { supported: false, kind: 'unknown', score: 0, count: 0, description: '未发现聊天记录或数据表。' };
  }

  function pageEstimate(perPage, total) {
    const pagination = paginationRoots()[0];
    if (!pagination) return { pages: total && perPage ? Math.ceil(total / perPage) : 0, perPage };
    const value = text(pagination);
    const display = value.match(/(\d+)\s*\/\s*(\d+)/);
    if (display) return { pages: Number(display[2]), perPage };
    const explicit = value.match(/共\s*(\d+)\s*页/);
    if (explicit) return { pages: Number(explicit[1]), perPage };
    const numbers = [...value.matchAll(/(?:^|\s)(\d+)(?=\s|$)/g)].map((match) => Number(match[1])).filter((number) => number > 0 && number < 100000);
    const pages = total && perPage ? Math.ceil(total / perPage) : Math.max(0, ...numbers);
    return { pages, perPage };
  }

  // 检测时优先使用生意参谋专用适配器的预扫描。它能读取分页器总条数，
  // 必要时短暂跳转以校验尾页，并在完成后恢复至第一页。
  async function detectWithPagination() {
    const result = detect();
    if (!result.supported || result.kind !== 'chat-detail') return result;
    let total = tableTotalCount();
    let { pages, perPage } = pageEstimate(result.count, total);
    const sycm = window.__QIANNIU_SYCM_EXTRACTOR__;
    if (sycm?.preScanAndGetTotal) {
      try {
        const scan = await sycm.preScanAndGetTotal();
        total = Number(scan?.total) || total;
        pages = Number(scan?.pages) || pages;
        perPage = Number(scan?.perPage) || perPage;
        if (sycm.jumpToFirstPage) await sycm.jumpToFirstPage();
      } catch (error) {
        console.warn('[淘系用户聊天洞察] 分页预扫描失败，将使用当前分页器信息：', error);
      }
    }
    return {
      ...result,
      total,
      pages,
      perPage,
      description: total
        ? `检测到共 ${total} 个聊天、${pages || '未知'} 页；导出会从第一页逐条采集聊天明细。`
        : `当前页 ${result.count} 条；未能从分页器确认总数，导出会持续翻页直到末页。`
    };
  }

  function reportProgress(progress) {
    if (detachedExportTask) Object.assign(detachedExportTask, progress);
    try {
      chrome.runtime.sendMessage({
        type: 'qianniuLocal.progress', taskId: detachedExportTask?.taskId,
        stage: 'exporting', heartbeatAt: Date.now(), ...(detachedExportTask || {}), ...progress
      });
    } catch (_) { /* background may be restarting */ }
  }

  function startDetachedHeartbeat() {
    clearInterval(detachedHeartbeatTimer);
    detachedHeartbeatTimer = setInterval(() => {
      if (detachedExportTask) reportProgress({ phase: detachedExportTask.phase || '正在处理当前聊天明细' });
    }, 10_000);
  }

  function safeCsvCell(value) {
    const text = String(value ?? '');
    const guarded = /^[=+\-@]/.test(text) ? `'${text}` : text;
    return `"${guarded.replaceAll('"', '""')}"`;
  }

  function maskExportValue(value) {
    const text = String(value ?? '');
    return text.length < 3 ? '***' : `${text.slice(0, 1)}***${text.slice(-1)}`;
  }

  function isSensitiveExportField(name) {
    return /旺旺|买家|用户|客户|姓名|手机号|电话|联系人|发送人|账号/i.test(name || '');
  }

  function buildChatCsv(data, redact) {
    const conversations = (data.conversations || []).map((conversation) => ({
      ...conversation,
      customer: redact ? maskExportValue(conversation.customer) : conversation.customer,
      rowData: Object.fromEntries(Object.entries(conversation.rowData || {}).map(([key, value]) => [key, redact && isSensitiveExportField(key) ? maskExportValue(value) : value])),
      messages: (conversation.messages || []).map((message) => ({ ...message, sender: redact ? maskExportValue(message.sender) : message.sender }))
    }));
    const detailHeaders = [...new Set(conversations.flatMap((conversation) => Object.keys(conversation.rowData || {})))];
    const rows = conversations.flatMap((conversation) => {
      const messages = conversation.messages?.length ? conversation.messages : [{ time: '', role: '', sender: '', content: conversation.loadFailed ? `[聊天详情加载失败：${conversation.failureReason || '未知原因'}]` : '' }];
      return messages.map((message) => ({ ...conversation.rowData, 客户: conversation.customer, 时间: message.time, 角色: message.role, 发送人: message.sender, 内容: message.content }));
    });
    const headers = [...detailHeaders, '客户', '时间', '角色', '发送人', '内容'];
    const text = '\uFEFF' + [headers.map(safeCsvCell).join(','), ...rows.map((row) => headers.map((header) => safeCsvCell(row[header])).join(','))].join('\r\n');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    return { text, filename: `taoxi-chat-insight-${stamp}.csv` };
  }

  function buildChatText(data, redact) {
    const conversations = data.conversations || [];
    const sections = conversations.map((conversation, index) => {
      const customer = redact ? maskExportValue(conversation.customer) : (conversation.customer || '未命名客户');
      const lines = [`=== 聊天 ${index + 1}：${customer} ===`];
      const rowData = conversation.rowData || {};
      if (Object.keys(rowData).length) {
        lines.push('【咨询明细】');
        for (const [key, value] of Object.entries(rowData)) lines.push(`${key}: ${redact && isSensitiveExportField(key) ? maskExportValue(value) : (value ?? '')}`);
      }
      lines.push('【聊天内容】');
      const messages = conversation.messages || [];
      if (!messages.length) lines.push(conversation.loadFailed ? `[聊天详情加载失败：${conversation.failureReason || '未知原因'}]` : '[未读取到聊天内容]');
      for (const message of messages) {
        const sender = redact ? maskExportValue(message.sender) : (message.sender || message.role || '未知');
        lines.push(`[${message.time || ''}] ${sender}: ${message.content || ''}`);
      }
      return lines.join('\n');
    });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    return { text: sections.join('\n\n'), filename: `taoxi-chat-insight-${stamp}.txt` };
  }

  function rowNodes(table) {
    const rows = [...table.querySelectorAll('tbody tr, [role="row"]')].filter(visible);
    return rows.length ? rows : [...table.querySelectorAll('tr')].filter(visible).slice(1);
  }

  function headersFor(table) {
    const header = [...table.querySelectorAll('thead tr, [role="row"]')].find((row) => row.querySelector('th, [role="columnheader"]'));
    const cells = header ? [...header.querySelectorAll('th, td, [role="columnheader"], [role="cell"]')] : [];
    const names = cells.map(text).filter(Boolean);
    if (names.length) return names.map((name, i) => name || `字段${i + 1}`);
    const first = rowNodes(table)[0];
    return [...(first?.querySelectorAll('td, th, [role="cell"]') || [])].map((_, i) => `字段${i + 1}`);
  }

  function cellValue(cell) {
    const image = cell.querySelector('img');
    const value = text(cell);
    if (value) return value;
    return image ? `[图片${image.alt ? `：${image.alt}` : ''}]` : '';
  }

  function extractTablePage() {
    const table = tableCandidates()[0]?.node;
    if (!table) throw new Error('未找到可导出的数据表。');
    const headers = headersFor(table);
    const rows = rowNodes(table).map((row) => {
      const values = [...row.querySelectorAll(':scope > td, :scope > th, :scope > [role="cell"]')].map(cellValue);
      if (!values.length) return null;
      return Object.fromEntries(headers.map((name, index) => [name, values[index] || '']));
    }).filter(Boolean);
    return { headers, rows };
  }

  function nextButton() {
    const all = [...document.querySelectorAll('button, a, [role="button"], li')].filter(visible);
    return all.find((el) => /^(下一页|下页|Next|›|>)$/i.test(text(el)) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !el.classList.contains('disabled')) || null;
  }

  function pageFingerprint() {
    try { return JSON.stringify(extractTablePage().rows.slice(0, 3)); } catch (_) { return ''; }
  }

  async function extractAllTablePages() {
    const first = extractTablePage();
    const headers = first.headers;
    const all = [...first.rows];
    const seen = new Set([pageFingerprint()]);
    for (let index = 1; index < 200; index += 1) {
      const button = nextButton();
      if (!button) break;
      button.click();
      let changed = false;
      for (let wait = 0; wait < 30; wait += 1) { await sleep(300); const fingerprint = pageFingerprint(); if (fingerprint && !seen.has(fingerprint)) { seen.add(fingerprint); changed = true; break; } }
      if (!changed) break;
      const page = extractTablePage();
      for (const row of page.rows) all.push(Object.fromEntries(headers.map((h) => [h, row[h] || ''])));
    }
    return { headers, rows: all };
  }

  // 聊天查询页的 DOM 会因灰度版本而不同。下面的逻辑刻意不依赖固定的
  // CSS 模块名：先定位最小的客户项与真正的消息容器，再处理翻页和加载状态。
  const CUSTOMER_SELECTORS = '.results-list, [class*="result"][class*="list"], [class*="customer"][class*="item"], [class*="contact"][class*="item"]';
  const MESSAGE_SELECTORS = '[class*="_chatWrap"], [class*="chatWrap"], [data-message-id], [data-messageid]';

  function customerItems() {
    const all = [...document.querySelectorAll(CUSTOMER_SELECTORS)].filter((node) => visible(node) && text(node).length > 0 && text(node).length < 600);
    return all.filter((node) => !all.some((other) => other !== node && node.contains(other)));
  }

  function customerName(node, index) {
    const named = node.querySelector('[class*="nick"], [class*="name"], [class*="user"], [title]');
    return text(named) || text(node).split(/\s{2,}/)[0].slice(0, 80) || `客户 ${index + 1}`;
  }

  function customerKey(node, index) {
    const id = node.getAttribute('data-id') || node.getAttribute('data-user-id') || node.getAttribute('data-key') || '';
    return id ? `id:${id}` : `name:${customerName(node, index)}`;
  }

  function paginationRoots() {
    return [...document.querySelectorAll('[class*="pagination"], [class*="Pagination"], [class*="pager"], [class*="Pager"], [role="navigation"]')].filter(visible);
  }

  function isDisabled(node) {
    return !node || node.disabled || node.getAttribute('aria-disabled') === 'true' || /disabled|is-disabled/.test(String(node.className || ''));
  }

  function chatNextButton() {
    const roots = paginationRoots();
    const scopes = roots.length ? roots : [document];
    for (const scope of scopes) {
      const candidate = [...scope.querySelectorAll('button, a, [role="button"], li')].find((node) => {
        const label = `${text(node)} ${node.getAttribute('title') || ''} ${node.getAttribute('aria-label') || ''}`;
        return visible(node) && !isDisabled(node) && /下一页|下页|next|next page|›|»/i.test(label);
      });
      if (candidate) return candidate;
    }
    return null;
  }

  function estimatedChatTotal() {
    const sources = [...paginationRoots(), document.body].map(text);
    const values = [];
    for (const source of sources) {
      for (const match of source.matchAll(/(?:共|总计|total)\s*([\d,]+)\s*(?:条|个|位|条记录|条数据|results?|items?)/gi)) values.push(Number(match[1].replaceAll(',', '')));
      for (const match of source.matchAll(/([\d,]+)\s*(?:条|个|位)\s*(?:客户|用户|聊天|会话|记录)/g)) values.push(Number(match[1].replaceAll(',', '')));
    }
    return values.filter((value) => Number.isFinite(value) && value > 0 && value < 1_000_000).sort((a, b) => b - a)[0] || 0;
  }

  function chatPageFingerprint() {
    return customerItems().map(customerName).join('|');
  }

  async function moveToNextChatPage() {
    const before = chatPageFingerprint();
    const next = chatNextButton();
    if (!next) return false;
    next.click();
    for (let attempt = 0; attempt < 40; attempt += 1) {
      await sleep(250);
      const after = chatPageFingerprint();
      if (after && after !== before) return true;
    }
    return false;
  }

  function chatContainers() {
    const nodes = [...document.querySelectorAll('.message-list-right, [class*="message-list-right"], [class*="messageList"], [class*="chat-list"], [class*="chatList"]')].filter(visible);
    return nodes.sort((a, b) => messageWrappers(b).length - messageWrappers(a).length || text(b).length - text(a).length);
  }

  function chatContainer() { return chatContainers()[0] || null; }

  function messageWrappers(container) {
    if (!container) return [];
    const all = [...container.querySelectorAll(MESSAGE_SELECTORS)].filter(visible);
    return all.filter((node) => !all.some((other) => other !== node && other.contains(node)));
  }

  function messageDateFor(wrapper, container) {
    const dateNodes = [...container.querySelectorAll('[class*="groupTime"], [class*="_groupTime"], [class*="date"], time')].filter(visible);
    let latest = '';
    for (const node of dateNodes) {
      if (node.compareDocumentPosition(wrapper) & Node.DOCUMENT_POSITION_FOLLOWING) latest = text(node);
    }
    return latest;
  }

  function readChatMessages(container = chatContainer()) {
    if (!container) return [];
    const result = [];
    for (const wrap of messageWrappers(container)) {
      const time = text(wrap.querySelector('[class*="chatTime"], [class*="_chatTime"], time'));
      const sender = text(wrap.querySelector('[class*="chatName"], [class*="_chatName"], [class*="sender"], [class*="nick"]'));
      const contentNode = wrap.querySelector('[class*="chatText"], [class*="_chatText"], [class*="chatContent"], [class*="_chatContent"], [class*="messageContent"], [class*="message-content"]');
      let content = text(contentNode);
      const media = contentNode?.querySelectorAll('img, video, audio').length || 0;
      if (!content && media) content = '[图片或媒体]';
      if (!content && !time && !sender) continue;
      if (!content) content = text(wrap).replace(sender, '').replace(time, '').trim();
      const classes = `${wrap.className || ''} ${contentNode?.className || ''}`.toLowerCase();
      result.push({ date: messageDateFor(wrap, container), time, sender, role: /xiaoer|seller|service|right|customer-service/.test(classes) ? '客服' : '买家', content });
    }
    return result;
  }

  function messagesFingerprint(container) {
    const rows = readChatMessages(container);
    return rows.slice(-3).map((row) => `${row.time}|${row.sender}|${row.content}`).join('||');
  }

  function messageScrollContainer(container) {
    const candidates = [container, ...container.querySelectorAll('[class*="scroll"], [class*="Scroll"], [style*="overflow"]')].filter((node) => node.scrollHeight > node.clientHeight + 20);
    return candidates.sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight))[0] || container;
  }

  function mergeMessages(target, messages) {
    for (const message of messages) {
      const key = `${message.date}|${message.time}|${message.sender}|${message.content}`;
      if (!target.has(key)) target.set(key, message);
    }
  }

  async function waitForChatReady(previous) {
    for (let attempt = 0; attempt < 60; attempt += 1) {
      await sleep(150);
      const container = chatContainer();
      const fingerprint = messagesFingerprint(container);
      if (fingerprint && (fingerprint !== previous || attempt >= 5)) return container;
      const failure = text(container);
      if (/接口超时|加载失败|请求超时/.test(failure) && attempt > 20) break;
    }
    return null;
  }

  async function collectOpenedChat(previous) {
    const container = await waitForChatReady(previous);
    if (!container) return null;
    const collected = new Map();
    mergeMessages(collected, readChatMessages(container));
    const scroller = messageScrollContainer(container);
    let stable = 0;
    let last = messagesFingerprint(container);
    for (let attempt = 0; attempt < 15 && stable < 3; attempt += 1) {
      scroller.scrollTop = 0;
      await sleep(220);
      mergeMessages(collected, readChatMessages(container));
      const current = messagesFingerprint(container);
      stable = current === last ? stable + 1 : 0;
      last = current;
    }
    scroller.scrollTop = scroller.scrollHeight;
    await sleep(120);
    mergeMessages(collected, readChatMessages(container));
    return [...collected.values()];
  }

  async function openCustomer(node) {
    const eventOptions = { bubbles: true, cancelable: true, view: window };
    node.dispatchEvent(new MouseEvent('mousedown', eventOptions));
    node.dispatchEvent(new MouseEvent('mouseup', eventOptions));
    node.click();
  }

  async function extractChats(limit) {
    const total = estimatedChatTotal();
    const requested = Math.max(1, Math.min(Number(limit) || total || 50, 5000));
    const target = total ? Math.min(requested, total) : requested;
    const conversations = [];
    const seen = new Set();
    let pagesVisited = 0;

    while (conversations.length < target && pagesVisited < 500) {
      const customers = customerItems();
      if (!customers.length) {
        if (pagesVisited === 0) {
          const messages = await collectOpenedChat('');
          if (!messages?.length) throw new Error('没有找到客户列表或已加载的聊天消息。请先在页面中执行查询。');
          conversations.push({ customer: '当前会话', messages });
        }
        break;
      }
      pagesVisited += 1;
      for (let index = 0; index < customers.length && conversations.length < target; index += 1) {
        const customer = customers[index];
        const key = customerKey(customer, index);
        if (seen.has(key)) continue;
        seen.add(key);
        const name = customerName(customer, conversations.length);
        const previous = messagesFingerprint(chatContainer());
        await openCustomer(customer);
        let messages = await collectOpenedChat(previous);
        if (!messages) { // 页面偶发慢加载时自动重试一次
          await sleep(900);
          await openCustomer(customer);
          messages = await collectOpenedChat(previous);
        }
        conversations.push({ customer: name, messages: messages || [], loadFailed: !messages });
        await sleep(250);
      }
      if (conversations.length >= target || !(await moveToNextChatPage())) break;
    }
    return { conversations, total: total || conversations.length, pagesVisited };
  }

  // 生意参谋“咨询明细”专用路径：每条表格记录都通过其“聊天明细”入口
  // 打开独立弹窗。这里不复用聊天列表逻辑，避免把主表本身误当作聊天内容。
  function chatDetailButtons(scope) {
    const candidates = [...scope.querySelectorAll('button, a, [role="button"], span, div')].filter(visible);
    const matches = candidates.filter((node) => {
      const value = text(node);
      return /^(聊天明细|聊天记录|查看聊天|对话详情)$/.test(value) || (/聊天/.test(value) && value.length <= 12 && /明细|记录|详情|查看/.test(value));
    });
    return [...new Set(matches.map((node) => node.closest('button, a, [role="button"]') || node))].filter(visible);
  }

  function rowChatDetailTrigger(row) {
    const cells = [...row.querySelectorAll(':scope > td, :scope > [role="cell"]')];
    const operationCells = cells.filter((cell) => /操作|聊天明细|聊天记录/.test(text(cell)));
    const scopes = [...operationCells, ...cells];
    // 生意参谋常见结构为 .operation-item > span；先返回最内层 a/button，
    // 随后由 openAndReadDetail 同时触发其 operation-item 父容器。
    for (const scope of scopes) {
      const explicit = [...scope.querySelectorAll('a, button, [role="button"]')].find((node) => /聊天明细|聊天记录|查看聊天|对话详情/.test(text(node)) && visible(node));
      if (explicit) return explicit;
      const operation = [...scope.querySelectorAll('.operation-item, [class*="operation-item"]')].find((node) => /聊天明细|聊天记录|查看聊天|对话详情/.test(text(node)) && visible(node));
      if (operation) return operation;
    }
    return chatDetailButtons(row)[0] || null;
  }

  function tableTotalCount() {
    const sources = [...paginationRoots(), document.body].map(text);
    for (const source of sources) {
      const match = source.match(/共\s*([\d,]+)\s*条(?:记录|数据)?/);
      if (match) return Number(match[1].replaceAll(',', '')) || 0;
    }
    return 0;
  }

  function dataForTableRow(row, headers) {
    const cells = [...row.querySelectorAll(':scope > td, :scope > th, :scope > [role="cell"]')];
    return Object.fromEntries(headers.map((header, index) => [header, cellValue(cells[index] || document.createElement('td'))]));
  }

  function detailModalCandidates() {
    const selectors = [
      '[role="dialog"]', '.ant-modal-wrap', '.ant-drawer', '.el-dialog__wrapper',
      '.next-dialog', '[class*="modal" i]', '[class*="dialog" i]', '[class*="drawer" i]'
    ].join(',');
    const standard = [...document.querySelectorAll(selectors)].filter((node) => {
      if (!visible(node)) return false;
      const box = node.getBoundingClientRect();
      return box.width >= 240 && box.height >= 120 && !node.closest('table');
    });
    // 生意参谋的聊天详情在部分版本中没有 modal/dialog 类名；它是一个
    // fixed 层，内部包含 low-chat 或 ChatLog。用尺寸、定位和内容三者联合识别。
    const floating = [...document.querySelectorAll('div, section, aside')].filter((node) => {
      if (!visible(node) || node.closest('table')) return false;
      const box = node.getBoundingClientRect();
      if (box.width < 240 || box.height < 120) return false;
      const style = getComputedStyle(node);
      if (!['fixed', 'absolute'].includes(style.position)) return false;
      const value = text(node);
      return /聊天明细|聊天记录|聊天内容|low-chat|ChatLog/i.test(`${value} ${node.className || ''}`);
    });
    return [...new Set([...standard, ...floating])].sort((a, b) => {
      const za = Number(getComputedStyle(a).zIndex) || 0;
      const zb = Number(getComputedStyle(b).zIndex) || 0;
      return zb - za || text(b).length - text(a).length;
    });
  }

  function titledChatDetailModal() {
    const titles = [...document.querySelectorAll('h1, h2, h3, h4, div, span, p')]
      .filter((node) => visible(node) && text(node) === '聊天明细');
    const matches = [];
    for (const title of titles) {
      let node = title.parentElement;
      for (let depth = 0; node && node !== document.body && depth < 10; depth += 1, node = node.parentElement) {
        const box = node.getBoundingClientRect();
        const hasChatTable = [...node.querySelectorAll('table')].some((table) => /聊天对象/.test(text(table)) && /聊天内容/.test(text(table)) && /聊天时间/.test(text(table)));
        if (box.width >= 450 && box.height >= 280 && hasChatTable) matches.push(node);
      }
    }
    return matches.sort((a, b) => a.getBoundingClientRect().width * a.getBoundingClientRect().height - b.getBoundingClientRect().width * b.getBoundingClientRect().height)[0] || null;
  }

  async function waitForDetailModal(previous, attempts = 80) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      await sleep(150);
      const titled = titledChatDetailModal();
      if (titled && (!previous.has(titled) || /聊天对象/.test(text(titled)))) return titled;
      const candidates = detailModalCandidates();
      const modal = candidates.find((node) => !previous.has(node)) || candidates.find((node) => /聊天明细|聊天记录|聊天内容/i.test(text(node)));
      if (modal) return modal;
    }
    return null;
  }

  function visibleMessageRows(modal) {
    const chatTable = [...modal.querySelectorAll('table')].find((table) => /聊天对象/.test(text(table)) && /聊天内容/.test(text(table)) && /聊天时间/.test(text(table)));
    const tableRows = [...(chatTable?.querySelectorAll('tbody tr') || [])].filter((row) => visible(row) && row.querySelectorAll('td').length > 0);
    const structured = [...modal.querySelectorAll('[class*="low-chat-row"], [class*="ChatLog_row"], [class*="message-row" i], [class*="chat-row" i]')].filter(visible);
    const candidates = [...tableRows, ...structured];
    return candidates.filter((node) => {
      const value = text(node);
      return value.length > 1 && !/^(聊天时间|发送人|聊天内容|暂无数据|加载中|消息列表)$/.test(value) && !/^(聊天明细|关闭|取消|确定)$/.test(value);
    }).filter((node) => !candidates.some((other) => other !== node && node.contains(other) && text(other).length > 1));
  }

  function parseDetailMessage(row) {
    const cells = [...row.querySelectorAll(':scope > td, [class*="cell" i]')].filter(visible).map(text).filter(Boolean);
    const raw = cells.length ? cells : [text(row)];
    const timestampIndex = raw.findIndex((value) => /(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}\s*)?\d{1,2}:\d{2}/.test(value));
    const time = timestampIndex >= 0 ? raw[timestampIndex] : '';
    const senderIndex = raw.findIndex((value, index) => index !== timestampIndex && /(?:买家|客服|旺旺|店小二|机器人)/.test(value));
    const sender = senderIndex >= 0 ? raw[senderIndex] : '';
    const content = raw.filter((value, index) => index !== timestampIndex && index !== senderIndex).join(' ').trim() || text(row);
    const role = /客服|店小二|机器人/.test(sender) ? '客服' : (/买家/.test(sender) ? '买家' : '未知');
    const date = (time.match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}/) || [])[0] || '';
    return { date, time, sender, role, content };
  }

  function findDetailScroller(modal) {
    const chatTable = [...modal.querySelectorAll('table')].find((table) => /聊天对象/.test(text(table)) && /聊天内容/.test(text(table)) && /聊天时间/.test(text(table)));
    const candidates = [chatTable?.parentElement, modal, ...modal.querySelectorAll('[class*="scroll" i], [class*="list" i], [class*="body" i], [style*="overflow"]')]
      .filter((node) => visible(node) && node.scrollHeight > node.clientHeight + 24);
    return candidates.sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight))[0] || modal;
  }

  function mergeDetailMessages(target, modal) {
    for (const row of visibleMessageRows(modal)) {
      const message = parseDetailMessage(row);
      const key = `${message.date}|${message.time}|${message.sender}|${message.content}`;
      if (!target.has(key)) target.set(key, message);
    }
  }

  async function collectDetailMessages(modal) {
    const scroller = findDetailScroller(modal);
    const messages = new Map();
    // 从顶部开始，逐屏下滚至底部。每一屏都合并一次，兼容虚拟列表和懒加载。
    scroller.scrollTop = 0;
    await sleep(350);
    let lastHeight = -1;
    let stable = 0;
    for (let step = 0; step < 160 && stable < 4; step += 1) {
      mergeDetailMessages(messages, modal);
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
      const previousTop = scroller.scrollTop;
      const previousHeight = scroller.scrollHeight;
      if (atBottom) {
        await sleep(250); // 给底部懒加载一次机会
      } else {
        scroller.scrollTop = Math.min(scroller.scrollTop + Math.max(180, Math.floor(scroller.clientHeight * 0.82)), scroller.scrollHeight);
        await sleep(220);
      }
      const unchanged = previousTop === scroller.scrollTop && previousHeight === scroller.scrollHeight && lastHeight === scroller.scrollHeight;
      stable = unchanged ? stable + 1 : 0;
      lastHeight = scroller.scrollHeight;
    }
    mergeDetailMessages(messages, modal);
    return [...messages.values()];
  }

  async function closeDetailModal(modal) {
    const close = [...modal.querySelectorAll('button, [role="button"], [aria-label]')].find((node) => {
      const label = `${text(node)} ${node.getAttribute('aria-label') || ''} ${node.getAttribute('title') || ''}`;
      return /关闭|close|取消|×/i.test(label) && visible(node);
    });
    if (close) close.click();
    else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
    for (let attempt = 0; attempt < 30; attempt += 1) {
      await sleep(120);
      if (!modal.isConnected || !visible(modal)) return;
    }
  }

  function clickableDetailTargets(button) {
    const targets = [];
    let node = button;
    for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
      const style = getComputedStyle(node);
      if (node.matches('button, a, [role="button"]') || style.cursor === 'pointer' || /operation|action|button|link/i.test(String(node.className || ''))) targets.push(node);
    }
    targets.push(button);
    return [...new Set(targets)].filter(visible);
  }

  async function openAndReadDetail(button) {
    const before = new Set(detailModalCandidates());
    const targets = clickableDetailTargets(button);
    let modal = null;
    // 有些版本的事件绑定在操作列父节点，有些绑定在文字节点；由内至外各试一次。
    for (const target of targets) {
      target.scrollIntoView({ block: 'center', behavior: 'instant' });
      target.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'mouse' }));
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'mouse' }));
      target.click();
      modal = await waitForDetailModal(before, 18);
      if (modal) break;
    }
    // 页面偶发首击只激活行，第二击才弹出；再以原始文字节点重试一次。
    if (!modal) {
      await sleep(500);
      button.click();
      modal = await waitForDetailModal(before, 60);
    }
    if (!modal) return { messages: [], loadFailed: true, failureReason: '未检测到聊天详情弹窗' };
    await sleep(400);
    const messages = await collectDetailMessages(modal);
    await closeDetailModal(modal);
    return { messages, loadFailed: false, failureReason: messages.length ? '' : '聊天详情弹窗中未找到消息行' };
  }

  async function moveToNextTablePage() {
    const before = pageFingerprint();
    const next = nextButton();
    if (!next) return false;
    next.scrollIntoView({ block: 'center', behavior: 'instant' });
    next.click();
    for (let attempt = 0; attempt < 50; attempt += 1) {
      await sleep(220);
      const after = pageFingerprint();
      if (after && after !== before) return true;
    }
    return false;
  }

  async function extractChatDetails(allPages) {
    // 当生意参谋专用适配器已加载时，必须走它的完整链路。该链路会保留
    // 行内操作节点，依次完成点击、等待详情、滚动加载、消息解析和关闭弹窗。
    const sycm = window.__QIANNIU_SYCM_EXTRACTOR__;
    if (sycm?.extractFullPageData && sycm?.processRecord) {
      const conversations = [];
      let scan = { total: 0, pages: 0, perPage: 0 };
      if (allPages && sycm.preScanAndGetTotal) {
        scan = await sycm.preScanAndGetTotal();
        if (sycm.jumpToFirstPage) await sycm.jumpToFirstPage();
      }
      let pageData = await sycm.extractFullPageData();
      if (!pageData?.success) throw new Error(pageData?.reason || '生意参谋专用适配器未找到数据表。');
      const total = Number(scan?.total) || pageData.totalCount || sycm.getTotalCount?.() || 0;
      const totalPages = Number(scan?.pages) || pageEstimate(pageData.rows.length, total).pages || 0;
      const maxPages = allPages ? Math.max(1, Math.min(totalPages || 1000, 1000)) : 1;
      let page = 0;
      reportProgress({ completed: 0, total, pagesVisited: 1, totalPages, phase: '正在读取第 1 页聊天记录' });
      while (pageData?.rows?.length && page < maxPages) {
        for (const record of pageData.rows) {
          reportProgress({ completed: conversations.length, total, pagesVisited: page + 1, totalPages, phase: `正在采集第 ${conversations.length + 1} 个聊天明细` });
          const processed = await sycm.processRecord(record);
          const rowData = {};
          for (const [key, value] of Object.entries(processed || {})) {
            if (key.startsWith('_')) continue;
            if (value && typeof value === 'object') {
              rowData[key] = value.text ?? value.name ?? value.productName ?? value.datetime ?? JSON.stringify(value);
            } else rowData[key] = value ?? '';
          }
          const messages = processed?._chatMessages || [];
          const customer = processed?._realBuyerWangwang || rowData['买家旺旺'] || rowData['买家'] || '咨询记录';
          conversations.push({ customer, rowData, messages, loadFailed: messages.length === 0, failureReason: messages.length ? '' : '详情中没有可导出的消息' });
          reportProgress({ completed: conversations.length, total, pagesVisited: page + 1, totalPages, phase: `已完成第 ${conversations.length} 个聊天，准备下一条` });
          await sleep(180);
        }
        page += 1;
        if (!allPages || !sycm.checkHasNextPage?.() || !(await moveToNextTablePage())) break;
        // 翻页后必须用专用适配器重新构建行记录；旧行携带的 DOM 节点已经失效。
        await sleep(450);
        pageData = await sycm.extractFullPageData();
      }
      return { conversations, total: total || conversations.length, pagesVisited: page, totalPages };
    }

    const conversations = [];
    let pagesVisited = 0;
    const total = tableTotalCount();
    const totalPages = pageEstimate(0, total).pages;
    const maxPages = allPages ? Math.max(1, Math.min(totalPages || 1000, 1000)) : 1;
    reportProgress({ completed: 0, total, pagesVisited: 1, totalPages, phase: '正在读取第 1 页聊天记录' });
    for (let page = 0; page < maxPages; page += 1) {
      const table = tableCandidates()[0]?.node;
      if (!table) throw new Error('未找到咨询明细表。');
      const headers = headersFor(table);
      const rows = rowNodes(table);
      let buttonsFound = 0;
      for (let index = 0; index < rows.length; index += 1) {
        const button = rowChatDetailTrigger(rows[index]);
        if (!button) continue;
        buttonsFound += 1;
        reportProgress({ completed: conversations.length, total, pagesVisited: page + 1, totalPages, phase: `正在采集第 ${conversations.length + 1} 个聊天明细` });
        const detail = await openAndReadDetail(button);
        const rowData = dataForTableRow(rows[index], headers);
        const customer = rowData['买家旺旺'] || rowData['买家'] || rowData['买家昵称'] || `咨询记录 ${conversations.length + 1}`;
        conversations.push({ customer, rowData, messages: detail.messages, loadFailed: detail.loadFailed, failureReason: detail.failureReason || '' });
        reportProgress({ completed: conversations.length, total, pagesVisited: page + 1, totalPages, phase: `已完成第 ${conversations.length} 个聊天，准备下一条` });
        await sleep(180);
      }
      pagesVisited += 1;
      if (!buttonsFound || !allPages || !(await moveToNextTablePage())) break;
    }
    return { conversations, total: total || conversations.length, pagesVisited, totalPages };
  }

  async function runDetachedExport(taskId, redact, format) {
    detachedExportTask = { taskId, completed: 0, phase: '正在准备导出任务' };
    startDetachedHeartbeat();
    try {
      const data = await extractChatDetails(true);
      const file = format === 'txt' ? buildChatText(data, redact) : buildChatCsv(data, redact);
      reportProgress({ completed: data.conversations.length, total: data.total || data.conversations.length, pagesVisited: data.pagesVisited, totalPages: data.totalPages, phase: '聊天采集完成，正在生成文件' });
      await chrome.runtime.sendMessage({
        type: 'qianniuLocal.exportFile', taskId, text: file.text, filename: file.filename,
        mime: format === 'txt' ? 'text/plain' : 'text/csv',
        completed: data.conversations.length, total: data.total || data.conversations.length
      });
    } catch (error) {
      try { await chrome.runtime.sendMessage({ type: 'qianniuLocal.exportFailed', taskId, error: error.message || '导出失败。' }); } catch (_) { /* background may retry on next task */ }
    } finally {
      clearInterval(detachedHeartbeatTimer);
      detachedHeartbeatTimer = null;
      detachedExportTask = null;
    }
  }

  chrome.runtime.onMessage.addListener((request, _sender, respond) => {
    if (request?.type === 'qianniuLocal.startDetachedExport') {
      if (detachedExportTask) { respond({ ok: false, error: '当前页面已有导出任务在运行。' }); return; }
      runDetachedExport(request.taskId, Boolean(request.redact), request.format);
      respond({ ok: true });
      return;
    }
    if (request?.type === 'qianniuLocal.detect') {
      detectWithPagination().then(respond).catch((error) => respond({ supported: false, kind: 'unknown', score: 0, count: 0, error: error.message }));
      return true;
    }
    if (request?.type !== 'qianniuLocal.extract') return;
    (async () => {
      try {
        if (request.kind === 'chat') respond({ ok: true, ...(await extractChats(request.chatLimit)) });
        else if (request.kind === 'chat-detail') respond({ ok: true, ...(await extractChatDetails(request.allPages)) });
        else respond({ ok: true, ...(request.allPages ? await extractAllTablePages() : extractTablePage()) });
      } catch (error) { respond({ ok: false, error: error.message || '提取失败。' }); }
    })();
    return true;
  });
})();
